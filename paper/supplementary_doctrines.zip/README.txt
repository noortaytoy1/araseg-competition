SUPPLEMENTARY MATERIAL — the complete learned jury doctrines (verbatim)

READ THE _ABOUT_THIS_PAIR.txt IN EACH FOLDER FIRST. Three jury pairs, one trap:
the shared punctuated pair's files carry internal headers naming "NoPnx-NP" (the
rendering of their first training phase), while the NoPnx-NP track's actual pair is
the curated-39 one in the NoPnx-NP/ folder. Every folder's _ABOUT file states which
track(s) its pair judged and its true training counts.

Contents: six doctrine files plus the shared pair's two lessons records. All are the
juries' own writing, UTF-8 Markdown with Arabic quotations. The doctrine files are
byte-identical to the public release (jury/doctrines/), EXCEPT that the two shared-
pair copies here carry a clearly bracketed EDITORIAL NOTE prepended above the jury
text (the release copies remain byte-pure; the note exists only in this package to
prevent the header/track confusion).

Integrity: every excerpt printed in the paper appears verbatim in these files; the
release's verification script re-checks that on every build.
