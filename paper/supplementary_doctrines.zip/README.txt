SUPPLEMENTARY MATERIAL — the complete learned jury doctrines (verbatim)

Six policy files plus the shared pair's two lessons records, byte-identical to the
release (jury/doctrines/ and scratch history) and to the files used in every reported
evaluation. Each was written entirely by its jury during training; superseded rules
are struck through, never deleted. UTF-8 Markdown with Arabic quotations.

  NoPnx-NP/doctrine_jury0.md   NoPnx-NP/doctrine_jury1.md    (curated-39 pair; the 89.1 blind submission)
  NoPnx-PA/doctrine_jury0.md   NoPnx-PA/doctrine_jury1.md    (full-174 pair, 87+87 disjoint; the paper's ablation)
  Pnx-NP-PA/doctrine_jury0.md  Pnx-NP-PA/doctrine_jury1.md   (shared punctuated pair)
  Pnx-NP-PA/lessons_np_juror0.md  Pnx-NP-PA/lessons_np_juror1.md
      (the shared pair's accumulated correction records, referenced by its doctrines)

NAMING NOTE (read before comparing counts): the shared punctuated pair's doctrines
carry INTERNAL headers naming "NoPnx-NP" / "no punctuation" and counts of 141 and 123
graded documents. That pair's first training phase ran on the DE-PUNCTUATED form of
the corpus, and the jurors titled their own files accordingly; the folder name
(Pnx-NP-PA) is the track assignment, the internal header is the jury's own label.
The track folder NoPnx-NP holds a different, later, clean-room pair trained on a
curated 39-document curriculum (20 and 19); its doctrines' own batch headers (1-4)
match. Per-juror distinct-document counts on disk: shared pair 133 and 121 with
partial overlap (the 141/123 in the headers count re-served documents); NoPnx-PA
87+87 disjoint; NoPnx-NP 20+19 disjoint.

Integrity: every excerpt printed in the paper appears verbatim in these files; the
release's verification script re-checks that on every build.
