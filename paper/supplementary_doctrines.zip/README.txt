SUPPLEMENTARY MATERIAL — the complete learned jury doctrines (verbatim)

These are the six policy files, byte-identical to the release (jury/doctrines/ in the
code repository) and to the files used in every reported evaluation. Each was written
entirely by its jury during training; superseded rules are struck through, never
deleted, so the revision history is part of the text. Files are UTF-8 Markdown and
contain Arabic quotations; open in any text editor or Markdown viewer.

  NoPnx-NP/doctrine_jury0.md   NoPnx-NP/doctrine_jury1.md    (curated-39 pair, the 89.1 submission)
  NoPnx-PA/doctrine_jury0.md   NoPnx-PA/doctrine_jury1.md    (full-174 pair, the paper's ablation)
  Pnx-NP-PA/doctrine_jury0.md  Pnx-NP-PA/doctrine_jury1.md   (shared punctuated pair)

Integrity: every excerpt printed in the paper appears verbatim in these files, and the
release's verification script re-checks that on every build.
