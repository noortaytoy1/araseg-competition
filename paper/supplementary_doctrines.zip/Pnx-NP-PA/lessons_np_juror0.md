# Lessons — Juror 0, NoPnx-NP (cumulative, append-only)

Every entry below is a correction I absorbed from an answer key, stated as *what the annotators do*,
with the short example from my own error that produced it. Never delete an entry.

---

## BATCH 1 — docs: doc_361233315d24 (legal), doc_eb278f2980be (narrative), doc_54f919517225 (narrative)
Scores: legal F1 97.6 (P 96.3 / R 98.9) · narrative-Aqqad F1 85.0 (P 98.6 / R 74.7) · narrative-Tolstoy F1 69.3 (P 97.5 / R 53.7)
Batch mean F1 ≈ 84.0. Grader line: `juror0: 63 docs graded | mean F1 90.64 (P 97.40 / R 86.88)`.

### THE HEADLINE OF THIS BATCH (applies everywhere)
**I cut FAR too little. Precision 96–99 on all three documents, recall 54–99.** The annotators segment
much more finely than "one sentence = one full stop." When I am undecided at a candidate site, **CUT**.
A false cut costs the same as a missed cut, and my error profile says every coin-flip I declined was a
loss. Target densities I measured from the keys:
- legal constitution: **~14.7 tokens per segment**
- literary essay-narrative (al-Aqqad): **~16.6 tokens per segment** (median 15)
- plain translated narrative (Tolstoy): **~9.9 tokens per segment** (median 9, max 33)
If a running segment has passed ~12–15 tokens and the next word is a coordinator, cut.

---

### narrative

**RULE — و / ف / ثم / أو / لكن introducing a NEW predication is a BOUNDARY, not a comma.**
This is the single biggest thing I got wrong. I wrote a law saying "coordination continues a sentence"
and it cost me 68 missed cuts on one document.
- `…صاحب أرض ‖ فاقترض بذورا وزرعها ‖ وكان المحصول وفيرا ‖ فسدد في عام واحد…` — I ran all four together.
- `…ليعول أسرته ‖ لكنه كان فقيرا لا يملك أرضا ‖ فكان يردد دائما…` — I ran all three together.
- `…فتوقف وحفر حفرة وشرب ماء من قربته ‖ ثم انحرف يسارا ‖ وتابع سيره بهمة…`
- `…لا يقربونها إليهم ولا إلى نفسها ‖ أو ينظر إليها نظرة القانص الفاتك…` (أو cuts too)
- `…وكأن نزواتها هي القوة الدافعة لها في الفضاء ‖ فإذا دفعتها فهي ناهيك من حركة…`

**RULE — what STAYS joined under و is a short same-subject verb chain with no new weight.**
`فاقترض بذورا وزرعها` · `وذهب إلى السيدة واشتراها منها` · `فأخرج هو الآخر هداياه وقدمها لهم` ·
`فتوقف وحفر حفرة وشرب ماء من قربته` · `تجمع رجال البشكير حول باعوم وأهدوه ثيابا وقدموا له شايا وأعدوا له وليمة`.
Practical test: keep joined while the segment is still short and the verbs are one continuous move;
cut as soon as a new explicit subject, a new adverbial, or a new stage of the action appears.

**RULE — ف before a new consequence/reaction clause almost always cuts.**
`فعرف`, `فجلس`, `فراح`, `فقال`, `فتوقف`, `فسار`, `فقد ظل`, `فقد كان`, `فلا تهمها`, `فتعلم لأول وهلة`,
`فإذا أحجم`, `فلو خلا جانب منه` — all segment-initial in the key. I joined most of them.

**RULE — a one-word segment is normal. Do not refuse it.**
The key gives `ماذا` its own segment (the priest's stunned cry) and `يجوز` its own segment (the narrator's
one-word concession). I explicitly declined both, reasoning "a single-token segment is a bigger bet." Wrong.

**RULE — asyndeton always cuts, and I must not override it on a "that reads like an appositive" hunch.**
`فأوروبا عندها نبي معصوم ‖ كل شيء فيها خير من كل شيء في غيرها` — I saw the asyndeton, called it an
appositive gloss, and declined. The key cut. Same at `وكان صاحبها همام على نقيضها ‖ يهزأ بالعرف` and
`كما هي وثنية في التدين ‖ لا تؤمن بالعصمة الإنسانية`.

**RULE — a causal لأن clause after a completed statement cuts.**
`…أصلح ما تكون مديرة للإضاءة في مسرح تمثيل ‖ لأنها تعلم مواقع الرؤية علما لا خطأ فيه`.

**CONFIRMED (I got these right in narrative):**
- أما … فـ opens a new segment: `أما هذه الفتاة`, `أما الرجل الخبير`, `أما شوبنهور`. ✓
- إذ opens a new segment: `…وإن أرادت أن تقوله ‖ إذ المعهود في المرأة…` ✓ (I marked it med; it was right.)
- إلا أن opens a new segment: `إلا أنه استقر آخر الأمر`, `إلا أنهما حين خرجا` ✓
- Every direct question ends a segment, in narration and inside quoted speech alike:
  `ما هذا الذي ذعر منه الكاهن ذلك الذعر الشديد ‖`, `أتحزن علي إذا مت ‖`, `ماذا يظن هؤلاء الناس ‖`,
  `وما ثمن الأرض التي أختارها ‖`, `أي مقياس هذا ‖`, `كم هكتارا تعني ‖` ✓
- The speech frame is welded to the first sentence of its quote — the colon is not a stop:
  `قال الزعيم ثمن الأرض عندنا ألف روبل في اليوم ‖`, `هتف الزعيم يا لك من رجل متميز ‖` ✓
- Later sentences inside the same turn are separate: `…يا لك من رجل متميز ‖ لقد حصلت على أراض كثيرة جدا ‖` ✓
- Fronted time adverbials open a segment: `ذات شتاء`, `في أحد الأيام`, `بعد الإفطار`, `بعد مدة`,
  `في المساء`, `أخيرا`, `بعد قليل` ✓
- Title / byline / translator-credit are three separate display lines:
  `كم من الأرض يحتاج الإنسان ‖ قصة ليو تولستوي ‖ ترجمة أماني سالم ‖` ✓
- Repeated cries get separate segments: `سأموت بلا ريب ‖ سأموت بلا ريب ‖` ✓

**MY ONE FALSE CUT IN NARRATIVE — asyndeton inside a quoted turn is not automatic.**
`قالت ستبكي ولا شك لا أسألك في ذلك ‖ ولكن كم عبرة يا ترى…` — I cut after `ولا شك`; the key runs it on and
cuts at `ولكن` instead. So inside one speech turn, short asyndetic clauses can stay together; the
coordinator is the more reliable cut site than the asyndeton.

---

### legal

**RULE — `الباب X` / `الفصل X` and its title are ONE line, not two.**
This was 21 of my 40 false cuts. The key reads `الباب الأول الأسس العامة ‖`, `الفصل الثاني الأسس الاقتصادية ‖`,
`الباب الرابع المحكمة الدستورية ‖` as single segments. I split every one of them. I had flagged them med —
the flag was right, the call was wrong. **Never split a Bāb/Faṣl number from the title that follows it.**

**RULE — but a bare ordinal `أولا` / `ثانيا` / `ثالثا` CAN stand alone as its own segment**, with the
name that follows it as a second segment: `… ‖ ثانيا ‖ مدينة عدن ‖ مدينة عدن ذات وضع اقتصادي…`.
(The source is not perfectly consistent about this; treat the ordinal as its own line by default.)

**RULE — an article number that survived the stripping is its own segment.**
`… أحكام عامة ‖ مادة 282 ‖ تجسد الهيئات المستقلة…`. I glued `مادة 282` onto the article body.

**RULE — cut immediately before the FIRST list item, even if the stem ends mid-phrase.**
`يقوم النظام السياسي على أساس ‖ الفصل بين السلطات…` · `تكفل الدولة ‖ العناية باللغة العربية…` ·
`وتكفل له الدولة ‖ الحق في الاسم والنسب…` · `ويتضمن الحق في ‖ اللجوء إلى القضاء…` ·
`ينشأ بقانون ‖ جهاز الشرطة الاتحادي…`. I placed several of these one or two words too late.

**RULE — `ومنهم` DOES introduce an enumerated sub-list, and the stem ends at `ومنهم`.**
`الموافقة على تعيين كبار القيادات المدنية والعسكرية ومنهم ‖ الوزراء ‖ محافظ البنك المركزي ‖ …`.
I read it as an inline comma series and declined to cut. Wrong — that was a deliberate override and it lost.

**RULE — و + a fronted adverbial does NOT start a new segment in legal prose.**
`…بأي صورة من الصور وفي الأحوال التي ينص القانون فيها…` and `…أغلبية الأصوات الصحيحة وفي حال وفاة أحد المترشحين…`
both run on. I invented a "fronted-adverbial paragraph break" rule; it is false for legal.
(Contrast narrative, where ف + fronted adverbial — `فإذا دفعتها` — does cut.)

**RULE — `أما` does NOT start a new segment in legal prose.**
`…ولا يجوز تقديمه في نفس دورة الانعقاد أما إذا وافق مجلس النواب…` runs on. This is the exact opposite of
narrative, where أما always cuts. **أما is topic-dependent: cut in narrative, do not cut in legal.**

**RULE — a bare fronted time adverbial attaches to the clause that FOLLOWS it, not the one before.**
`…وفقا لنظام القائمة النسبية المغلقة ‖ بعد الدورة التشريعية الأولى يمثل الجنوب…` and
`…بما فيها الجيش والأمن ‖ خلال الدورة الانتخابية الأولى يجب معالجة عدم المساواة…`.
I attached both adverbials backwards and produced a false cut plus a missed cut each time.

**RULE — do not cut before a quoted formula introduced by كالتالي / الآتي.**
`صيغة اليمين الدستورية كالتالي quot أقسم بالله العظيم…` is one segment. Nor before the closing invocation:
`…وفق برنامج زمني محدد والله الموفق ‖` runs on.

**RULE — an inline comma-series inside a single numbered item is NOT sub-segmented.**
`العملة سك النقود السياسة النقدية` is one item; `المحميات الطبيعية والأنواع النادرة` is one item.
I cut inside both. So: short parallel noun phrases *within* a numbered item stay together — the cue that
they are separate items is that each is a full, weighty phrase and the list stem announced them
(الآتية / بالآتي / ما يلي / فيما يلي / ومنها / ومنهم).

**CONFIRMED (the legal law that worked — F1 97.6, recall 98.9):**
- The unit is the constitutional line: heading line, article rubric, article body, or one enumerated item.
- Article rubrics standing before their body are their own segments, betrayed by immediate repetition:
  `النظام السياسي ‖ يقوم النظام السياسي على أساس…`, `الحق في الكرامة ‖ الكرامة حق لكل إنسان…` ✓
- Inside an article body, و/ف/كما coordination CONTINUES the segment — the opposite of narrative.
  `الشريعة الإسلامية مصدر التشريع والاجتهاد في تقنين أحكام الشريعة مكفول حصرا للسلطة التشريعية` is one segment. ✓
- Asyndeton starts a new article: `…وطرق إدارتها ‖ تراعي الأحزاب تمثيل المرأة…` ✓
- List stems ending in الآتية / بالآتي / ما يلي / فيما يلي / ومنها close a segment, and each item closes one. ✓
- A resumptive/circumstantial verb sharing the previous subject does NOT cut:
  `الشعب مالك السلطة ومصدرها يمارسها بشكل مباشر…` ✓

---

### CROSS-TOPIC RULE OF RECORD (batch 1)
**The same connective behaves oppositely by topic.** In legal prose و/ف are within-segment commas;
in narrative they are segment starts. أما cuts in narrative and does not cut in legal. So the first
thing to fix for any document is the topic and its segment density, then apply the connective policy
that goes with it — do not carry one document's coordination rule into the next.

---

## BATCH 2 — docs: doc_405d5fba81e0 (narrative), doc_5b0751f40176 (narrative), doc_7bc0656a48ce (narrative)
Scores: 83.6 (P 73.8 / R 96.3) · 85.6 (P 78.4 / R 94.1) · 77.2 (P 67.7 / R 89.8). 84 errors.
Grader line: `juror0: 66 docs graded | mean F1 90.26 (P 96.31 / R 87.18)`.

### THE HEADLINE OF THIS BATCH — I OVERCORRECTED FROM BATCH 1 AND MUST STOP
**71 of my 84 errors were FALSE CUTS. Precision 67–78, recall 90–96 — the exact mirror image of batch 1.**
Batch 1 told me "when I am undecided at a candidate site, CUT." I carried that into three narrative
documents and invented ~25 boundaries per document. The batch-1 headline was right about **one** site
type only — a coordinator that joins two independent EVENTS — and I generalised it to subordinators,
حال clauses, appositives, explicatives, noun series and same-subject verb chains, where it is false.

**REPLACEMENT COIN-FLIP RULE (this supersedes "when in doubt, CUT" — the old rule is kept above as the
record of how I learned it, but it is no longer the tie-breaker):**
- Undecided at a MAIN-clause juncture — new event, new explicit subject, new stage/topic → **CUT**.
- Undecided at a subordinator (لأن/إذ/بينما/بعدما/رغم/إذا/مما/لـ-result/حيث), a حال clause (وهو/وهي +
  verb), a relative or appositive, an explicative (وهي أن/هي أن/أي/وهذا ما/وهو ما), a coordinated
  noun series, or a same-subject verb chain → **DO NOT CUT**.

**Density recalibration — the 9.9 anchor is what dragged me under.** All three of my derived "laws"
quoted the Tolstoy key's 9.9 tokens/segment and reasoned toward it. The keys here:
- doc_405d5fba81e0: 82 cuts / 1140 tok = **13.9** (I produced 10.7)
- doc_5b0751f40176: 85 cuts / 1050 tok = **12.4** (I produced 10.3)
- doc_7bc0656a48ce: 49 cuts / 770 tok = **15.7** (I produced 11.9)
**Narrative in this corpus runs 12–16 tokens/segment.** Tolstoy's 9.9 is the staccato-folk-tale outlier,
not the narrative norm. When my draft comes out under ~12 for narrative prose, I am over-cutting.

### THE ONE STRUCTURAL LAW OF THIS BATCH
**A subordinate clause is trailing baggage of the segment BEFORE it; the boundary falls at the next
MAIN clause, which is usually و + finite verb.** I was cutting one clause too early, every time — at the
subordinator — and then running on through the real boundary. Four proofs, each a false cut + a missed
cut in the same place:
- `…أثارت المزيد من الدهشة إذ اختارت اتجاها آخر ‖ واتجهت إلى مشتى جديد…` (I cut before إذ, not before واتجهت)
- `…تتعرض إلى جفاف في بعض السنين لتنتشر المجاعات ‖ وتهرب الحيوانات المائية…` (I cut before لتنتشر)
- `…لمدة عام إذا أمكن الاستفادة منها ‖ ومن هذه الحقيقة تنتشر الآن مشاريع…` (I cut before إذا)
- `…استلزمت مراقبتها ‖ ثم اكتشاف قفزات بعضها من الأحواض ‖ وسيرها على أقدام غريبة…` (see masdar rule below)

---

### narrative (batch 2 — the "do NOT cut" catalogue)

**RULE — و + a same-subject verb chain does NOT cut, however long the chain and however new the stage.**
This was my largest single class of false cuts (≈20 sites). Batch 1's "short same-subject chain stays"
was right but I limited it to *short*; length is not the trigger, a NEW SUBJECT is.
- `…من المداخن التي تعج بها ودخانها السام وانتقلوا إلى بلدة ريفية…` · `…وأقمارا وشموسا وترسم تنانين وأقزاما…`
- `وصل لاكي إلى مشارف الغابة ووقف هناك يزوم ويزمجر…` · `خرج لاكي من مخبئه وسار خائفا حذرا…`
- `اشتد غضب لاكي وهجم على الحكيم أرنوب وراح يعضه بعنف…` · `…حتى نشف حلقه وتيبس تماما وأحس من جديد بعطش أشد`
- `…أصيب بغرور شديد وأخذ ينبح ويصرخ ويقول أنا أقوى الأقوياء ‖` (chain + speech frame + first quoted line = ONE)
- `…الزرزور الذي يعيش صيفا في الجزر البريطانية وشمال فرنسا ويهاجر إلى المناطق الجنوبية…`

**RULE — و + a NOMINAL/descriptive predicate about the same referent does NOT cut.**
Description of one entity is one segment, even when the و introduces a fresh explicit subject.
- `…هزيلة وناتئة العظام مثل سمندل الماء الصغير وشعرها خفيف كالضباب الرقيق…`
- `…فروع الأشجار المتدلية ثعبانا مكتملا وله عينان لامعتان ولسان مشقوق يتحرك بسرعة ‖`
- `شاهد الفيل قادما من بعيد انزعج وأصيب بفزع شديد واقشعر بدنه وتدلى ذيله ووقف متخشبا…` (بدنه/ذيله are new
  subjects but one reaction event)

**RULE — parallel `وكان X … وكان Y …` frames run on. This KILLS my doc-2 law "wa-kāna + new subject
always opens a segment."** What changed and why: I wrote that law from batch 1's Tolstoy feel; this key
contradicts it three times, so the law is void — وكان is just a coordinator and obeys the ordinary test.
- `كان الضوء يزداد بريقا وكان الصوت يزداد نعومة ورقة ‖ وحين وصل لاكي…` (the cut is at the fronted وحين)
- `…يزداد طولا ‖ يتضخم ‖ وكانت عيناه تتسعان وكان هو نفسه يكبر ‖`
- `وكان ذيله ينكمش ويصغر وكان جسمه كله يصغر ‖ يصغر حتى عاد…`

**RULE — a bare-noun coordinated series never cuts, at و or at ثم.**
- `…وأسيجة شجيرات مليئة بالأزهار ثم التوت والخوخ الشوكي والزعرور البري وورود النسرين…`
- `…ما يشبه الرءوس العديمة الملامح وجذوعا ما تشبه الأذرع…`
**BUT — a series of HEAVY event-denoting masdar phrases IS segmented like clauses.** This is the one
place the key cuts a series, and I missed both:
- `الإجابة على هذا السؤال استلزمت مراقبتها ‖ ثم اكتشاف قفزات بعضها من الأحواض ‖ وسيرها على أقدام غريبة…`
The cue: each item is a full event with its own complements, not a name on a list.

**RULE — do NOT cut before لأن. (AMENDMENT to batch 1's "a causal لأن clause after a completed statement
cuts.")** What changed and why: batch 1 gave one al-Aqqad essay instance; this batch gives two clean
counterexamples in plain narrative, so the default flips to NO CUT and the al-Aqqad case is now marked
as the literary-essay exception, not the rule.
- `…ينهونها عن فعل هذا ويأمرونها بتجنب ذلك لأن هناك حربا دائرة ‖ كانت الحياة…`
- `…حدس ينبئها باقتراب الأذى لأنها شعرت أن الصلوات التي تتلوها كانت تذهب…`
Same for the ولأن…فـ pair, which is ONE unit: `ولأن فرس النهر رغم ضخامته يتميز بالوداعة والتسامح فهو لا يرفض…`

**RULE — do NOT cut before إذ. (AMENDMENT to batch 1's CONFIRMED "إذ opens a new segment.")**
What changed and why: batch 1 confirmed it once in al-Aqqad; this batch refutes it three times across
three different narratives, so إذ is now filed with لأن as explanatory baggage of the preceding clause.
- `كان والدها غائبا عن المنزل إذ كان طيارا يشارك في الحرب…`
- `…هزيلة وقبيحة المنظر إذ ليس لها أصحاب وإنما تنطلق في الشوارع…`
- `…فقد أثارت المزيد من الدهشة إذ اختارت اتجاها آخر ‖ واتجهت…`

**RULE — do NOT cut before بينما / بعدما / رغم / رغم أن / حيث / مما / إذا / لـ-of-result.**
- `…وسط صواعق متعرجة من ضربات البرق بينما يراقبه من مدخل يقود إلى كهف مظلم…`
- `…وراحت تلعب كعادتها وتمرح وترقص بينما ظل لاكي وحده يخبط الأرض…`
- `…حتى يصلوا إليها ويدمروها بعدما ألقوا بوالديها داخل حفرة خضراء…`
- `…يقف على ظهر فرس نهر عملاق بقبول وتسامح رغم أنه يستطيع القضاء عليه…`
- `رغم جميع سبل الحماية للغوريلا والشمبانزي في أفريقيا فإن الصيادين يخترقون أسوار الحماية…` (protasis+فإن = ONE)
- `الأنثى تضع بيضها مرة كل شهر مما أسفر عن سيطرتها على معظم البحيرات…`
- `…أمكن إنقاذهما بعد قتل الأم ليجدا في مركز رعاية الأيتام…`
*Known exception, recorded honestly:* بينما DID cut once, where it pivots to a wholly new topic rather
than a simultaneous action — `يعتمد في غذائه على النباتات المائية ‖ بينما التماسيح…`. Topic pivot cuts,
simultaneity does not.

**RULE — a حال clause introduced by وهو / وهي + verb stays inside the segment.**
- `…صورة مثيرة ورائعة ل أودين أثناء صيده البري وهو ينطلق على صهوة جواده…`
- `…قراءتها في وقت متأخر من الليل وهي تخفي مصباحا أسفل أغطية الفراش أو بالدفع بالكتاب…`

**RULE — explicative and resumptive comments stay attached: وهو ما / وهذا ما / وهي أن / هي أن / أي.**
- `…وأن تعلم الأولاد الأذكياء وهو ما كان محظورا على النساء المتزوجات…`
- `…كي تضفي عليها الحياة وهذا ما فعلته الطفلة مرارا وتكرارا ‖ وفي كل…` (the cut is at the fronted وفي كل)
- `برزت المفاجأة الثانية وهي أن عناصرها الوراثية قادتها إليه ‖`
- `…يرجع إلى حقيقة مؤسفة هي أن بعض الأنهار الصغيرة…`
- `…تنتج 14 ألف كيلو وات من الطاقة كل عام أي ما يفوق احتياجات المنزل…`

**RULE — أو joining parallel alternatives inside one statement does NOT cut. (AMENDMENT to batch 1's
"أو cuts too.")** What changed and why: batch 1's أو site was a new predication in an essay; here أو
twice joins alternatives inside a single thought, so the rule is narrowed to "أو cuts only when it
opens an independent predication with new weight."
- `…يمكن لوهلة أن تبدو كلبا رابضا ومزمجرا أو يمكن أن يبدو أحد فروع الأشجار ثعبانا…`
- `…وهي تخفي مصباحا أسفل أغطية الفراش أو بالدفع بالكتاب عبر الفتحة الضيقة…`

**RULE — a SHORT لكن/ولكن clause that just reverses the immediately preceding predicate about the same
subject does NOT cut. (AMENDMENT/narrowing of batch 1's "لكن is a boundary.")** What changed and why:
batch 1's لكن sites were full new predications; three short reversals here are run on, so length and
subject-continuity now gate the rule.
- `حاولت الطفلة النحيلة التجاوب مع الصورة لكنها أخفقت ‖` · `…من الدمار الوشيك ولكنها تجهل أنها تعلم ذلك ‖`
- `…هو مبعث الرضا الغامر ولكنها لم تستطع التعبير عن ذلك لفظا ‖`
- Parallel negations likewise run on: `لم ينته كما انتهت عوالم أخرى عديدة ولم تجتحه الجيوش ولم تقصفه وتساوه بالوحل ‖ ولكن…`
  — note the key DOES cut at that final ولكن, after the long parallel run. Long run then ولكن = cut;
  two-word reversal = no cut.

**RULE — أما…فـ used as the second half of a two-part contrast does NOT open a segment; the cut comes
AFTER it. (AMENDMENT to batch 1's "أما always cuts in narrative.")** What changed and why: batch 1's
أما sites were paragraph-initial topic switches; this one is welded to the sentence it contrasts with.
- `وقد حملت قصة بنيان رسالة ومعنى واضحين أما أسجارد والآلهة فلم تكن كذلك ‖ فهذا الكتاب…`

**RULE — a question or quote is welded to the frame that announces it, and a short quoted turn is not
split.** Batch 1's "every direct question ends a segment" is about where it ENDS, not where it starts.
- `وهنا برز السؤال الحائر كيف وصلت السمكتان إلى هذا المجرى المائي البعيد ‖`
- `…وهو ينط ويقفز ويقول أنا جميل أنا قوي وعظيم ‖ ثم نبح…` (I split the two brags; the key runs them on)
- Inside one speech turn, و/ثم + a further promise runs on: `فلماذا لا تأتي لتعمل في بيتي الجديد خادما
  وسوف أجعل زوجي يقدم لك أفضل أنواع الطعام ‖` · `سأشرب من العين المسحورة مرة أخرى ثم أبتلع كل هذه الحيوانات…`

**RULE — an asyndetic APPOSITIVE that re-names or unpacks the NP just given stays attached.**
This narrows batch 1's "asyndeton always cuts" — asyndeton between two PREDICATIONS cuts; asyndeton
between a head NP and its own gloss does not.
- `كانت تقص حكاياتها الخاصة وهي تسير عبر الحقول حكايات عن فرسان جامحين ومستنقعات عميقة…`
- `…وهو يعظ مجموعة من الحيوانات الوديعة المنتبهة أرانب وظبي وسنجاب وطائر عقعق…`

**RULE — an asyndetic descriptive/circumstantial VERB continuing the same NP does not cut** (very common
in magazine science prose, and 5 of my false cuts there):
- `تبين امتلاكها لعضو غريب في جسمها يشبه الرئة يتيح لها الخروج من الماء والمشي على الأرض لمدة تصل إلى 12 ساعة
  تعود بعدها إلى الماء للتنفس بالخياشيم ‖`
- `…خشن الجلد لونه رمادي يعتمد في غذائه على النباتات المائية ‖`
- `…يتحول إلى هيليوم تنطلق منه الطاقة الحرارية الرهيبة إلى الفضاء…`
- `…مئات الخلايا أو مجمعات حرارة الشمس تحول طاقة الشمس إلى مصدر حراري دائم…`
- Trailing PPs likewise: `…وساعات اليد وغيرها عن طريق خلايا تتكون من السيليكون…` · `…آفاق المستقبل من بينها المنزل الذي نراه في الصورة ‖`

### narrative — the few places the key cuts MORE finely than I did (13 missed)

**RULE — bare asyndetic juxtaposed finite verbs (staccato repetition for effect) each get their own
segment.** This is the one place these keys go very short, and I smoothed it over:
- `كان ذيله يكبر ‖ يزداد طولا ‖ يتضخم ‖` · `وكان جسمه كله يصغر ‖ يصغر حتى عاد إلى حجمه الطبيعي ‖`
(but a repetition governed by one verb stays: `ظل ينبح ينبح ‖`)

**RULE — و + أن introducing a SECOND heavy complement clause DOES cut. This kills my doc-2 law
"a coordinated complement clause under أن stays inside."** What changed and why: proved wrong at first use.
- `…كانت تدرك طول الوقت رغم ضخامته أنه كلب ‖ وأنها كانت تسخر منه بسبب هذا القيد…`

**RULE — و + قد + perfect opening a new predication cuts** — `…كان الكتاب باللغة الألمانية ‖ وقد اقتبس من
أعمال الدكتور دبليو فاجنر ‖`. (Do not over-apply: وقد + a negated imperfect continuing the same description
runs on — `…بحثا عن غذائها وقد لا تجد ما تأكله فتنام آخر الليل…`.)

**RULE — a bare naming/label NP that starts a new topic gets its own segment** (as against the appositive
rule above, where the NP re-names what precedes):
- `…وعيون زرقاء صافية وكأنه إله ‖ شجرة المران الرمادية إجدراسيل ‖ كانت الطفلة…`
- `…ثم وصوله إلى نهاية ‖ نهاية حقيقية نهاية العالم ‖` (I cut one word late — the bare `نهاية` closes,
  and the whole expansion `نهاية حقيقية نهاية العالم` is one segment)

---

### CROSS-TOPIC RULE OF RECORD (batch 2)

**CONFIRMS AND EXTENDS the legal heading rule to narrative: a section NUMBER and the title that follows
it are ONE display line.** In legal I learned `الباب الأول الأسس العامة ‖`; here the same key logic gives
`نهاية العالم ‖ ١ البداية ‖ كانت الطفلة…` — I split the numeral from `البداية`. This is now a general
law, not a legal one: **never split a chapter/section number from its title.**

**"CUT WHERE THE ORIGINAL PUNCTUATION WAS" IS TOO COARSE — the keys cut at full stops, not at commas.**
That was the law I wrote for doc_7bc0656a48ce and it gave my worst score of the batch (P 67.7). Arabic
journalistic prose comma-separates every clause juncture; the annotators do not. Restate the law as:
**cut where the original would have had a FULL STOP** — i.e. at a complete predication boundary — and
treat every comma-grade juncture (subordinate clause, حال, apposition, series, same-subject chain) as
internal.

**What still holds from batch 1, unchanged and reconfirmed here:** و/ف/ثم between two independent EVENTS
with new subjects are boundaries in narrative (this is why recall stayed 90–96 — I did not lose those);
fronted adverbials open a segment (`وحين وصل لاكي`, `وفي كل`, `ومن هذه الحقيقة`, `وهنا برز`); asyndeton
between two predications opens a segment; heading/byline lines are one display segment each.

---

## BATCH 3 — docs: doc_666e6f739000 (narrative), doc_78b2ed132e2f (narrative), doc_f41918b2700e (narrative)
Scores: folk-tale king/vizier F1 92.8 (P 96.7 / R 89.2) · magazine page F1 90.8 (P 91.5 / R 90.0) ·
children's tale "flying horse" F1 82.1 (P 84.2 / R 80.0). **41 errors: 25 MISSED, 16 FALSE CUTS.**
Grader line: `juror0: 69 docs graded | mean F1 90.18 (P 96.07 / R 87.14)`.

### THE HEADLINE OF THIS BATCH — MY COUNT IS NOW RIGHT; MY PLACEMENT IS WRONG
Cuts made vs. cuts in the key: 60 vs 65 · 59 vs 60 · 57 vs 60. After batch 1 (way too few) and batch 2
(way too many), **the density calibration has converged — and it is no longer where the errors live.**
On doc_f41918b2700e I was within 3 cuts of the key and still lost 21 sites: I put the boundary in the
wrong place. **The remaining failure is boundary PLACEMENT around a subordinate or adverbial head, and
a systematic mis-sort of which و-junctures are clause-grade and which are comma-grade.**

**Density amendment — 9.9 was never an outlier.** Batch 2 wrote "narrative runs 12–16 tok/segment;
Tolstoy's 9.9 is the staccato-folk-tale outlier." All three keys here run **10.3, 10.7, ~9.5**. What
changed and why: three documents in one batch is not an outlier, it is a register. The corpus has TWO
narrative registers and I must identify which one I am in before I place a single cut:
- **adult / literary / magazine-feature narrative → 12–16 tokens per segment** (batch 2 docs)
- **children's & folk tale, dialogue-heavy tale, heading-heavy magazine page → ~10 tokens per segment**
Cues for the ~10 register: simple clause-per-event syntax, a translated or read-aloud tale, refrains and
repetitions, heavy quoted dialogue, display headings. In that register **every و + a complete clause is
its own beat.** In the 12–16 register it is not.

---

### narrative (batch 3)

**RULE — subordinators come in TWO classes, and I must sort them before placing the boundary.
This SPLITS batch 2's one structural law ("a subordinate clause is trailing baggage of the segment
BEFORE it").** What changed and why: batch 2 proved the backward half on لأن/إذ/بينما; this batch proves
a forward half exists, and I lost a matched false-cut + missed-cut pair by applying the backward rule to
a forward subordinator.
- **BACKWARD-attaching (explanatory): لأن · إذ · بينما · حيث · مما · رغم أن · بعدما** — they close the
  segment they follow; the boundary is at the next main clause. (Unchanged from batch 2.)
- **FORWARD-attaching (culminative / temporal-advancing): حتى · ولما · وحين · وإذا** — they OPEN the next
  segment and drag their consequence chain in with them.
  `…ثم سار في طريق طويل ملتو ‖ حتى وصل إلى بيت الساحر فوقف أمامه ورفع يده ليدق الباب ‖` — I did the exact
  opposite: ran on through `حتى`, then cut before `فوقف`. Two errors, one misplacement.
  `…وحدة الذكاء ‖ حتى أن الوزير كالدهار اكتسب عن جدارة لقب…` — حتى أن of result also opens.

**RULE — a segment opened by a fronted adverbial or a forward subordinator runs to the END of its scene:
do NOT cut inside it at ف or و, even at a new explicit subject.** This is the corollary of "fronted
adverbials open a segment" that I did not have, and it cost three false cuts.
- `وأخيرا وقفت السجادة ورأى الضابط نفسه في قاعة فسيحة أمام الساحر ‖` — ONE segment. I cut before `ورأى`
  because الضابط is a new subject. The scene opened by `وأخيرا` was not finished.
- `وأحيانا كانت تهاجمهم الحيوانات المفترسة كالأسود والذئاب فتحدث بينهم وبينها معارك شديدة ‖` — ONE segment.
  I cut before `فتحدث`; ف-of-consequence does not cut when the head adverbial is still open.
- `حتى وصل إلى بيت الساحر فوقف أمامه ورفع يده ‖` — same shape.
So: **ف opens a new reaction only at the start of a fresh MAIN-clause beat, never immediately after an
adverbial/subordinate head.**

**RULE — everything inside the scope of a subordinate clause is shielded: no و / ثم / وإنما inside a
لأن-clause or an أن-complement ever cuts.** Three false cuts, all the same mistake.
- `…هلك لأن طريقها صعب وبيننا وبينها صحراء واسعة ونهر كبير وبحر…` — I cut before `وبيننا`.
- `وطلب منه أن يعد فرقة مكونة من مائة جندي وأن يرسل معهم أحد الضباط…` — I cut before `وأن يرسل`.
- `…أن يعبروا كل ما في الطريق من صحاري وبحار وجبال ثم يحضروا له الحصان الطيار…` — I cut before `ثم`.
This also RECONCILES batch 2's `…إذ ليس لها أصحاب وإنما تنطلق في الشوارع…` (no cut): that وإنما was under
إذ. At main-clause level وإنما DOES cut — see the next rule.

**RULE — و + a verbless / fronted-PP clause cuts ONLY when it brings a NEW ENTITY as its subject.**
This is the single cleanest new discriminator of the batch; it decided six sites, four of them mine.
- NO CUT — the predicate is about a referent already in play:
  `…فيها من الخيرات أشكال وألوان وعنده كل ما يخطر على البال…` (the king, already the topic) ·
  `فنحن كما تعلم يا مولاي في موسم الحصاد وعلينا أن نحسم الأمور بين المزارعين والتجار…` ·
  `…إلى المدن المجاورة وأمامنا كذلك ‖` — I cut before `وعلينا` and before `وأمامنا`, reading them as an
  enumerated list of obligations. They are coordinated predicates of one statement.
- CUT — a new entity arrives as subject:
  `…في وسطها سجادة صغيرة مربعة عليها نقوش غريبة ‖ وحولها كراسي أشكالها عجيبة ‖` (كراسي is new) ·
  `…فرأى الجبل عاليا عاليا ‖ وطريق الصعود إليه صعبا ‖` (a second object of رأى, but a new entity — the key
  cuts even here) · `…في خلية النحل ‖ وتحيط بها مادة لاصقة ‖` · `…حتى ابتعدوا عن بلادهم ‖ وغابت بيوتهم عن العيون ‖` ·
  `…ثم ساروا إلى الأمام أياما وأياما وأياما ‖ والصحراء لا تريد أن تنتهي…` (و + new nominal subject cuts even
  when it reads as a حال clause — this narrows batch 2's "حال clause stays inside").

**RULE — و + a same-subject verb chain DOES cut in the ~10-token register when the conjunct is a complete
clause with its own complements. This AMENDS batch 2's "و + same-subject verb chain does NOT cut, however
long the chain and however new the stage."** What changed and why: batch 2's absolutism ("however new the
stage") is refuted eight times here; batch 1's original condition ("cut as soon as a new stage appears")
was right and I should not have thrown it away. The trigger is not the subject — it is whether the
conjunct is a full clause and a new beat.
- `…كان دائما يقف بجانبهم ويرعى شئونهم ‖ ويفصل في قضاياهم بحكمته وسعة صدره…` — the key runs the two SHORT
  conjuncts together and cuts before the HEAVY third. Weight decides.
- `ركب الملك والوزير الحكيم جواديهما ‖ وأخذا يتجولان في الحقول ويستمتعان…` — inchoative أخذ/بدأ/راح +
  imperfect = a new stage = cut.
- `فخرج الضابط من الباب ‖ ونزل من أعلى الجبل ‖ وسار في طريقه إلى المدينة ‖` — three motion verbs, same
  subject, THREE segments. I wrote one. This is the clearest proof that batch 2's rule is register-bound.
- `ثم نادى النعمان قائد جيشه ‖ وطلب منه أن يعد فرقة…` · `وتعتبر العين من المناطق الزراعية في البلاد ‖
  وتنتج محاصيل وفيرة من الخضروات والفاكهة والنخيل ‖` (gazetteer style: each و + predication is a segment).
What still runs on: bare conjuncts with no complements of their own, and sub-actions of one single move
(`فوقف أمامه ورفع يده ليدق الباب`, `ويستمتعان بمشاهدة المزارع`).

**RULE — inside a quoted turn, و + a new predication is a boundary exactly as in narration. This NARROWS
batch 2's "inside one speech turn, و/ثم + a further promise runs on."** What changed and why: batch 2 had
one same-subject continuation of a single act; four sites here are new predications and all four cut.
- `…من بلاد الأعاجيب ‖ ولن أرتاح حتى أحصل عليه ‖` · `…لم أنم طوال الليلة الماضية ‖ وأشعر بالإرهاق الشديد…` ·
  `إنني مرهق جدا ‖ ولن يستفيد برأيي ومشورتي أي طرف من الأطراف ‖` · `فقد كرهت هذه المواكب التي تقيدني ‖ وأحب
  أن أشعر بالحرية…`
Two useful tells inside the tells: a **tense/aspect shift** (perfect/negated-past → imperfect state:
`لم أنم ‖ وأشعر`, `كرهت ‖ وأحب`) and a **new explicit subject** (`ولن يستفيد … أي طرف`).

**RULE — ولكن: cut when its clause is a new beat that itself gets continued; do NOT cut when it completes
a thwarted-attempt frame. REFINES batch 2's "short لكن reversal does not cut."** What changed and why:
batch 2 gated the rule on length, and length does not predict these three sites — continuation does.
- CUT: `فقام من سريره ليبدأ يوما جديدا من العمل ‖ ولكنه شعر بالإرهاق والملل ‖ فهو لم يحصل على…` — the ولكن
  clause has its own ف-explanation hanging off it, so it is a segment.
- NO CUT (the frame "X opened his mouth to speak, but before he could…" is ONE beat, and this document
  uses it twice as a refrain — I cut both):
  `فتح الضابط فمه ليتكلم ولكن قبل أن ينطق بحرف واحد سمع الساحر…` ·
  `ففتح الضابط فمه ليتكلم ولكنه أحس السجادة تتحرك تحت قدميه ‖ ثم رآها ترتفع به…`
- NO CUT: `فنظر الضابط ولكنه لم ير أحدا ‖` (bare reversal — batch 2 confirmed).

**RULE — وإنما after a negation CUTS at main-clause level.** My derived law called the `لم…وإنما`
correlative internal; it is not.
- `فنظر الضابط ولكنه لم ير أحدا ‖ وإنما شعر بالسجادة الصغيرة تتحرك تحت قدميه…`

**RULE — بالإضافة إلى opening an additive expansion CUTS.** My derived law listed it as internal. New.
- `…وأكثر من 100 ألف شجرة وشجيرة في ربوعها وضواحيها ‖ بالإضافة إلى مدينة الألعاب العالمية التي تشغل…`

**RULE — وهي / وهو + a definite NP predicate (a full equational sentence) CUTS. NARROWS batch 2's
"explicative وهي stays attached."** What changed and why: batch 2's sites were `وهي أن` / `وهو ما` gloss
of a preceding noun, and حال `وهو + imperfect`; a standalone equational clause is a different animal.
- `…جنوب شرقي العاصمة أبو ظبي ‖ وهي المدينة الثانية في إمارة أبو ظبي ‖`
Still internal: `وهي أن` · `وهو ما` · `وهذا ما` · `وهو + imperfect` (حال).

**RULE — an asyndetic descriptive verb whose subject is the NP just introduced at the END of the previous
clause starts a new segment (topic shift). NARROWS batch 2's "asyndetic descriptive verb continuing the
same NP does not cut."** What changed and why: batch 2's cases continued the MAIN topic; here the sentence
hands off to a sub-entity and the following sentences stay with it.
- `…يتميز باحتوائه على أعضاء كهربائية ‖ تتكون من خلايا خاصة مرتبة بشكل يشبه قرص الشمع…` — and the next
  sentence is `والأعضاء الكهربائية غنية بالأوعية…`, confirming the topic has moved to the organs.

**RULE — ثم + a same-subject verb continuing the history of ONE entity does NOT cut in expository prose.**
- `…ضرورية للحماية من الأعداء ثم استعملت سجنا في أيام الحكم البريطاني ‖` (one tower, one history) — I cut.
Contrast the ~10-token tale, where ثم IS a beat: `…أحس السجادة تتحرك تحت قدميه ‖ ثم رآها ترتفع به…`.
Same connective, opposite verdict, decided by register — the batch-1 cross-topic law again.

**RULE — a fronted PP predicate + a list of bare masdar/noun subjects is ONE verbless sentence. Do not
segment the list.** Four false cuts in one place — my worst single cluster of the batch.
- `ومن أهداف ثورة 23 يوليو القضاء على الاستعمار وأعوانه القضاء على الإقطاع القضاء على الاحتكار وسيطرة رأس
  المال إقامة جيش وطني قوي ‖` — ONE segment. I made five.
This CONSTRAINS batch 1's legal rule "cut before the first list item and one per item": that applies only
when the source visibly enumerated — a numbered/bulleted item, or a stem ending in
`ما يلي / الآتية / بالآتي / فيما يلي / ومنها / ومنهم`. Asyndetic parallel masdars after a bare `ومن أهداف…`
are an inline series, and batch 1's "a bare-noun series inside one item is not sub-segmented" governs.

**RULE — a presentative / announcement formula closes its own segment; what it announces starts a new
one.** Extends the batch-1 legal "list stem closes a segment" into narrative.
- `…إني أعرف ما تريد أن تقول ‖ وإليك الجواب ‖ السر الغريب الذي لا يوجد إلا في بلاد…` — I welded
  `وإليك الجواب` to the answer.

**CONFIRMED — the laws that worked, no errors on any of them in three documents:**
- Front matter / display lines are one segment each (series imprint · title · byline · edition; page
  banner · إعداد byline · headline · caption · card field). ✓
- The speech frame is welded to the FIRST sentence of its quote: `قاطعه الملك قائلا اسمع يا حكيم ‖` ✓
- Every direct question closes a segment, in narration and inside quoted speech alike. ✓
- Relative clauses (`التي` / `الذي` / `والتي`), adjective stacks, appositives and purpose `لـ` (`ليدق`,
  `ليتكلم`, `ليبدأ`) are internal. ✓
- Bare-noun coordinated series never cut: `صحاري وبحار وجبال` · `الخضروات والفاكهة والنخيل`. ✓
- ف of consequence opening a fresh main-clause beat cuts: `فأخذ` · `فدهش` · `فوجد` · `فنظر` · `ففتح` · `فخرج`. ✓
- و + a fronted PP reopening the narration cuts: `…في 19 أكتوبر 1954 ‖ وبمقتضاها تم جلاء آخر جندي بريطاني…` ✓
  (narrative/expository only — batch 1's legal rule that و + fronted adverbial does NOT cut still stands for legal.)

---

### CROSS-TOPIC RULE OF RECORD (batch 3)

**THE ORDER OF OPERATIONS IS NOW FIXED. (1) Identify topic. (2) Identify REGISTER inside the topic and
its density band (~10 vs 12–16 for narrative). (3) Bracket every subordinate clause and decide its
DIRECTION — backward-explanatory or forward-culminative — before looking at any coordinator. (4) Only
then sort each و / ف / ثم into clause-grade or comma-grade.** Every one of my 41 errors was a step-3 or
step-4 error; none was a step-2 error any more.

**THE و-SORT, stated once for the whole record.** و is clause-grade (CUT) when it brings a new entity as
subject, a complete clause with its own complements in the ~10-token register, an inchoative new stage,
a tense/aspect shift, or a fronted PP. It is comma-grade (NO CUT) when it predicates about a referent
already in play, sits inside a subordinate scope, coordinates bare nouns, completes a single move, or
falls inside a scene already opened by an adverbial head.

**A subordinate or adverbial head is a MAGNET, not a wall.** Backward subordinators pull the boundary
after themselves; forward subordinators and fronted adverbials pull the following main clause in front of
themselves. When attachment is genuinely two-way (`وساروا حتى ابتعدوا عن بلادهم ‖` attaches back, but
`‖ حتى وصل إلى بيت الساحر فوقف…` attaches forward), **attach in the direction that keeps both segments
near the document's measured density.** That tie-breaker resolved both حتى sites correctly after the fact.

---

## BATCH 4 — docs: doc_3484c02411e9 (narrative), doc_51f6f776f3c7 (narrative), doc_9ad9ba0d12d4 (narrative)
(the prompt labelled this "batch 3 of 37"; it is the FOURTH set of three I have absorbed — batches are
numbered here in the order I received them, and nothing above is renumbered.)
Scores: Tahrir stream-of-consciousness F1 87.8 (P 82.4 / R 93.8) · Sinai travel diary F1 89.5 (P 82.3 /
R 98.1) · forum opinion post F1 92.6 (P 88.0 / R 97.8). **36 errors: 30 FALSE CUTS, 6 MISSED.**
Grader line: `juror0: 72 docs graded | mean F1 90.17 (P 95.58 / R 87.53)`.

### THE HEADLINE OF THIS BATCH — DESCRIPTION IS ONE SEGMENT; I KEEP CUTTING IT INTO SENTENCES
30 of 36 errors were false cuts, precision 82/82/88. I have now over-cut narrative in two of four
batches (2 and 4) and the driver is identical both times, so it is a standing defect, not a wobble:
**I derive an elaborate document-specific "wa-policy" that assigns clause-grade status to FORMAL cues —
a fronted element, ف-of-consequence, a new grammatical subject, a complete clause with complements — and
the annotators cut on SEMANTIC grounds only: a NEW EVENT or a NEW TOPIC.** Every formal cue I trusted
appears on both sides of the key's boundary line, so no formal cue can decide a site by itself.

**The operational form of the fix.** Before accepting any cut, ask: *does the clause after this point
tell me something NEW, or does it tell me MORE ABOUT WHAT I WAS JUST TOLD?* Elaboration — resumptive
description, a possessed attribute, a comparison, an appositive re-naming, an instantaneous reflex, a
trailing PP, a bare reversal, a restated verb — stays inside, no matter how many clause-grade cues it
carries. That single question would have removed 24 of my 30 false cuts.

**Density.** Keys: doc_3484 ≈ 8.3 tok/seg (my 7.3) · doc_51f6 11.4 (my 9.6) · doc_9ad9 11.0 (my 9.9).
Every one of my three estimates ran 1–2 tokens SHORT of the key. Density did NOT diagnose the problem —
doc_3484's key really is the shortest-segmented document in my record at 8.3 and I still over-cut it.
So: **density is a check on my count, never a licence to place a cut.** Amendment to batch 3's "my count
is now right": my count drifts short again whenever the document is descriptive rather than eventful.
When my draft narrative density lands under ~10, the cuts to delete are the elaborative ones, in the
order listed below.

---

### narrative (batch 4 — the elaboration catalogue: what looks clause-grade but is not)

**RULE — a verb carrying a RESUMPTIVE OBJECT PRONOUN that binds back to the NP just described is a
relative-like descriptive tail: NEVER cut before it.** This is the cleanest new discriminator of the
batch and it is a hard formal test I can apply blind. REFINES batch 3's "an asyndetic descriptive verb
whose subject is the NP just introduced starts a new segment (topic shift)" — that rule holds only when
the verb has NO pronoun reaching back; when the pronoun is there, the clause is inside.
- `…من شيء يشبه الأسمنت له لون الرماد يشقها مجرى رفيع رمادي يتلوى تحت كتل الأسمنت…` — I cut before `يشقها`.
- `…يتلوى تحت كتل الأسمنت على جانبيه يعلوها دخان وبخار وقتام ورمال وغبار…` — I cut before `يعلوها`.

**RULE — a verbless clause whose subject is a POSSESSED ATTRIBUTE of the referent in play is internal.
A body part, a garment, a colour, a face is NOT a new entity.** This CONTRADICTS and narrows batch 3's
"و + a verbless / fronted-PP clause cuts ONLY when it brings a NEW ENTITY as its subject" — the entity
test must exclude anything possessed by the referent already on stage. Three sites in two documents:
- `ينشق الكون عن عساكر جيش وبوليس ملابسهم عادية بعضهم بالجلابيب والشوارب واللحى الطويلة…`
- `تنزع الخمار في البيت وجهها جميل فيه بعض البثور ولها عينان غائرتان ‖`
- `…له لون الرماد` · `عيناي خضراوان لونهما لون الزرع` (the possessed-attribute clause is inside; the
  BARE VERB that follows it is not — see the next rule).

**RULE — but a BARE asyndetic FINITE VERB with no pronoun reaching back DOES cut, every time, however
short, and even when it denotes a state rather than an event.** This kills my derived law for doc_3484
("حال / manner elaborations of the same act stay inside") and CONFIRMS batch 2's staccato rule. Four
missed cuts, all one shape:
- `كانت تجاهد للوقوف ‖ تشد عضلاتها ‖ تقاوم الانحناء ‖ يعود قوامها إلى وضعه المستقيم ‖` — I wrote ONE
  segment for the first three. Two-token segments are correct here.
- `عيناي خضراوان لونهما لون الزرع ‖ تلمعان في مرآة حقيبتي كعيون القططة ‖` — `تلمعان` is a state and it
  still cuts, because nothing in it points back.
- `عظام ظهرها قوية متينة ‖ لها قوة أربعين رجلا وعشرين حصانا…` — the switch from an ADJECTIVAL predicate
  to a fronted-PP predication with its own noun subject (`قوة`) also cuts.
So the pair of rules together: **pronoun reaching back → inside · nothing reaching back → cut.**

**RULE — `كان` + imperfect immediately after a completed action by the same subject is a حال and stays.**
- `جلست فوق حجر بجوار خيمتها كانت تلهث قليلا ‖` — I cut before `كانت`. Contrast the bare-verb rule above:
  the auxiliary is what marks it as concurrent state rather than a fresh beat.

**RULE — two short parallel verbless clauses that make ONE observation are one segment.**
- `الزحام شديد لا مكان لقدم ‖` — I split them. The second is a negative-existential gloss of the first,
  not a second fact.

**RULE — a chain of DEICTIC appositive re-namings of one referent runs on, however long, and the final
predicate closes it.** CONFIRMS and extends batch 2's appositive rule (which covered one gloss; this is
three in a row, each headed by a demonstrative).
- `هؤلاء الملايين النساء الشباب الشابات الرجال الأطفال العجائز هذه الوجوه من كل الأعمار والأشكال والبقاع
  ملايين الملايين تملأ الشوارع والميادين ‖ أصواتهم تدوي في…` — ONE segment; I made three. The cut comes
  only when a genuinely new sub-topic takes over (`أصواتهم`).
- Same shape in nominal form: `لقد أسرجت الجمال الثلاثة غطاء على السنام عليه السرج الخشبي الثقيل بمقبضيه
  العاليين من الأمام والخلف وعلى السرج أغطية وحصائر ‖` — ONE segment; I made three. A noun-phrase
  unpacking of HOW something was done is apposition, not enumeration.

**RULE — an adverbial phrase with NO predication after it is a TRAILING complement, not a fronted head.**
Sharp test I did not have: *a fronted adverbial may open a segment only if a finite clause follows it.*
- `كانت تمشي في جوارها وسط الصفوف خمس ساعات وأكثر من الجنوب إلى الشمال فوق الكباري القديمة والجديدة…` —
  I cut before `من الجنوب`, reading it as a fronted route adverbial. There is no verb after it: it
  specifies the walking already stated.

**RULE — و + a fronted element is NOT clause-grade by itself. AMENDS batch 3's و-SORT, which listed
"a fronted PP" as a CUT trigger.** What changed and why: batch 3's evidence was expository/gazetteer
prose (`وبمقتضاها تم جلاء آخر جندي بريطاني`); three sites here inside continuous description or a single
action sequence all run on, so the fronted element is demoted from trigger to neutral — it cuts only
when what follows is also a new event.
- `…يقفز الجمل على حين غرة وبصعوبة يستطيع رحمان امتطاءه مستعينا بعصا بيده ‖`
- `فتأخذ الصور التي تبرزها عارية الوجه وبعد إلقاء نظرة عابرة عليها سرعان ما تضعها…`
- `…بمقبضيه العاليين من الأمام والخلف وعلى السرج أغطية وحصائر ‖` (و + fronted PP + a brand-new entity
  as subject — and it STILL does not cut, because the segment is one static inventory).

**RULE — ف of INSTANTANEOUS reflex is comma-grade; ف of a new step in time is clause-grade.**
EXTENDS batch 3's "ف opens a new reaction only at a fresh MAIN-clause beat, never immediately after an
adverbial/subordinate head" — it also does not cut immediately after the MAIN clause it is the reflex of.
Three sites, two documents, and I cut all three:
- `يفك لافي وصبي آخر اسمه رحمان قيده فينتصب ثم يسرج…` (the camel rises the instant the hobble is off)
- `…أحدهم مبارك الدليل الآخر فتحجب صالحة وجهها بسرعة البرق ‖` (`بسرعة البرق` is the tell — no time passes)
- `هي نفسها تطير مع الزجاجة وتسقط على الأرض فبدت لها دماء حمراء ‖` (perception in the same instant)
Still clause-grade, unchanged from batches 1 and 3: ف opening a step that ADVANCES the story in time
(`فاقترض بذورا`, `فتوقف`, `فخرج الضابط من الباب`).

**RULE — وقد + perfect that REPEATS the verb just used is a resumptive restatement, not a new
predication. NARROWS batch 2's "و + قد + perfect opening a new predication cuts."** What changed and
why: batch 2's site introduced a new verb and a new fact (`وقد اقتبس من أعمال الدكتور…`); here the same
verb is said again about the same subject, which is elaboration.
- `لاحظت أنها تلهث وريقها جاف وقد لاحظت حالتها قبل أن تلحظها هي ‖`

**RULE — the comparison list is internal and it includes كأنما.** My derived law already said كما / كـ
were internal and I cut at كأنما anyway; recording it so the list is closed: **كما · كـ · كأنما · كأن**.
- `الكلمتان تخرجان من بين شفتيها مع الشهيق والزفير كأنما في السماء آذان تلتقط الصوت…`

**RULE — و + a same-subject bare finite verb is comma-grade even when it carries its own time adverbial
or its own complements, when it completes ONE continuous move or ONE argumentative point.** My doc_51f6
law licensed a "scene/mode transition" exception for exactly this shape and lost the site. CONFIRMS
batch 2's same-subject rule and batch 3's "sub-actions of one single move run on."
- `…اسمه لافي القليل القليل من الإنجليزية ويصطحبني بسيارته بعد الظهر كي يريني بيته…` (the exception I
  invented, refuted at its only site)
- `ألقت البلوفر والشال وحقيبة يدها إلى الأرض وانطلقت وسط الملايين تهتف معهم يسقط النظام ‖`
- `وشركة أرمكو معروفة عالميا بمستوى الصيانة والحماية وحصلت على الكثير من الجوائز العالمية…`
- `أما الخلافات ممكن أن تحل من خلال العقل والحوار والمساومات ممكن تكون هي المخرج من أتون السعير…`
  (و + a genuinely new nominal subject, still no cut — the two predicates are one argumentative move,
  which is a second constraint on the batch-3 "new entity as subject" trigger.)

**RULE — bare لكن/لكنها reversing the predicate just given does not cut.** CONFIRMED again, third batch
running (batch 2 established it, batch 3 refined it on continuation).
- `…لها قوة أربعين رجلا وعشرين حصانا كما كانوا يقولون عنها لكنها لم تعد شابة وليست كهلة ‖`

**RULE — وهي التي + relative is internal. This does NOT conflict with batch 3's "وهي + definite NP
predicate CUTS" — the two are different structures and both stand.** وهي/وهو + RELATIVE or + أن/ما
gloss = inside; وهي/وهو + a standalone equational NP predicate = cut.
- `…صور لصديقة لي كنت قد التقطتها منذ بضعة شهور وهي التي اقترحت علي هذه الرحلة الصحراوية ‖`

**RULE — a هل … أم … alternative question is ONE segment, and a parenthetical aside inside it does not
cut either. NARROWS batch 1's confirmed "every direct question ends a segment"** — it ends at the end of
the WHOLE question, and أم keeps it open.
- `هل ذعرت من وجه نادرا ما تراه أنا الرجل لا أشاهد مرآة في المنزل أم أنها تريد من باب الحشمة حمايته من…`
  — one segment; I made three. `أنا الرجل لا أشاهد مرآة في المنزل` is an aside inside the question.

**RULE — a VOCATIVE or ADDRESS/REPLY frame attaches FORWARD to the sentence it introduces.**
NEW, and the family it joins is large: this is the same forward-welding as the speech frame, the chant
frame and the list stem. It cost me three errors including one matched missed+false pair — the classic
"one word on the wrong side" failure I first recorded for legal fronted time adverbials in batch 1.
- `…ينعمون براحة ويتكلمون بما لا يرون ‖ يا رجل إنها أنفس ليست ألعاب الأطفال الصغار ‖` — I attached
  `يا رجل` backwards and lost both boundaries at once.
- `ردا على الأخ فيصل اليامي هذا الحادث قضاء وقدر ‖` — reply frame welded to the first assertion.
- `إلى الأخ رقم 1 من هم قبيلة ورسنكلي ‖` — address line welded to the question it introduces. Note this
  is NOT a display line, even though it looks like one.

**RULE — an emphatic one-word ECHO of a word already inside the clause stays inside it.** CONFIRMS
batch 2's `ظل ينبح ينبح`; NARROWS batch 1's "a one-word segment is normal" — a one-word segment is
normal when it is a whole utterance (`ماذا`, `يجوز`, `أرواح` as a fresh cry), not when it re-sounds a
word from the sentence it sits in.
- `إنها أرواح أزهقت يا رجل أرواح ‖ حسبي الله ونعم الوكيل ‖` — I gave the second `أرواح` its own segment.

**RULE — in a diary/dispatch header block, the PLACE line after the dateline is its own display line.**
EXTENDS the display-line rule (title/byline/edition/dateline) with one more member. My only missed cut
in that document.
- `سيناء ‖ 23 كانون الأول ديسمبر 2005 ‖ في خليج العقبة ‖ تهب ريح قاسية باردة شمالية شرقية ‖` — I welded
  `في خليج العقبة` to the weather clause as a fronted adverbial. In the header block it is a line.

**CONFIRMED — the laws that worked, zero errors on them across all three documents:**
- Bare-noun coordinated series never cut: `دخان وبخار وقتام ورمال وغبار` · `العقل والحوار`. ✓
- Relative clauses, adjective stacks, purpose لـ, and everything inside an أن-complement are internal. ✓
- Backward subordinator إذ closes the segment it follows. ✓
- The announcing frame is welded to the chant/quote it announces: `الهتاف يدوي يسقط النظام` ·
  `يهتفون يسقط النظام` · `بكلمتين اثنتين يسقط النظام`. ✓
- Every direct question closes a segment (except across أم — see above). ✓
- A long, heavily subordinated argumentative sentence is ONE segment: the 46-token إن-indictment with an
  appositive, a relative and a PP tail survived intact. Long ≠ splittable. ✓
- Formula / du'a / oath / one-word cry each stand alone in polemic: `حسبي الله ونعم الوكيل ‖`. ✓
- Asyndeton between two genuine PREDICATIONS with new topics cuts: `الزحام شديد لا مكان لقدم ‖ الملايين
  من المتظاهرين خرجوا…`. ✓

---

### CROSS-TOPIC RULE OF RECORD (batch 4)

**THE ORDER OF OPERATIONS GAINS A STEP 3.5 — THE ELABORATION FILTER.** Batch 3 fixed the order as
(1) topic → (2) register/density → (3) subordinate direction → (4) sort the coordinators. Insert between
3 and 4: **(3.5) mark every clause that only tells me MORE about what was just said, and rule it internal
before any coordinator is examined.** The markers, in the order they earn their keep: a pronoun reaching
back into the previous clause (on the verb, or on the subject as a possessed attribute); a demonstrative
re-naming; a comparison particle; an adverbial with no verb after it; a repeated verb; an instantaneous
reflex; a bare reversal. Twenty-four of my thirty false cuts were sites this filter catches.

**THE و-SORT, RESTATED AND DEMOTED (supersedes the batch-3 statement; batch 3 is kept above as the
record of how I learned it).** What changed and why: batch 3 listed "a fronted PP", "a new entity as
subject", and "a complete clause with its own complements" as CUT triggers; this batch refutes each of
them at least twice, so none of the three is sufficient on its own.
- و is clause-grade only when the clause after it is a NEW EVENT or a NEW TOPIC — a fresh beat that
  moves the document forward in time or in argument.
- و is comma-grade when it continues one move, one portrait, one inventory or one argumentative point,
  and this holds even with a fronted element, even with a brand-new noun as subject, even when the
  conjunct is a full clause with its own complements.
- The formal cues survive only as tie-breakers when the semantic question is genuinely balanced.

**A GENERAL LAW ABOUT FRAMES, now that four of them agree.** The speech frame, the chant frame, the list
stem, the reply/address frame and the vocative all attach FORWARD to what they introduce; only display
lines (title, byline, edition, dateline, place line, section number + title) stand alone. When I meet a
short introducer, the question is never "does it get its own segment" but "is it a display line or a
frame" — and outside a front-matter block, it is a frame.

---

## BATCH 5 — docs: doc_0ad7fe19f9bb (narrative / magazine dispatch + interview page),
## doc_0c92fc467c35 (narrative / children's magazine feature), doc_2f73d2ab2ca3 (narrative / folk tale)
(the prompt labelled this "batch 4 of 37"; it is the FIFTH set of three I have absorbed — batches are
numbered here in the order I received them, and nothing above is renumbered.)
Scores: magazine interview F1 91.8 (P 87.5 / R 96.6) · Scheherazade/Rimsky-Korsakov F1 91.4 (P 86.5 /
R 97.0) · "the brown men of Jeddah" folk tale F1 85.7 (P 80.0 / R 92.3). **19 errors: 15 FALSE CUTS,
4 MISSED.** Cuts made vs. key: 32/29 · 37/33 · 30/26.
Grader line: `juror0: 75 docs graded | mean F1 90.15 (P 95.14 / R 87.84)`.

### THE HEADLINE — THE UNIT IS A COMPLETE MOVE, AND I KEEP CUTTING IT AT ITS INTERNAL HINGE
Third over-cutting batch out of five (2, 4, 5), so this is a standing defect and no longer a wobble.
But the shape has changed and I must name the new shape precisely. Batch 2's defect was "coordination
is not a comma." Batch 4's was "elaboration is not a new sentence." **Batch 5's residue is narrower and
meaner: I cut at the HINGE INSIDE ONE MOVE** — between an action and the reaction it triggers, between
a negation and the correction that answers it, between a definition and its contrastive twin, between a
name and the appraisal hung on it, between a label and the name that completes it. Every one of those
hinges carries a genuine clause-grade cue (ف, و + a new verb, و + a new subject, a fresh predication),
and the annotators do not cut at any of them, because **both halves are one thing being said.**

**The operational question, which now precedes the batch-4 elaboration question:** *is the clause after
this point the OTHER HALF of the clause before it?* If it completes a two-part shape — act→reaction,
say→what was said, deny→correct, define X→define not-X, name→rank it, frame→deliver it — it is internal,
whatever connective sits between them. That question alone removes 12 of my 15 false cuts.

**Density.** Keys ≈ 8.6 / 10.1 / 8.8 tokens per segment; my drafts 7.8 / 9.0 / 7.7 — short by ~1 token
every time, for the fifth document type running. See the calibration constant at the end.

---

### narrative (batch 5)

**RULE — an action and its IMMEDIATE consequence or on-the-spot utterance are ONE segment: do NOT cut at
the ف or the و + قال that hinges them. WIDENS batch 4's "ف of INSTANTANEOUS reflex is comma-grade" from
same-instant reflexes to any consequence that follows automatically and without a time gap, and it now
covers و + a speech verb as well.** This KILLS my doc_2f73 law, which said "(d) every ف that opens a NEW
STEP in story time cuts" and "(e) every speech/whisper frame, including وقالوا carrying the refrain."
Five of my six false cuts in that document were this one mistake.
- `اجتمعوا حول الطبلية طاولة مستديرة أرضية فقال أحدهم يا سعيد نسينا الليمونة ‖` — they sit down and one
  of them speaks on the spot; ONE segment.
- `فاتفقوا أن يذهبوا جميعا لشراء الليمونة فأقفلوا الباب ووضعوا المفتاح تحت كيس الرمان ‖` — agreeing to go
  and locking up is one departure.
- `وخرج الرجال السمر من عند القاضي فشاهدوا امرأة حاملا تقف على بطنها ذبابة ‖` — stepping out and seeing.
- `فضربوه ضربة على رأسه وقالوا وهذه ذبابة ‖` and `فضربوه ضربة فوق ركبته وقالوا هذه ذبابة ‖` — the
  strike-and-say refrain is ONE beat, both times. I split both.
**The counter-cue, from the same document, so the rule does not swallow the confirmed ف-cuts:** ف still
CUTS when it opens a NEW EPISODE — after a quoted turn has closed, or at a change of scene.
`…روح يا حمدان ‖ فاتفقوا أن يذهبوا جميعا…` — I got that one right. So the tell is never the ف itself; it
is whether the preceding stretch already closed on its own (a quote ending, a scene ending) or is still
mid-move. Unchanged and still confirmed: `فخرج` · `فنظر` · `ففتح` · `فدهش` · `فاقترض` · `فتوقف`.

**RULE — CORRELATIVE PAIRS ARE ONE SEGMENT.** New as a class; the record had scattered members
(`وإن كان … لكن`, `هل … أم`) but never the class, and I lost a site at three different members.
- **negation + correction** — `ولم يتوقف كورساكوف عند حدود الهواية أو الموهبة لكنه واظب على الدروس
  الموسيقية وتعلم على أيدي…` This AMENDS batch 3's "CUT at ولكن when the clause is a new beat that itself
  gets continued": the continuation (`وتعلم`) is present here and the key still does not cut. What changed
  and why — correlation outranks continuation; the `لم/ما … لكن` frame is one statement, and length and
  continuation were both false predictors. (Fourth batch running that a bare لكن reversal does not cut.)
- **two-part contrastive definition** — `السفير المقيم هو الذي يقيم في نفس البلد وغير المقيم هو الذي
  يتردد حسب الضرورة ‖` — one answer to one question; X and not-X are defined in one breath.
- **anaphoric parallel** — `هي التي قررت أن تقف في وجه السلطان شهريار وهي التي لم تكن تملك من سلاح غير…`
  CONFIRMS batch 4's "وهي التي + relative is internal" — a rule I had already written down and violated.
  Recording the discipline failure as well as the rule: **the record only pays if I consult it at the
  site.** وهي/وهو + التي/الذي is never a boundary.

**RULE — a dateline and the correspondent's name printed with it are ONE display line.** NARROWS my own
batch-3/4 display-line law, which listed "each country–city dateline, each correspondent byline" as
separate lines. Twice in one document, the same shape:
- `سلطنة عمان بهلاء عبد الله بن خليفة الهنائي ‖` · `اليمن حضرموت حسين صالح باشماخ ‖`
This is the same law as legal `الباب الأول الأسس العامة ‖` and batch 2's `١ البداية ‖`: **a display line
is the whole PRINTED line, and a label is never split from the name that completes it.** The genuinely
standalone display lines above them are unaffected — `كشافة مجلس التعاون ‖` (the dispatch headline) stands
alone and I got it right.

**RULE — وقد + perfect that completes the SAME framing act is comma-grade. NARROWS batch 2's "و + قد +
perfect opening a new predication cuts" for the second time** (batch 4 narrowed it for a repeated verb;
this narrows it for a continued frame).
- `…على هذه الفرصة الثمينة لإجراء حوار صحفي لمجلة ماجد وقد أجاب مشكورا على الأسئلة التالية ‖ ماذا تعني
  كلمة سفارة ‖` — thanking him for the interview and his having answered the following questions is one
  editorial preamble. Note where it DOES close: at the list stem `الأسئلة التالية`, exactly as batch 1's
  legal stem rule predicts. The stem closes the segment; the stem does not get a segment of its own.

**RULE — the resumptive-pronoun shield is an object clitic ON THE VERB, not any pronoun anywhere in the
clause. SHARPENS batch 4's "a verb carrying a RESUMPTIVE OBJECT PRONOUN … NEVER cut before it."**
What changed and why: I stretched that test to a pronoun sitting in a trailing PP complement and lost
the site; the test must be structural, not lexical.
- `السفارة هي رابط بين دولتين ‖ تعمل على تطوير العلاقات بينهما ‖` — `بينهما` reaches back, but it is buried
  in a PP; `تعمل` itself carries nothing, so the bare-asyndetic-verb rule wins and the key cuts.
- Contrast batch 4's `يشقها` · `يعلوها`, where the clitic is ON the verb and makes the clause a
  relative-like tail. **Clitic on the verb → inside. Pronoun deeper in the clause → does not shield.**

**RULE — لعل + a speculative predication after a completed action OPENS a segment.** New. My derived law
for that document filed "purpose لعله" with the internal baggage; it is a main clause with its own
modality, not a purpose subordinator.
- `وألف العديد من القطع الموسيقية وهو صبي ثم التحق بالكلية البحرية ‖ لعله يقابل في البعيد شهرزاد أو
  السندباد ولعله…` — and the ولعله that continues the speculation stays INSIDE that new segment.

**RULE — ثم continuing ONE person's biography does NOT cut, even on a ~10-token children's magazine page.
CONFIRMS batch 3's "ثم + a same-subject verb continuing the history of ONE entity does not cut in
expository prose" and extends its trigger: the rule is fired by the PASSAGE being a biography/history,
not by the document's overall register.** I applied the folk-tale ثم rule inside an embedded life-story.
- `وألف العديد من القطع الموسيقية وهو صبي ثم التحق بالكلية البحرية ‖` (this false cut and the لعل missed
  cut above are the same misplacement: one boundary, one clause too early)
- the twin site: `ولد في روسيا في العام 1844 ونشأ في أسرة فنية تحب الموسيقى وتعشق الآلات…` — born and
  raised is ONE opening move, however complete the second conjunct is.
- Contrast the folk tale in the SAME batch, where ثم is the beat marker and I was right to cut:
  `‖ ثم وقفت أخرى فوق ركبة القاضي…` · `‖ ثم ضربوا الذبابة ‖`. Same connective, opposite verdict, decided
  by passage type — the batch-1 cross-topic law yet again.

**RULE — after an INDEFINITE head noun, كان/كانوا + imperfect is an adjectival relative (صفة), not the
main clause; the segment's predicate is the finite verb AFTER it.** New, and it cost me a matched
false-cut + missed-cut pair — the "one clause on the wrong side" failure I have now made in four batches.
- `جماعة من الرجال السمر كانوا يعيشون في جدة اشتروا حزمة ملوخية ‖ قطفوها وخرطوها وطبخوها…` — I cut after
  `جدة` and then ran on through `اشتروا`. The key does the exact opposite: the presentative subject plus
  its description plus its first EVENT are one opening sentence.
This CONFIRMS and generalises batch 4's "كان + imperfect after a completed action is a حال and stays":
**كان + imperfect is descriptive backdrop and is never a segment-closing main predicate.**

**RULE — a vocative BEFORE its clause welds forward; a vocative AFTER a complete utterance closes with it.
SHARPENS batch 4's "a VOCATIVE or ADDRESS frame attaches FORWARD to the sentence it introduces"** with
the positional test it was missing — batch 4 saw only the pre-posed case (`يا رجل إنها أنفس…`).
- forward, confirmed: `فقال أحدهم يا سعيد نسينا الليمونة ‖` — frame + vocative + clause = ONE.
- backward, missed: `همس بخيت في أذن حمدان أنظر يا حمدان ‖ هذه ذبابة ‖` — `أنظر يا حمدان` is a complete
  first sentence of the quote (imperative + trailing vocative), and the next sentence of the same turn is
  its own segment. Batch 1's "later sentences inside the same turn are separate" applied and I missed it
  only because I read the imperative-plus-vocative as an incomplete frame.

**RULE — when two parallel وهي/وهو clauses follow each other, the FIRST is an appraisal tail and stays
inside; the SECOND opens the sub-topic the rest of the paragraph develops and cuts.**
- `أما سيمفونية شهرزاد فقد ألفها في العام 1888 وهي من أهم أعمال الأوركسترا ‖ وهي متتالية من أربع حركات…`
  — I cut at both; the key cuts only at the second. A RANKING tag (`من أهم` / `من أشهر` / `من أفضل`) rides
  with the topic sentence that names the thing; a CONSTITUTIVE description that the following sentences
  unpack (here the four `الحركة` items) is a new beat.
This RECONCILES batch 3's "وهي + a definite NP predicate CUTS" with batch 4's "وهي التي / وهي أن is
internal" without overturning either: the operative test is neither definiteness nor the relative
pronoun, it is **whether the sentences that follow unpack this clause or leave it behind.**

**CONFIRMED — the laws that worked, zero errors on them across all three documents:**
- Every interview question closes a segment, including the second of two questions coordinated by و
  inside one interviewer turn; every answer sentence closes a segment. ✓
- The speech frame is welded to the FIRST sentence of its quote: `قال سعيد…` · `فقال أحدهم يا سعيد
  نسينا الليمونة ‖`. ✓
- Asyndetic bare finite verbs are the beats of a folk tale: `‖ اجتمعوا…` · `‖ قطفوها…` · `‖ همس بخيت…` ·
  `‖ طارت الذبابة…` · `‖ قال سعيد…`. ✓
- أما switching topic to a new character cuts in narrative: `‖ أما القاضي ففتح فمه مدهوشا متعجبا ‖`. ✓
- و + a fronted PP opening a NEW SCENE cuts: `‖ وفي الطريق…` (contrast batch 4, where a fronted PP inside
  a continuing description does not — the discriminator is the new scene, not the fronting). ✓
- A verb chain whose conjuncts all carry a resumptive ـها is one segment: `قطفوها وخرطوها وطبخوها
  وصنعوا منها فتة ملوخية ‖`. ✓
- Internal, all reconfirmed: relative clauses (الذي/التي), coordinated adjectives (`وقادر`), bare-noun and
  bare-relative series (`والأمانة والحكمة`, `وما يتعلق`), backward-attaching حيث, أن-complements, purpose
  لـ, appositive glosses (`الطبلية طاولة مستديرة أرضية`), the three verbs under one إياك, a لما protasis
  with its apodosis, and gapped coordination under one shared verb. ✓
- Display headline lines stand alone: `كشافة مجلس التعاون ‖`. ✓

---

### CROSS-TOPIC RULE OF RECORD (batch 5)

**A CALIBRATION CONSTANT, measured over two batches and six documents: my draft carries ~10–15% TOO MANY
cuts.** Batch 5: 32 vs 29 (+10%), 37 vs 33 (+12%), 30 vs 26 (+15%) — overall +12.5%; batch 4 over-cut all
three of its documents too. My per-segment density has been ~1 token short of the key in all six. This is
now a reliable prior, so it becomes an ACTION rather than an observation. **When the draft is finished,
delete the least-certain ~1 cut in every 8, and take them in this order:**
1. the ف / و+قال hinge between an action and its immediate reaction (5 of 15 this batch)
2. the second half of a correlative pair — لكن after a negation, not-X after X, وهي التي after هي التي (3)
3. an appraisal or framing tail — وقد + perfect completing a frame, وهي + a ranking (2)
4. a display line I split into label + name (2)
5. ثم / و continuing ONE entity's history or one opening move (2)
Fourteen of this batch's fifteen false cuts are in those five classes. The fifteenth was not a count
error at all but the presentative misplacement (`جماعة … كانوا يعيشون … اشتروا`), which deleting cuts
would not have fixed — **density is a check on my count, never a licence to place or move a cut.**
(Amendment of record to batch 3's "my count is now right": it is right only after this deletion pass.)

**THE ORDER OF OPERATIONS GAINS STEP 3.6 — THE CORRELATIVE / HINGE FILTER.** The order is now:
(1) topic → (2) register and density band → (3) subordinate-clause direction → (3.5) the batch-4
elaboration filter (does this clause only tell me MORE about what was just said?) → **(3.6) the hinge
filter: is this clause the OTHER HALF of a two-part shape?** — act→reaction, deny→correct, define
X→define not-X, name→rank, frame→deliver, label→name → (4) sort the remaining coordinators.
Steps 3.5 and 3.6 are both "do not cut" filters, and they must run BEFORE any connective is examined,
because every site they catch displays a valid clause-grade cue that will otherwise win the argument.

**THE و-SORT, unchanged from batch 4 and reconfirmed — و is clause-grade only when the clause after it is
a NEW EVENT or a NEW TOPIC.** Batch 5 adds no exception to it; every و I got wrong this batch was caught
by 3.5 or 3.6, not by a defect in the sort itself.

---

## BATCH 6 — docs: doc_7aa0f72706ad (narrative / magazine masthead + editorial column),
## doc_a404631139d3 (narrative / comic-strip balloon page), doc_f7c344e48e78 (other / MCQ worksheet)
(the prompt labelled this "batch 5 of 37"; it is the SIXTH set of three I have absorbed — batches are
numbered here in the order I received them, and nothing above is renumbered.)
Scores: masthead+editorial F1 80.0 (P 100.0 / R 66.7) · balloon page F1 94.4 (P 100.0 / R 89.5) ·
worksheet F1 99.0 (P 98.0 / R 100.0). **17 errors: 15 MISSED, 2 FALSE CUTS.**
Cuts made vs. key: 22/33 · 34/38 · 102/100.
Grader line: `juror0: 78 docs graded | mean F1 90.19 (P 95.30 / R 87.75)`.

### THE HEADLINE — THERE ARE TWO FAMILIES OF DOCUMENT AND MY BIAS IS OPPOSITE IN EACH
Precision 100 / 100 / 98, recall 66.7 / 89.5 / 100. **This is the exact mirror of batches 2, 4 and 5.**
Every generalisation I have made about my own error profile for five batches — "I over-cut", "delete the
least-certain 1 cut in every 8" — was measured on PROSE only, and this batch shows it is not merely
inapplicable but *inverted* outside prose. On the two display/dialogue documents I under-cut by 33% and
10%; the worksheet, the only one where I applied a list law, scored 99.

**THE LAW OF RECORD, and the most valuable thing in this batch:**
- **FAMILY A — prose registers** (narrative, expository, legal body, argument, editorial column):
  8–16 tokens/segment. The unit is the SENTENCE. My standing bias is to OVER-cut. Filters 3.5
  (elaboration) and 3.6 (hinge/correlative) apply. The batch-5 deletion pass applies.
- **FAMILY B — display / list / dialogue registers** (masthead & front matter ~3 tok/seg, worksheet
  items ~4, comic balloons ~5): the unit is the **DATUM, the ITEM, or the single UTTERANCE**, never the
  sentence. My standing bias is to UNDER-cut by merging adjacent items into an invented "line".
  **Every discourse-level shielding rule in this record is SUSPENDED in family B.** The batch-5 deletion
  pass is FORBIDDEN here — its class 4 ("a display line I split into label + name") is precisely what the
  key demands, and applying it would have cost me nine more sites.
- **The sorting cue is measured density.** If a block runs under ~6 tokens/segment, I am in family B.
- **A single document can contain both.** doc_7aa0f72706ad is a family-B masthead (0–42, ~3 tok/seg) +
  a family-A editorial column (43–163, ~7 tok/seg) + a family-B sign-off. I correctly identified the two
  zones and then gave the front matter a family-A-flavoured law. Identifying the zone is not enough;
  each zone gets its own family's law.

**What still shields in family B, and what does not.** Syntactic subordination still shields:
أن/ما-complements, relative clauses, كما comparison, a resumptive clitic ON the verb, an إذن + ف
apodosis — all held with zero errors on the balloon page. What does NOT shield in family B:
discourse-level explanation (لأن / explanatory إن), possessed-attribute description, appositive
re-naming, correlative pairing, and coordinated-NP series. **Subordination shields; discourse relations
do not.**

---

### narrative — FRONT MATTER, MASTHEADS, BANNERS, SIGN-OFFS (family B)

**RULE — in a masthead or issue bar the unit is the FIELD, not the printed band: EVERY self-contained
datum is its own segment.** I merged the whole masthead into five "printed lines" and lost eight cuts in
43 tokens. The key runs the block at **~3 tokens per segment** — the finest register in my record.
- `مجلة كل الأولاد وكل البنات ‖ ماجد ‖` — the strapline and the magazine's NAME are two fields, not one
  line. I glued them, twice (@4 and again at @39).
- `الأربعاء 1 مارس 1995 م ‖ 29 رمضان 1415 ه ‖` — two calendars = TWO datelines. I wrote one dateline.
- `السنة السابعة عشر ‖ العدد 836 ‖ الثمن 3 دراهم ‖` — three fields. I wrote one "issue bar".
- `MAJED ‖ NO 836 ‖ March 1 1995 ‖` — the Latin strip repeats the fields and each repeat is a field.
  I wrote one "Latin line".

**RULE — a bare LABEL word stays with its value, but two self-standing fields printed adjacently split.
This SHARPENS batch 5's "a label is never split from the name that completes it", which I applied far too
widely.** What changed and why: batch 5's site (`سلطنة عمان بهلاء عبد الله بن خليفة الهنائي ‖`) is ONE
ENTRY of a repeating record — place + who filed from it — and that is where the narrowing holds, together
with `الباب الأول الأسس العامة` and `١ البداية`. It does NOT hold across a masthead grid or a sign-off
block. The operative test: **is the first part meaningless without the second (العدد · الثمن · السنة · NO
· الباب · a numeral) → one segment; or is each part a complete item of the same kind (two dates, a
strapline and a title, a valediction and a signature) → two segments.**
- `مع محبتي ‖ ماجد ‖` — the valediction and the signature are two lines of the sign-off block. I glued
  them under the batch-5 narrowing. `مع محبتي` is not a label for `ماجد`; it is a complete formula.

**RULE — a و-coordinated pair of complete banner items SPLITS. The bare-noun-series shield is a PROSE
shield and does not survive into a display block.**
- `عيد الفطر المبارك ‖ وعيد ماجد السعيد ‖` — two greetings, two segments. I wrote one "Eid greeting line".
- The limit, from the same document: the internal و of a single item does NOT split —
  `مجلة كل الأولاد وكل البنات` is one strapline and the key keeps it whole. So the test is the ITEM
  boundary, not the connective: two complete items of the same kind split; a coordinated NP inside one
  item does not.

---

### narrative — the editorial column (family A, ~7 tok/seg): 2 errors, both self-inflicted

**RULE — a distributional argument about "how this author must be punctuating" NEVER overrides the
standing و-sort.** CONFIRMS batch 4's headline defect in a new direction: there it made me over-cut, here
it made me miss.
- I observed that the column has exactly ONE clause-level و in 121 tokens of otherwise asyndetic prose,
  and concluded "therefore the asyndeton is the full stop and the one و is the one comma." The key cuts
  at it: `ضاعفنا كمية الأعداد المطبوعة ‖ واستمرت رحلة ماجد من نجاح إلى نجاح طوال 16 عاما ‖`. New subject
  (`رحلة ماجد`), new event, new timescale — the standing sort said CUT and my document-specific economy
  argument talked me out of it. **Rarity is not evidence about grade.**

**RULE — an appositive that follows a COMPLETED predication is its own segment; an appositive sitting
inside an NP whose predicate has not yet arrived is internal. This gives batch 2's and batch 4's
appositive rules the positional test they were missing, and overturns neither.**
- `اليوم يبدأ عام جديد ‖ العام السابع عشر ‖` — the sentence is already whole at `جديد`; the re-naming is
  a post-sentential announcement. I filed it as "an asyndetic appositive re-naming, internal".
- This is the SAME shape as batch 2's `…ثم وصوله إلى نهاية ‖ نهاية حقيقية نهاية العالم ‖`, which I had
  already recorded correctly. Second batch running that I lost a site my own record had solved:
  **the record only pays if I consult it at the site.**
- Still internal, unchanged: `كانت تقص حكاياتها الخاصة … حكايات عن فرسان جامحين` and the batch-4 deictic
  chain — both mid-clause, both before the predicate lands.

**CONFIRMED — the staccato-editorial law worked (only 2 errors in 121 tokens of column):**
asyndetic juxtaposition of two complete predications IS the boundary in this register, and the internal
list held with zero errors — relative clauses (`التي أعقبت`, `الذي نريد أن نقدمه`), أن-complements
(`أننا لم نحقق`), a trailing حين-adjunct with no apodosis, a `قائلا` frame welded to the first sentence of
its quote, bare-noun and adjective series (`الدقائق والساعات`, `عام جديد وسعيد`), and trailing PPs. ✓
The long closing sentence stayed whole: **length is subordination, not splittability.** ✓

---

### conversational — COMIC / BALLOON DIALOGUE (family B, ~5 tok/seg)

**RULE — in a balloon-dialogue register EVERY complete predication is a segment. The family-A shielding
filters do not apply.** All four of my misses in this document are one mistake: I measured the density at
~5 tokens/segment, wrote it down, and then applied prose shields anyway.
- `…أن يكتب في المنزل موضوع إنشاء ‖ عنوانه كيف تندلع الحرب ‖` — I ran them on under batch 4's
  "a verbless clause whose subject is a POSSESSED ATTRIBUTE is internal." **That rule is a DESCRIPTION
  rule (a portrait, a body part, a colour); a possessed-attribute clause that states a new STIPULATION —
  an assignment, a specification, a title — is a separate segment.** Two instructions, two segments.
- `…هذا الموضوع صعب جدا ‖ ولا أدري ماذا أكتب فيه ‖` — I read the second as elaboration of the first
  (why it is hard). In this register it is a second utterance and it cuts.
- `…لا يمكن أن نحاربها ‖ إن بيننا معاهدة صداقة وحسن جوار ‖` — I filed explanatory إن with batch 2's
  "do NOT cut before لأن". **Discourse-level justification shields in family-A prose and does NOT shield
  in family B.** The لأن/إذ rule is hereby scoped to prose.

**RULE — a one-word assent or concession is a whole utterance and gets its own segment, even when a
ولكن reversal follows it. NARROWS batch 5's correlative-pair rule (3.6): correlation binds two CLAUSES,
never an interjection to a clause.**
- `…إن بيننا معاهدة صداقة وحسن جوار ‖ طبعا ‖ ولكن هذا افتراض فقط ‖` — I wrote "a طبعا…ولكن
  concession-reversal pair" into my law as one internal unit. The key gives `طبعا` its own segment.
  This is batch 1's `ماذا` / `يجوز` rule, which I applied correctly to `ماذا` in this very document and
  then refused for `طبعا`. Add to the standalone family: **طبعا · نعم · بالطبع · كفى · خلاص · كلام فارغ.**

**CONFIRMED — the balloon-page law that worked (precision 100.0, every cut I made was in the key):**
- Turn change closes a segment, and on a page with no speaker tags **gender agreement is the tracker**
  (متحيزة fem. → تعتقد أنك masc. → لا تفهمين/اتركي fem. → لا تعرف masc. → بائسة fem.). ✓
- A whole-utterance cry, a free direct question, an imperative after a declarative, and a bare asyndetic
  finite clause each close a segment. ✓
- Syntactic shields hold even at 5 tokens/segment: أن/ما-complements (`أن أبي ذكي جدا ويفهم في كل شيء`,
  `ما هو الخطأ وما هو الصواب`), a كما comparison, a bare-noun pair under one negation
  (`الطهي ولا السياسة`), a verb carrying a resumptive clitic (`وتعلمه`), an إذن + ف apodosis. ✓

---

### exercise — MULTIPLE-CHOICE WORKSHEET (family B, ~4 tok/seg): recall 100.0 on 100 cuts

**RULE — the STEM of a list is the ENTIRE run of text from the previous item to the first item of the new
list, including any scenario or quoted definition that precedes the question proper. It is ONE segment.**
This KILLS clause (iii) of my derived law ("a scenario or a quoted definition standing before the question
is its own segment") and it is the same law as batch 1's legal "cut before the FIRST list item" and batch
4's forward-welding frames — I simply failed to see that a narrative scenario can be part of a stem.
Both of my false cuts, and they were the only two errors in 102 cuts:
- `…زراعة بعض المحاصيل في غير مواسمها يشير التعريف السابق إلى مفهوم الزراعة ‖ الرملية ‖ المروية ‖` —
  I cut between the definition and the sentence that refers back to it.
- `…طلاب العلم من سلطنة عمان للدراسة في جامعة قطر نوع السياحة التي قام بها هي ‖ البيئية ‖` —
  I cut between the scenario and the stem.
**In a question block there is exactly ONE boundary: stem → first option.** Everything before the first
option is stem, however long and however narrative.

**CONFIRMED — the worksheet law that worked (100% recall on 100 cuts):**
- The stem closes exactly where the options begin, **even when it breaks off mid-phrase** — on a
  preposition (`ب`, `بسبب`), a copula (`هو`, `هي`), a quantifier (`حوالي`), or a head noun awaiting its
  adjective (`مفهوم الزراعة`, `تحت القطاع`, `بموجب معاهدة`, `عام`). ✓
- EACH option is its own segment, however short, down to one word:
  `الجبل ‖ الهضبة ‖ الوادي ‖ السهل ‖`. ✓
- Everything INSIDE one option stays whole — comma-grade attribute stacks
  (`حار صيفا معتدل شتاء أمطاره قليلة على الأطراف`), a causal لـ tail
  (`الصحراوية لوجود الكثبان الرملية`), a compound (`الربط الكهربائي`), a numeral phrase
  (`2 4 مليون كم 2`). ✓ No connective in a worksheet is clause-grade.

---

### CROSS-TOPIC RULE OF RECORD (batch 6)

**THE ORDER OF OPERATIONS GAINS A NEW STEP 0 — FAMILY BEFORE TOPIC.** The order is now:
**(0) split the document into blocks and assign each block to family A (prose) or family B (display /
list / dialogue), by its measured density: under ~6 tokens/segment is family B** → (1) topic →
(2) register and density band → (3) subordinate-clause direction → (3.5) elaboration filter →
(3.6) hinge / correlative filter → (4) sort the remaining coordinators.
**Steps 3.5 and 3.6 run in family A ONLY.** In family B they are pure loss: they cost me thirteen of this
batch's fifteen missed cuts. Step 0 is now the first thing I do, before I look at a single connective.

**THE BATCH-5 CALIBRATION CONSTANT IS AMENDED, NOT DELETED.** Batch 5 measured "+12.5% too many cuts;
delete the least-certain 1 in 8" over six prose documents, and it is kept above as the record of how I
learned it. What changed and why: this batch's three documents ran **−33%, −10.5%, +2%** against the key,
so the constant is refuted outside prose and the sign of my bias is set by the FAMILY, not by me.
- **Family A: the deletion pass stands** — draft, then delete the least-certain ~1 cut in 8, in the
  batch-5 priority order.
- **Family B: run the pass in REVERSE.** Where two adjacent stretches could each stand alone as a datum,
  an item or an utterance, SPLIT them. The classes to split, in order of how much they cost me here:
  (1) two adjacent masthead fields I merged into one "printed line" (8 sites); (2) a valediction and the
  signature under it (1); (3) a complete predication I shielded with a prose discourse rule — possessed
  attribute, explanatory إن, elaboration (3); (4) a standalone interjection I welded to its reversal (1).

**A CORRECTION TO HOW I READ MY OWN ERROR HISTORY.** For five batches I wrote headlines of the form
"I over-cut" / "I under-cut" as if I had one global bias whose sign I needed to keep re-measuring. I do
not have one. What I have is constant across all six batches: **I write an elegant document-specific law
and then defend it against the key.** The sign of the resulting error is set by whichever way that
particular invented law happens to point.
- Batch 2: "coordination is a comma" → over-cut. Batch 4: "formal cues are clause-grade" → over-cut.
- Batch 5: "every ف opens a new step" → over-cut. Batch 6: "one segment per printed line", "the one و must
  be the one comma", "a scenario is its own sentence" → under-cut.
Four of the six laws I invented were defended at the exact site where a rule already in this file gave
the right answer (`نهاية ‖ نهاية حقيقية`, the و-sort, `وهي التي`, the list-stem rule). **The failure is
not calibration. It is that I reason from the document instead of consulting the record.** Concretely:
before I defend any document-specific law at a site, I must first name the standing rule it contradicts
and say why this document is the exception — and "the distribution in this document suggests" is never
a reason.

**THE DISPLAY-LINE LAW, RESTATED ONCE FOR THE WHOLE RECORD (supersedes the scattered statements in
batches 1–5, which are kept above as the record of how I learned it).** I cannot see line breaks in a
de-punctuated text, so "one segment per printed line" is a guess and my guess is always too coarse.
Replace it with: **one segment per DATUM.** A datum is a title, a strapline, one date in one calendar,
one label+value field, one greeting, one headline, one byline, one place line, one valediction, one
signature, one section-number+title, one dispatch entry (place + correspondent). Two data printed
adjacently are two segments even with no connective, and even with a و between them.

---

## BATCH 7 — 23 docs: 7 quran (doc_127c1535d7d9, doc_281bb07b48c9, doc_7f28cab0c923, doc_9e0419ed749d,
## doc_d5e46166411c, doc_ea9c5c63ae76, doc_f876524dd98e) · 5 exercise (doc_1c49614cd6bc, doc_25ed373f8aeb,
## doc_7a7737eabf04, doc_87ac286b6785, doc_ede30da2ee29) · 5 bible (doc_4f0612ce35d1, doc_b58385fe50df,
## doc_d86f75defe49, doc_df532033acd3, doc_f2767b56c842) · 5 poetry (doc_51816712b97c, doc_723871f7197e,
## doc_7f77a81d1a7a, doc_b9371c2fbb78, doc_bb10be35e0fa) · 1 conversational (doc_cb57e21e8421)
(the seventh set I have absorbed — batches are numbered here in the order I received them, and nothing
above is renumbered.)
**90 errors on 23 documents: 71 FALSE CUTS, 19 MISSED.** By topic: bible 54 (43 false / 11 missed),
poetry 28 (25 false / 3 missed), exercise 6 (3 false / 3 missed), quran 1 (false), conversational 1 (false).
Thirteen of the 23 documents scored F1 100.0.
Grader line: `juror0: 101 docs graded | mean F1 91.03 (P 94.48 / R 89.78)`.

### THE HEADLINE — THE CANONICAL UNIT IS THE FIRST QUESTION, AND IT IS DECIDED BY THE SOURCE, NOT BY DENSITY
Sixty of my ninety errors are one mistake made in eight documents: **the source had a canonical printed
unit and I segmented by sentence or by rhyme instead.** Where I named the canonical unit and obeyed it
mechanically I scored 100.0 thirteen times over — 7 āyah documents, 3 worksheets, 2 verse-Bibles, 1 bayt
poem, on boundary counts as large as 133. Where I argued myself out of it I produced my four worst scores
in the record: 60.6, 79.5, 81.5, 82.6.

**THE ORDER OF OPERATIONS GAINS A STEP −1, WHICH NOW PRECEDES EVERYTHING INCLUDING BATCH 6'S STEP 0:**
**(−1) Ask: does this source have a canonical printed unit? Name it before reading a single connective.**
- quran → the **āyah**. bible → the **verse**. poetry → the **printed line / bayt**. exercise → the
  **item** (one stem + one option each). legal → the **article / enumerated line**. front matter → the
  **field**.
- If a canonical unit exists, **it is the whole law and syntax has NO vote in either direction**: the unit
  cuts through any constituent, and no juncture inside the unit ever cuts, however many complete sentences
  it holds. Every filter in this record — 3.5 elaboration, 3.6 hinge/correlative, the batch-5 deletion
  pass, the batch-6 family-B splitting pass, the whole و-sort — is IRRELEVANT, not merely suspended.
- Only if no canonical unit exists do I fall to batch 6's step 0 (density → family A or B) and then to
  topic, register and the connective sort.

**DENSITY CANNOT DETECT A CANONICAL UNIT — this amends batch 6's step 0 in the one place it misleads.**
Batch 6 said "under ~6 tokens/segment → family B, the unit is the item". The Qur'an documents in this
batch measure **4.1, 5.7, 6.4, 6.5, 11.1, 11.6 and 17.0** tokens per segment under ONE identical law, and
the five Bibles measure **10.4, 11.1, 11.6, 12.9 and 14.5** — dead centre of the family-A prose band, which
is exactly the trap I fell into. So: **density sorts family only for sources with no canonical unit. Where
the unit is canonical, its density is a property of the source (al-Baqarah's long legislative verses vs.
al-Naḥl's short ones) and carries no disciplinary force at all.** Batch 6's ~6 threshold is kept for
unknown prose/display material, where it still works.

**THE THREE-WAY FAMILY SORT (supersedes batch 6's two-way A/B split; batch 6 is kept above as the record
of how I learned it).** What changed and why: batch 6 wrote one family B and gave it one shielding law
("subordination shields; discourse relations do not"), measured on a comic-balloon page. This batch
refutes that law in the verse registers while confirming it in dialogue, so family B splits in two.
- **FAMILY A — prose** (narrative, expository, legal body, argument, editorial, a worksheet's prose
  coda): unit = the SENTENCE, 8–16 tok/seg. Filters 3.5 and 3.6 apply. Deletion pass applies. Bias: I
  over-cut.
- **FAMILY B1 — canonical printed unit** (āyah · Bible verse · poem line/bayt · worksheet stem+options ·
  constitution article · masthead field · title line): unit = the printed unit. **NOTHING shields, not
  even syntax.** The unit boundary cuts through an iḍāfa, an أن-complement, a verb and its PP, a
  negation…بل pair, a speech frame and its quote. Bias: I under-cut where the unit is short and over-cut
  where I mistake an internal echo for a unit end.
- **FAMILY B2 — utterance / datum** (comic balloon dialogue, credits block, interjections): unit = the
  complete UTTERANCE, ~3–5 tok/seg. **Syntactic subordination DOES shield** (batch 6's dictum, verbatim
  and reconfirmed); discourse relations do not. Split where two adjacent stretches could each stand alone.
- The tell between B1 and B2: in B1 the unit is set by the PAGE (a line, a verse, a slot) and can be
  syntactically incomplete; in B2 it is set by a SPEAKER and is a complete speech act.

---

### quran (7 documents, 1 error — 6 of 7 at F1 100.0)

**RULE — THE ĀYAH IS THE SEGMENT, exhaustively and exclusively. Reconfirmed at 18, 20, 30, 49, 77 and 128
boundaries with zero errors: the key's boundary count equals the verse count in every document.**
- It cuts where syntax runs straight on: through an appositive relative (2:156 `الذين`), an istithnā'
  (2:160 `إلا الذين`), a ḥāl accusative (2:162 `خالدين`), an idh-clause, a bare preposition opening a verse
  (16:44 `بالبينات والزبر`), and a pair of verses that form one grammatical sentence (25:68/69, 25:75/76).
- It holds together whatever a long verse contains: three or more independent predications, interior
  rhetorical questions, imperatives, noun series, أو-alternatives, 33-token stretches. No connective in a
  muṣḥaf is clause-grade. Only the fāṣila is.
- Waqf signs (ج · صلى · قلى · م) are recitation guidance, never boundaries. The rhyme (fāṣila) is the
  recoverable trace of the missing verse circle: a candidate boundary that does not land on the rhyme is
  wrong, and a fāṣila I do not cut at is a missed boundary.

**RULE — the BASMALA welds FORWARD into the first āyah; it is not a segment of its own.** My one Qur'anic
error in seven documents, and it is instructive: I reasoned "it is printed on its own line above the sūra
and is syntactically unattached, therefore a display line."
- `بسم الله الرحمن الرحيم إنا أنزلناه في ليلة القدر ‖` — ONE segment. I cut after `الرحيم`.
The mechanical reason, which is the rule to carry: **the boundary set is the set of āyah separators, and an
unnumbered superscription has no separator after it.** (Untested corollary, flagged as inference: in
al-Fātiḥa, where the basmala IS counted as āyah 1, a boundary would follow it.) This also kills the
"display line" argument for anything inside a muṣḥaf: sūra headings and the basmala are not data in a
masthead grid, they are unnumbered text, and the batch-6 display-line law does not reach into family B1.

---

### bible (5 documents, 54 errors — my worst topic in the record)

**RULE — THE UNIT IS THE VERSE, exhaustively and exclusively, exactly as in the Qur'an. The key's boundary
count equals the verse count in all five documents (34 · 38 · 41 · 41 · 50, 204 boundaries total), and
there is not one intra-verse cut and not one merged pair anywhere.** This is the law I had already written
correctly for doc_df532033acd3 ("THE UNIT IS THE VERSE, not the sentence… internal full stops,
exclamations and question marks inside a verse are NOT boundaries… verse boundaries that fall inside a
syntactic constituent ARE boundaries") and then abandoned in three of the other four documents in favour
of an invented "the unit is the printed sentence of the Van Dyck" law. Forty-three false cuts and eleven
misses, all from that one decision.

**Everything that does NOT cut inside a verse** — each one of these is a false cut I actually made, and
each one is a site where a rule elsewhere in this record would have licensed the cut:
- a printed **full stop** between two complete predications: `فأعطيكم ما يحق لكم فمضوا` · `وحملته الملائكة
  إلى حضن إبراهيم ومات الغني أيضا ودفن` · `فدعا اسمه أنوش حينئذ ابتدئ أن يدعى باسم الرب` · `هذا كتاب
  مواليد آدم يوم خلق الله الإنسان`
- a **direct question**, however clean: `ما ظلمتك أما اتفقت معي على دينار` · `أليس العشرة قد طهروا فأين
  التسعة` · `ماذا يشبه ملكوت الله وبماذا أشبهه` · `فماذا يكون لنا` (kills, inside family B1, batch 1's
  "every direct question ends a segment")
- a **change of speaking turn**: `قالوا له لأنه لم يستأجرنا أحد قال لهم اذهبوا…` · `افتح لنا يجيب ويقول
  لكم` · `أين يارب فقال لهم` · `ماذا تريدين قالت له`
- a **one-word cry, answer or imperative**: `كلا أقول لكم` (twice) · `ولم أجد اقطعها لماذا تبطل الأرض` ·
  `لا أظن` · `لا يا أبي إبراهيم بل إذا مضى…` (kills, here, batch 1's "a one-word segment is normal")
- a **vocative**: `يامراؤون تعرفون أن تميزوا` · `يا مرائي ألا يحل` · `يا أورشليم ياأورشليم يا قاتلة الأنبياء`
- a **بل / negation-correction**, an **أما…** contrast, a **new imperative after a declarative**:
  `من مائدة الغني بل كانت الكلاب` · `فلا يكون هكذا فيكم بل من أراد` · `عندهم موسى والأنبياء ليسمعوا منهم` ·
  `احترزوا لأنفسكم وإن أخطأ إليك أخوك` · `قم وامض إيمانك خلصك` · `هوذا هناك لا تذهبوا ولا تتبعوا`
- an **asyndetic new predication with a new subject**: `وإذ قال هذا أخجل جميع الذين كانوا يعاندونه وفرح كل
  الجمع` · `كما كان في أيام لوط كانوا يأكلون ويشربون`

**Everything that DOES cut at a verse end, however mid-sentence it lands** — each one a miss of mine:
- between a **speech frame and its quote**: `وقال لهم ‖ ها نحن صاعدون إلى أورشليم` · `فقال لهم ‖ اجتهدوا
  أن تدخلوا`. **In family B1 the verse boundary outranks the forward-welding frame law of batches 1–5.**
- before **قائلين / قائلا**: `تذمروا على رب البيت ‖ قائلين هؤلاء الآخرون` · `فوقفوا من بعيد ‖ ورفعوا صوتا
  قائلين`
- inside a **descriptive / relative tail**: `مضروبا بالقروح ‖ ويشتهي أن يشبع`
- inside a **same-subject و-chain**: `يمجد الله بصوت عظيم ‖ وخر على وجهه`
- before a **لأن** explanation: `إلى بيت أبي ‖ لأن لي خمسة إخوة`
- before a **كما** comparison: `فليكن لكم عبدا ‖ كما أن ابن الإنسان لم يأت ليخدم`
- inside a **من…ومن parallel**: `فليكن لكم خادما ‖ ومن أراد أن يكون فيكم أولا`
- before a **ولا / و coordination continuing the same predicate**: `بمراقبة ‖ ولا يقولون هوذا ههنا` ·
  `فيحكمون عليه بالموت ‖ ويسلمونه إلى الأمم`

**RULE — the practical verse detector, for when the numerals are gone.** A Van Dyck verse runs ~11–14
tokens (measured: 10.4 · 11.1 · 11.6 · 12.9 · 14.5 across the five keys, and the genealogy's three-verse
cycle `وعاش X n سنة وولد Y ‖ وعاش X بعد ما ولد Y m سنة وولد بنين وبنات ‖ فكانت كل أيام X سنة ومات ‖`
is a metronome). **The diagnostic inversion to remember: the printed full stop tends to fall in the MIDDLE
of a verse, and the verse boundary tends to fall at a juncture my prose rules call comma-grade.** So when
a Bible document forces a choice near the 12-token mark, prefer the comma-grade juncture over the full
stop. That single reversal converts all 54 of this topic's errors.

**RULE — a genealogy or register passage is the same law, not a stricter one: the verse is the record, and
coordination inside a record is comma-grade however heavy.** The و that adds وولد / ودعا / ومات continues
one man's biography; لأن, قائلة/قائلا, التي-relatives, بعد ما adjuncts and bare-noun series are all
internal. My only two errors in that document were the two intra-verse asyndetic predications I let my
"cut at an internal full stop" law talk me into.

---

### poetry (5 documents, 28 errors)

**RULE — RHYME IS NOT A BOUNDARY DETECTOR. It is a confirmation once the line lengths are known.**
Internal rhyme inside a printed line — tasrīʿ in a muṣarraʿ opening, and the internal echo that Arabic
children's lyrics use constantly — is ordinary, and a rhyme word in mid-line does not cut. Twenty-five
false cuts, and the whole of my worst poetry score:
- `لعب وإثارة في الملعب فانتظروا الشارة ‖` — ONE segment. `وإثارة` rhymes with the line-final `الشارة`
  and sits mid-line. I cut it on every one of the six refrain repetitions.
- `أجمل أوقاتي هي حين أمارس كرة اليد ‖ هي حلم حياتي فيها اللعب وفيها الجد ‖` — TWO segments. `أوقاتي`
  and `حياتي` rhyme with each other and both sit mid-line. I cut both, twice each.
- `أين تراني أين مكاني ‖` — ONE segment, two rhyming parallel questions in one line. This also KILLS my
  doc_7f77a81d1a7a clause "a direct question inside a line still closes (the one place internal
  punctuation outranks the line)": in family B1 nothing outranks the line.
I had this rule right already — doc_b9371c2fbb78's law says "tasriʿ in a musarraʿ opening line is an
ornament inside one printed line, not a line end" and scored 100.0 on 133 boundaries. Sixth batch running
that I lost sites my own record had solved.

**RULE — in a printed-line register NOTHING shields, including syntax. This AMENDS batch 6's family-B
dictum "subordination shields; discourse relations do not" — that dictum is true of family B2 (dialogue)
and false of family B1 (verse).** What changed and why: I wrote the shielding clause into my own
doc_bb10be35e0fa law as clauses (iii) and (iv) — "the أن-complement under نعلم and the gapped coordination
لن يعيدنا الأمل … بل العمل still shield" and "I do NOT cut inside a clause between a verb and its own
complement, however good the rhyme looks" — and both clauses were refuted at every site:
- `نعلم أنا لن يعيدنا الأمل ‖ من عالم الديجتال ‖ بل العمل معا ‖` — THREE segments, twice over. The line
  splits the verb from its PP complement and splits the negation from its بل-correction.
- `يدا بيد بحثا عن الطريق هيا ‖` — and the interjection `هيا` is the tail of that line, not its own
  utterance (family B2's standalone-interjection rule does not reach into B1).

**RULE — a line may strand a PP from its verb, and a و that opens a line is never itself the cut — the cut
is the word BEFORE it.** Stated in my doc_723871f7197e law and violated at its only test:
- `هيا لا تيالي ‖ بالخوف و بضلم الأشرار ‖ فالحق أنقى ‖ و السيف أمضي ‖` — I wrote
  `هيا لا تيالي بالخوف ‖ و بضلم الأشرار ‖ فالحق أنقى و السيف أمضي ‖`: attached the PP backward to its
  verb, then merged two lines whose junction was a line-initial و.

**RULE — a repeated refrain is segmented identically at every occurrence, so a wrong refrain law is
multiplied by the number of repetitions. The refrain is therefore the FIRST thing to fix and it gets the
most CONSERVATIVE (longest-line) reading available.** One analytic error about `لعب وإثارة` became ten
scored errors; one about `فالحق أنقى` became three. Corollary that follows from the consistency itself:
**a repeated block tells me its own length** — segment it once, count, and check the count against the
other repetitions and against the non-refrain stanzas before committing.

**RULE — the unit of an Arabic verse poem printed in two hemistichs is the BAYT, both hemistichs together,
closing on the rhyme; the shaṭr is not the unit.** Confirmed at 133 boundaries with zero errors, and the
proof is internal: tadwīr carries a word across the hemistich boundary (`والعصر`, `كالحمام`, `الصابون`,
`الإنسان`), where a half-line boundary would fall inside a single token. Bare poem titles are each their
own segment. Inside a bayt nothing cuts; across a bayt boundary everything cuts — a speech frame from its
quote, a bare-noun series, a simile, a protasis from its apodosis.
**But a sung lyric is not printed in hemistichs and its lines run 2–5 words**; there the bayt reading
over-merges. The tell is the strophic shape: a lyric has a refrain and short breath-lines; a qaṣīda has a
constant metre and a single rhyme running to the end.

**RULE — a two-zone poetry document gives each zone its own family, and the prose coda is FAMILY A with
the ordinary و-sort — where a و + new grammatical subject that continues the SAME instruction does not
cut.** My other error in doc_7f77a81d1a7a:
- `…حسب مجيئها في الحروف والأسماء والأفعال والمجتهدون منكم سيعرفون سبب مجيء هذه الألفات مقصورة ‖` — ONE
  segment. I cut before `والمجتهدون` on "و + new subject + new remark". CONFIRMS batch 4's demotion of the
  و-sort: a new nominal subject is not a trigger; a NEW EVENT or NEW TOPIC is, and an appraisal of the
  exercise just set is the same move.

---

### exercise (5 documents, 6 errors — 3 documents at F1 100.0 on 99–100 boundaries)

**RULE — the STEM absorbs every word that is COMMON to all the options; the boundary falls exactly where
the options begin to DIFFER — and this cuts inside an iḍāfa.** Both of my off-by-one clusters, and a
genuine correction to the record: my batch-6 and batch-7 laws said "iḍāfa compounds (`زيت الزيتون`,
`قصب السكر`) stay whole inside a slot", which is true only when the whole iḍāfa is the option. When the
iḍāfa HEAD distributes over every option, the head belongs to the stem.
- `يصنع الصابون من زيت ‖ الزيتون ‖ دوار الشمس ‖ السمسم ‖` — the key's stem ends on `زيت`, because the
  three options are *olive / sunflower / sesame* and the oil is shared. I read `زيت الزيتون` as the first
  option and produced a matched false-cut + missed-cut pair.
- `تم إنشاء أول أسطول إسلامي في بلاد ‖ الشام ‖ العراق ‖ شمال افريقيا ‖` — same shape; `بلاد` distributes.

**RULE — a trailing adverbial belongs to the option it FOLLOWS, not to the option that follows it; and the
unambiguous later options are the PARALLELISM TEMPLATE that places the first, ambiguous one.**
- `وصل المسلمون في فتوحاتهم شرقا حتى ‖ جنوب فرنسا شرقا ‖ غرب الصين ‖ جنوب السودان غربا ‖` — the third
  option `جنوب السودان غربا` shows the shape (place + direction), which fixes `شرقا` to the first option.
  I attached it forward and lost two sites.
**The general discipline this yields for every worksheet: options in one block are morphologically and
semantically PARALLEL. Solve the last, cleanest option first, use it as a template, and let it place the
stem→first-option boundary — never the other way round.** Together with the block's option count (three
options per item is this corpus's commonest fixed shape) this makes the ambiguous cases mechanical.

**CONFIRMED — the worksheet law that worked, zero errors across 299 boundaries in three documents:**
- Exactly two kinds of segment and nothing else: (1) the STEM — the entire run from the end of the
  previous option to the first option of the new block, ONE segment however long, however narrative,
  across internal full stops, swallowing quoted Qur'an and hadith, embedded scenarios, definitions,
  announced example lists and the closing commentary on them; (2) EACH OPTION, one segment apiece. ✓
- The stem closes exactly where the options begin **even when it breaks off mid-phrase** — on a
  preposition (`في`, `من`, `بتاريخ`, `باسم`, `على`, a stranded `ل`), a particle (`عدا`, `حتى`), a copula
  (`هو`, `هي`), a fused preposition (`بفرض`), a possessed noun (`وأمه`), or a head noun awaiting its
  complement (`العصر`, `خليفة`, `اسم`, `مفهوم الزراعة`). ✓
- Every option is its own segment however short — one word (`الوضوء`, `الشورى`, `الحرية`, `فأس`, `عكا`,
  `غزة`) or one numeral (`11`, `17`, `20`, `14`). ✓
- For a true/false item, `صح` and `خطأ` are two complete data of the same kind and therefore TWO
  segments, not one answer field. ✓
- No connective in a worksheet is clause-grade: not و in a coordinated noun/adjective series
  (`المعابد والمقابر`, `الأوراق و الساق`, `السمسم و القمح`), not the internal و of a dual construct, not
  حيث, not purpose لـ, not أو, not حتى, not a relative clause, not an أن-complement. ✓ And an internal
  diagnostic worth taking every time: **option junctures in these documents are ASYNDETIC, so a و is
  evidence of coordination INSIDE a slot and never of an item boundary** (43 of 43 unambiguous junctures
  in doc_1c49614cd6bc). ✓
- Everything inside one option or one stem stays whole: iḍāfa (`قلعة عجلون`, `إمارة شرق الأردن`),
  noun+adjective, name+epithet, title+kunya, a bound honorific (`عليه السلام`, `صلى الله عليه وسلم`),
  a relative clause (`التي تؤكل ثمارها`), a conditional (`إذا منعنا عنه الماء`). ✓
- Density 2.5–6.0 tok/seg; the family-A filters 3.5 and 3.6 and the batch-5 deletion pass are irrelevant,
  as they are everywhere in family B1. ✓

---

### conversational (1 document, 1 error)

**RULE — a strip's SERIES title and its EPISODE title are ONE segment. This NARROWS batch 6's masthead law
"two complete items of the same kind split (series name | episode title)".** What changed and why: batch 6
derived that from a magazine MASTHEAD GRID, where the split data are of equal rank — two dates in two
calendars, a strapline and the magazine name, a valediction and a signature. A title block is
hierarchical, and a heading plus its specifier is one line, exactly as `الباب الأول الأسس العامة`,
`١ البداية` and the dispatch entry `سلطنة عمان بهلاء عبد الله بن خليفة الهنائي` are one line.
- `أبو الظرفاء مطلوب شاهد ‖ سيناريو محمد قنديل ‖ رسوم هانئ دراج ‖` — I cut after `أبو الظرفاء`.
**The sharpened test: two adjacent display data split only if they are of the SAME RANK. If the second
specifies, qualifies or names an instance of the first (series→episode, section→title, number→name,
place→correspondent, label→value), they are one segment.**

**CONFIRMED — the family-B2 credits + balloon law that worked (36 of 37 boundaries):** a bare LABEL holds
its value (`سيناريو` + name, `رسوم` + name); turn change closes a segment; a one-word interjection is a
whole utterance; a repeated formula is two utterances; ONLY syntactic subordination shields
(أن/ما-complements, relatives, a resumptive clitic ON the verb, عندما-protasis + apodosis, هل…أم, gapped
coordination, a vocative riding its own utterance); the family-A filters 3.5/3.6 and the deletion pass are
suspended and the pass runs in REVERSE. ✓

---

### CROSS-TOPIC RULE OF RECORD (batch 7)

**THE DIAGNOSIS IS UNCHANGED FROM BATCH 6 AND IS NOW SIX BATCHES OLD: I write an elegant
document-specific law and defend it against the key at the exact site where a rule already in this file
gives the right answer.** This batch is the most expensive instance yet, because the rule I abandoned was
not subtle — I had written "THE UNIT IS THE VERSE, not the sentence" as the law of doc_df532033acd3, scored
100.0 with it, and then in three other Bible documents wrote "THE UNIT IS THE PRINTED SENTENCE OF THE VAN
DYCK, NOT THE VERSE" and defended it with density arithmetic. Same for tasrīʿ (right in doc_b9371c2fbb78,
violated in doc_51816712b97c) and for the line-initial و (stated in doc_723871f7197e, violated in the same
document). **The concrete procedure, restated as an action: before writing any document's law, name the
topic's canonical unit, then name the standing rule my draft law contradicts, and say why THIS document is
the exception. "The density here is 10.8, which is the family-A prose band" is not a reason — density is
downstream of the unit, not upstream of it.**

**WHAT DENSITY IS FOR, finally settled.** It is (a) a check on my COUNT in family A, never a licence to
place a cut (batch 4/5); (b) the family sorter for sources with NO canonical unit (batch 6); (c) **nothing
at all where the unit is canonical** (batch 7). A Bible verse and a narrative sentence are both ~12
tokens; the two laws are opposite; density cannot tell them apart and must not be asked to.

**THE BIAS TABLE, by family, superseding every global statement about my error profile.**
- Family A prose: I over-cut ~10–15%; run the batch-5 deletion pass.
- Family B1 canonical unit: I have no bias — I have a failure mode. I either name the unit (F1 100) or
  substitute a syntax/rhyme law for it (F1 60–83). There is no middle. The pass to run is not deletion or
  splitting but **verification: count my boundaries and check the count against the source's own unit
  count** (verse count, refrain repetitions × line count, options per block).
- Family B2 utterance: I under-cut; run the batch-6 splitting pass in reverse.

**A NOTE ON WHAT THE THIRTEEN PERFECT DOCUMENTS HAVE IN COMMON.** In every one I stated a law that was
purely mechanical and checkable against the text without judgement — "cut at every fāṣila", "one segment
per bayt or title", "one stem plus one segment per option", "the boundary count must equal the verse
count". In every failing document my law contained a judgement word: *complete predication*, *narrative
beat*, *the printed sentence*, *rhyme word*, *stands alone as an utterance*. **In family B1 a law that
requires me to judge is a law that is wrong: the unit is a fact about the page, so the law must be a
counting rule.**

---

## BATCH 8 — 11 docs, all [exercise]: doc_617f4fad2251 · doc_72b8decfdb8c · doc_74177f9e1015 ·
## doc_741bfb3bda19 · doc_7825ac72ea71 · doc_cddb10bd6b23 · doc_d30b2fb502db · doc_e438f8ad8abe ·
## doc_eb9893e8f98b · doc_f60bd3a48b58 · doc_fe3b2556a241
(the eighth set I have absorbed — batches are numbered in the order I received them, nothing above is renumbered.)
Scores: 100.0 · 100.0 · 100.0 · 100.0 · 98.4 · 99.5 · 99.5 · 100.0 · 100.0 · 100.0 · 100.0 — chunk mean F1 99.8.
Cuts made vs. key: 68/68 · 67/67 · 100/100 · 67/67 · 95/94 · 101/100 · 99/100 · 62/62 · 95/95 · 100/100 · 96/96.
**5 errors on 950 boundaries: 3 FALSE CUTS, 2 MISSED. Eight of eleven documents at F1 100.0.**
Grader line: `juror0: 112 docs graded | mean F1 91.89 (P 95.00 / R 90.77)`.

### THE HEADLINE — THE FAMILY-B1 COUNTING LAW IS PROVED; ITS WHOLE RESIDUE IS THE PRINTED LINE
Batch 7 said "in family B1 a law that requires me to judge is wrong; the law must be a counting rule."
This batch is that claim tested at scale: eleven worksheets, one identical law stated as pure arithmetic
(*n* stems + *m* options = *n*+*m* segments), **950 boundaries, 5 errors, and no error anywhere in the
mechanism** — not one stem/option confusion, not one و mis-sorted at a real juncture, not one true/false
block miscounted. The law is now the most reliable thing in my record and I should stop re-deriving it.

**All five errors are the same single fact, and it is the deepest correction in this batch: the canonical
unit is the printed SLOT — a line or a cell of the layout — and "the option" is only my proxy for it.
Where the logical option and the printed line diverge, THE LINE WINS.** Three shapes of divergence, all
of which I got wrong by reasoning from the option instead of the line:
- an option **longer than its line wraps**, and the wrap is a second segment;
- **two short asyndetic phrases share one line**, and that line is one segment;
- the **last option of a block and the next block's stem share a line**, and that juncture is unmarked.

---

### exercise (batch 8)

**RULE — an option that overflows its printed line SPLITS at the wrap, and the wrap falls at a phrase
boundary (typically a trailing PP). This is a genuine exception to batch 7's "a trailing adverbial belongs
to the option it FOLLOWS", and the two are reconciled by the line, not by syntax.** My only missed cut in
the batch (doc_d30b2fb502db @262):
- `… ‖ استخدام السخان الكهربائي بدلا من السخان الشمسي ‖ في تسخين الماء ‖ تمزيق القصص بعد قراءتها ‖` —
  the key gives `في تسخين الماء` its own segment. I welded it to the option under the batch-7 rule.
The tell, and it is checkable: **that option was visibly longer than every sibling option in the block, and
the leftover is a self-contained PP.** Batch 7's trailing-adverbial rule is for a SHORT adverbial that
keeps the option inside one line (`جنوب السودان غربا`); this is the overflow case.

**RULE — asyndeton is a CANDIDATE detector for slot boundaries, never a boundary in itself. The block's
OPTION COUNT is what places them. In a "which combination" item, whose options are built out of the same
recurring phrases, an asyndetic juncture can fall INSIDE one option.** Two of my three false cuts
(doc_7825ac72ea71 @65, and the matched miss @79):
- key: `… ‖ تجنب الانفعالات التحكم بالمشاعر ‖ بناء علاقات ودية وتقبل الرأي الآخر و تجنب الانفعالات و التحكم
  بالمشاعر ‖ بناء علاقات ودية وتقبل الرأي الآخر ‖ تناول الأدوية ‖`
- mine: `… ‖ تجنب الانفعالات ‖ التحكم بالمشاعر ‖ بناء علاقات ودية وتقبل الرأي الآخر ‖ و تجنب الانفعالات و
  التحكم بالمشاعر بناء علاقات ودية وتقبل الرأي الآخر ‖ تناول الأدوية ‖`
The three practices (تجنب الانفعالات · التحكم بالمشاعر · بناء علاقات ودية وتقبل الرأي الآخر) RECUR across
the options: the item asks which combination is correct, so each option is a *set* of them. **The recurrence
of a phrase across the run is the tell that I am in a combination item; once I see it, the partition is
fixed by the option count and by which combinations are distinct — not by where the asyndeton falls.**

**RULE — I must never cut before a و, bound or free-standing, at a worksheet juncture. Seventh batch
running that I violated a law I had written down in the same document.** My third false cut
(doc_7825ac72ea71 @73) fell immediately before the free-standing `و` of `و تجنب` — and my own derived law
for that very document says, verbatim, "not any و — bound (والاختلاف, وتنتج…) or free-standing (74, 77);
option junctures are ASYNDETIC." The spacing of a و carries no information: `وتقبل` and `و تجنب` sit inside
one option side by side. **The check: before committing any worksheet boundary, read the token to its right;
if it is و, delete the cut, no argument.**

**RULE — the juncture between the LAST option of one block and the NEXT block's stem is occasionally
unmarked in the key (~1 per 100 boundaries), because the two share a printed line. There is no tell I can
find, so I do not chase it — but a +1 count discrepancy against the block arithmetic is the flag.**
(doc_cddb10bd6b23 @444: the key runs the last option `عندما تكون حالة الطرق والحالة الجوية جيدة` straight
into the next stem `كم البعد الذي يجب عليك الحفاظ عليه…`.) I cut 101 where the arithmetic of 20 blocks
predicted 100; the discrepancy was visible before grading and I did not act on it.

**CONFIRMED — the worksheet law that worked, now at 950 boundaries across 11 documents:**
- Exactly two kinds of segment and nothing else: (1) the STEM — the whole run from the end of the previous
  option to the point where the options begin, ONE segment however long, however narrative, swallowing
  scenarios, definitions and their tag, quoted Qur'ān with verse numerals, speech frames, riddles, the
  question marker `س`, bound honorifics and every internal connective; (2) EACH OPTION, one segment
  however short — one word, one letter, one numeral, an iḍāfa, a noun+adjective, a full personal name, a
  numeral+unit, a و-coordinated pair. ✓
- The stem absorbs every word COMMON to all options and closes exactly where they begin to DIFFER, mid-phrase
  if need be: a stranded preposition (`في`, `من`, `بحثا عن`, `من أجل`), a fused preposition (`بال`), a copula
  (`هو`, `هي`, `فمن هو`), a quantifier, a governing masdar, a possessed noun (`واجبي`), a head noun awaiting
  its complement (`إرشادات`, `تاريخ`, `على يد`, `للأكسجين`, `الرعي`), a stranded definite article (`ال`). ✓
- Absorption is decided by PRINTING, not by meaning: a word printed ONCE that all options need goes to the
  stem; a word printed ONCE PER OPTION (`وادي` ×4, `الحوار` ×4) stays in each option. ✓
- A true/false item is a TWO-option item: `صح` and `خطأ` are two segments, so the block is 3. `يعجبني` /
  `لا يعجبني` likewise. A three-option MCQ is 4. Blocks with a fixed shape (four discrete named entities
  per block, ×20) are pure arithmetic. ✓
- No connective is clause-grade: not و, not أو, not لأن, not أن, not إلا بعد, not حتى, not حيث, not purpose
  لـ, not a relative الذي/التي, not عندما, not a conditional. The family-A filters 3.5/3.6, the deletion
  pass, the splitting pass and the whole و-sort are irrelevant, not suspended. ✓
- Measured density 2.43–4.77 tok/seg, inside the worksheet band 2.5–6.0 — and it decided nothing, as it
  should not. ✓

---

### CROSS-TOPIC RULE OF RECORD (batch 8)

**THE CANONICAL UNIT IS ALWAYS A UNIT OF THE PAGE, AND THE PAGE IS A LAYOUT OF LINES AND CELLS — this
generalises step −1 and is worth more than any single topic rule.** The āyah, the Bible verse, the bayt, the
masthead field, the worksheet slot and the constitution article are all the same object seen in different
sources: **the smallest thing the printer put on its own line.** Every family-B1 law I have is a guess at
that object, and every family-B1 error I have ever made is a place where I substituted a logical unit
(a sentence, a rhyme, an option, a syntactic constituent) for a typographic one. So when a B1 count comes
out wrong by one or two, the question is never "did I mis-parse this" but **"which line did I merge, and
which line did I invent."**

**THE VERIFICATION PASS IS NOW MANDATORY IN B1, NOT OPTIONAL — and it must run BEFORE I commit, not after.**
Batch 7 named it ("count my boundaries and check the count against the source's own unit count") and this
batch shows what it is worth: two of my five errors (`+1` in doc_cddb10bd6b23, `−1` in doc_d30b2fb502db)
announced themselves as a one-off discrepancy against the block arithmetic, in documents where every block
was otherwise mechanical. The pass, stated as an action: **count the blocks, multiply by the block shape,
compare to my boundary count, and if it differs by one, hunt for a merged or invented LINE — not for a
mis-sorted connective.**

**AND THE STANDING DEFECT IS NOW EIGHT BATCHES OLD, in its purest form yet.** Not one of this batch's five
errors was a place where the record was silent. `و` is never a worksheet boundary — written in my own law
for the document where I broke it. The option count anchors the partition — batch 7's parallelism-template
rule. The line, not the option, is the unit — implied by every B1 law I have. **The record does not fail;
I fail to consult it at the site. The one habit that would have caught four of five: at each committed
boundary, read the token to its right and name the rule that licenses the cut.**

================================================================================
## BATCH 9 (final training, batch A of 4) — 8 docs, mean F1 86.3. THE BIAS FLIPPED.
Scores: 0de3 83.6 (P 76.7/R 92.0) · 16f2 87.5 (86.2/88.9) · 201b 89.3 (81.8/98.2) · 32b8 91.1 (85.7/97.3)
· 39e4 87.0 (78.9/96.8) · 4114 88.2 (88.2/88.2) · b592 80.0 (93.8/**R 69.8**) · c0ad 83.9 (81.2/86.7).
Six of eight documents: recall 87-98, precision 77-88. **I no longer under-cut expository. I OVER-cut it,
and the instrument that made me do it is my own E2 list.** 87 errors; 55 of them are false cuts.

### L9.1 — E2 IS MOSTLY WRONG. The connectives it says "CUT in expository" do not cut.
Every single E2 site I cut at in modern/scholarly prose was a FALSE CUT:
- **حيث** — false @160 (`كما توسع نطاق الأساليب العلمية الاجتماعية | حيث يعتمد الباحثون`), false @452
  (`…الحقبة المتأخرة للإمبراطورية | حيث كانوا يقومون بعتق عبيدهم`).
- **إذ** — false @222 (`…غزو الأوروبيين للعالم الجديد | إذ لم يحدث`), false @806 (`فذلك الاستعداد هو صورته |
  إذ ليس ها هنا إلا جسم`). I *flagged* this one in my own reasoning as the site where E2 fought N5. N5 WON.
- **كما / كما أن** — false @582, false @414. (But `كما أن إحسان عباس…` at 101/128 survived — كما cuts only
  when it opens a genuinely new datum sentence, i.e. when the source started a sentence with it.)
- **ولكن / ولكنا / ولكننا** — false @66, false @416, both in scholarly prose. `ولسنا نقصد أن X ولكنا نقول
  إن Y` is ONE segment: the deny→correct pair held, exactly as N4 said and I overruled.
- **وقد + perfect** — false @606, @792, @830 (201b) and @177 (32b8). FOUR false cuts from one rule.
  **وقد + perfect NEVER opens a segment.** Kill this from E2 outright.
- **inferential ف in MODERN prose** — false @30 (`حول العالم | فلذلك تكون`), false @331 (`تحدي الحداثة |
  فالعالم كان يتحول`), false @791 (`مثل الماء | فإنه إذا أفرط`). E4's ف-cuts belong to CLASSICAL
  argumentative prose only, and even there only some (see L9.4).
- **غير أن** — does not open: @437 `ولا يمكن أن يعرى عنها غير أنها لتعاقبها عليه تبين له` is one segment.

### L9.2 — E5's "parallel series with a new subject cuts" is wrong for ENUMERATIVE APPOSITIVES.
False @641 + @648: `…في الاجتماعات السابقة الأولى هي حمل الكرة باليد والجري بها والثانية هي إعاقة اللاعبين
… في الرجبي` is ONE segment — الأولى / والثانية are an inline appositive list, not two sentences.
False @739 + @752: `تقرر إضافة مجالين آخرين للجائزة أحدهما في الطب … والآخر في العلوم …` — ONE segment.
Counter-case: MISSED @470 in Ibn Tufayl, where `مركب على الحقيقة من معنيين ‖ أحدهما يقوم منه مقام الطين`
DOES cut. So: **أحدهما/والآخر/الأولى/والثانية after a stem that PROMISES a list stay inline; the same
words cut only in classical prose where each becomes a full argumentative step.** Default = merge.

### L9.3 — وأن-chains are shielded. Full stop. My E5-based cuts were all false.
False @152, @161 (`أن هذه الأربعة يستحيل بعضها إلى بعض وأن لها شيئا واحدا … وأن ذلك الشيء ينبغي…` = ONE
segment) and false @348 (`أن وراء هذا الامتداد معنى آخر … وأن الامتداد وحده لا يمكن…` = ONE). I invented a
"new subject inside an أن-complement is a step" law against N5's plain shielding rule — D1 firing again,
fourth batch running. **Everything inside an أن / إن / بأن complement is shielded including every وأن link.**

### L9.4 — What DOES cut in classical argumentative prose (Ibn Tufayl, key 14.1 tok/seg).
MISSED @308 `…على الامتداد المذكور ‖ ويكون بالجملة خلوا من سائر الصور` — a وي- verbal clause cuts.
MISSED @322 `ثم تفكر في هذا الامتداد إلى الأقطار الثلاثة ‖ هل هو معنى الجسم بعينه…` — **a direct QUESTION
is its own segment even inside an argument** (N6's question rule reaches expository).
MISSED @405 `لتبدل ذلك الطول وذلك العرض وذلك العمق ‖ وصارت على قدر آخر…` — و + new perfect verb cuts.
MISSED @431 + false @436: the cut is BEFORE `ولا يمكن أن يعرى عنها`, not after it. **ولا / ولم + a parallel
negation DOES cut** — and I had drawn that cut and then DELETED it in the D4 pass. Same at MISSED @670
(`…يصدران عنه وعن صورته ‖ ولم يعرف من صورته…`), also a cut I drew and deleted. D4 cost me two recall points.
False @114 (`…بعضها أبسط من بعض فقصد منها…` merges) vs surviving @105 (`فأخر التفكير في صورهما ‖` stands):
even inside one document the inferential ف is a coin-flip. Treat ف as med at best, never hi.

### L9.5 — E7's "loose heritage register, 18-25, merge" is a DISASTER. It cost R 69.8 on b592.
The 1922 appreciation of Rihani runs **16.5 tok/seg in the key**, not 22, and it is my worst document of the
batch. Eleven missed cuts, all of one shape: **an ornate appreciation is a STACK of short predications and
epithet groups, each its own segment.** The key cuts:
  `…والمؤلفات الإنكليزية والعربية ‖ كاتب رشيق العبارة متين التركيب ‖ يطرب بأسلوبه كما يسكر بآرائه الفلسفية ‖`
  `أفرنجي الأسلوب عصري الأفكار راقي الخيال والوصف والابتكار ‖ يبتكر بكتاباته … والجاهلية القديم ‖ ينظم الشعر…‖`
  `يعجب لهذا الاجتماعي الكبير ‖ ويفتخر به لأنه شرقي راق…`
I read those as one comma-series because a LATER stretch (`مقر بضعفه صادق بحديثه مسامح…`) genuinely is one.
The difference: **an epithet run with NO finite verb is one segment; the moment a finite verb heads the
group (يطرب · يبتكر · ينظم · ويفتخر), it is a new segment.** Also in the same doc: MISSED @558, @621, @695 —
**وهو + a VERBAL clause always cuts** (وهو يكتب ويؤلف · وهو يجتهد · وهو لا يزال), while وهي + a bare NP
predicate does not (@170 `وهي البطولة الأهم دوليا` merged, correctly).

### L9.6 — F2 is wrong about title-page labels. The label KEEPS its name.
False @4, @7, @11: the key reads `تأليف باتريسيا ديلبيانو ‖ ترجمة أماني فوزي حبشي ‖ مراجعة عز الدين عناية ‖`.
**A function label + its value is ONE segment on a book title page.** What I had backwards is the numeral:
MISSED @23 — the bare section number `1` IS its own segment (`… العبودية الحديثة ‖ 1 ‖ العبيد والخدم …`),
the exact opposite of F3's "a numeral is meaningless alone". A chapter ordinal above its title DOES split
(`الفصل الأول ‖ من العبودية القديمة إلى العبودية الحديثة ‖` — both my cuts survived). And my footnote
reasoning was RIGHT: the marker `1` closes the sentence it annotates (@153 survived).
Also MISSED @878: `وفي محكم التنزيل ‖ فلم تقتلوهم ولكن الله قتلهم…` — **a bare PP quotation frame is its own
segment; it does NOT weld forward like a verbal frame (قال/ذكر) does.**
Also MISSED @174 (`500 م ‖ بل وترك القانون الروماني…`) — **بل after a completed sentence OPENS a segment**
(distinguish: بل inside a لم…بل pair does not). MISSED @439: **حتى أن opens a segment.** MISSED @400:
**ومن ثم opens a segment.**

### L9.7 — Comic / balloon page (4114, F1 88.2, errors balanced 4/4).
MISSED @0: `ماجد ‖` — the MASTHEAD NAME is its own segment; I merged it into the first teaser.
False @18: `درهم أنا لست بخيلا ‖` is ONE segment — the price and the slogan share a printed line.
False @26: `مسابقة الطفل الجميل كوب حليب مجانا لكل الأطفال ‖` is ONE segment — **a poster HEADLINE plus its
immediate SUBLINE is one unit** (C4's rank test, which I named and then overrode).
MISSED @38: `انظروا من سيشارك في المسابقة معنا ‖ آخر العنقود ‖` — **a trailing NAME after a complete
utterance is its own line**, the mirror of the pre-posed vocative that welds forward.
False @57: `هذا يقول إنك لن تفوز لأنك مدلل ويكفيك مداعبة دميتك ‖` — **لأن does NOT split a balloon.** C2's
"explanatory لأن splits" is wrong; only turn changes and separate speech acts split.
MISSED @67 + false @68: `سأجعله يرى ‖ الآن لا فرصة لديه للفوز ‖` — **a fronted time adverbial in balloon
dialogue opens the NEXT utterance**, even before a non-finite clause. My N5 "needs a finite clause" test
does not apply in B2. Third batch in a row I mis-place a fronted adverbial (D3).
MISSED @91: `هه ‖ حسنا ‖ خذ المزيد منه ‖` — حسنا IS a whole utterance. I had drawn that cut and deleted it
because it "felt too fine". C1 said it plainly. **Stop overriding C1/C4 by feel.**

### L9.8 — The real density map, measured from this batch's keys.
classical argumentative (Ibn Tufayl) 14.1 · ornate heritage appreciation 16.5 · encyclopaedic Wikipedia
18.6-21.2 · fact-file Wikipedia with dual dates 20.7 · translated academic book 20.0 · scholarly
art history 25.0 · comic balloon page 3.8 (mine matched). **The spread inside "expository" is 14-25, and
knowing the topic label tells me nothing. What sets it is CLAUSE LENGTH in the source, not floridity.**

### L9.9 — The meta-lesson, and it is the same one as batch 8.
D1 fired four times (L9.3's invented وأن law; overriding N4 at @66; overriding C4 at @26; overriding C1 at
@91). D4's deletion pass cost me 2 recall points on cuts I had correctly drawn (@431, @670). And E2 —
a list I wrote to fix a recall hole — is now the single largest source of my errors. **A rule written to
correct a bias becomes the bias.** E2, E5 and E7 all need demotion; N4, N5, C1, C4 all need restoring.


================================================================================
## BATCH 9B — 8 docs, mean F1 86.9. The merge correction WORKED where I applied it; it FAILED where I
## substituted a register guess for a measurement. 34 errors (down from 87).
Scores: 085c 89.4 (P 91.3/R 87.5) · 3ccbb 94.1 (88.9/100) · 75aef 93.3 (100/87.5) · 8d06 96.0 (92.3/100)
· **ade63 71.4 (83.3/R 62.5)** · b8fa 90.9 (83.3/100) · **e1435 74.1 (P 58.8/100)** · fb2e 86.1 (75.6/100).
The three good expository scores are the batch-A correction paying off. The three bad ones are all the same
mistake in different directions: I guessed the grain instead of measuring it.

### L9B.1 — HADITH, at last, from two graded keys. عن NEVER CUTS.
e1435 key = 10 cuts, mine 17, P 58.8. b8fa key = 5, mine 6. Every false cut was an عن-link (@20, @24, @29,
and @22 in b8fa). The key's isnād for e1435 is:
  `حدثنا عبد الله بن محمد ‖ قال حدثنا أبو عامر ‖ قال حدثنا سليمان بن بلال المديني عن ربيعة بن أبي عبد الرحمن
   عن يزيد مولى المنبعث عن زيد بن خالد الجهني أن النبي صلى الله عليه وسلم سأله رجل عن اللقطة ‖ فقال …`
**So: cut ONLY before a قال that introduces a fresh حدثنا/حدثني. The entire عن-chain, plus the أن/عن-frame,
plus the questioner's setup, is ONE segment ending immediately before the matn's قال/فقال.** H2's "expect
4–6 tok/seg in the isnād" is KILLED — the measured hadith density is **9.3 and 8.8 tok/seg**, not 5.
### L9B.2 — The matn is much coarser than H3 said, and N6's question rule does NOT reach it.
e1435 key matn: `فقال اعرف وكاءها أو قال وعاءها وعفاصها ‖ ثم عرفها سنة ثم استمتع بها ‖ فإن جاء ربها فأدها
إليه ‖ قال فضالة الإبل فغضب حتى احمرت وجنتاه أو قال احمر وجهه ‖ فقال وما لك ولها معها سقاؤها وحذاؤها ترد
الماء وترعى الشجر ‖ فذرها حتى يلقاها ربها ‖ قال فضالة الغنم قال لك أو لأخيك أو للذئب ‖`
- **A direct QUESTION does not close a matn segment** (`فقال وما لك ولها معها سقاؤها…` is one 11-token unit).
- **A question and what follows it MERGE — answer or reaction alike** (`قال فضالة الإبل فغضب حتى احمرت…`).
  H4 is not a special case; it is the general matn rule. CONFIRMED at `قال فضالة الغنم قال لك أو لأخيك…`.
- **Not every ثم cuts**: one cut before the first ثم, none before the second.
- I DID get the b8fa question/answer split right (@36 survived), so a Companions' question that opens with a
  double frame `قال قالوا …` and is answered by a fresh `قال` + the ruling DOES split. The discriminator:
  a rapid-fire exchange inside a narrated scene merges; a formal question-and-ruling pair splits.

### L9B.3 — بينما OPENS a segment. في حين does not. Two graded misses now say so.
MISSED @154 (ade63): `… محسوب على السعودية ‖ بينما خالد خوجا محسوب على قطر …`. MISSED @168 in batch A
(32b8): `… وكان ذلك بالمشاركة ‖ بينما كانت جانيت راولي …`. Both times I merged it backward on N5's
authority and both times the key cut before it. Meanwhile FALSE @300 (085c): `… وادعاءات أبولينير في حين
كان تأثير السوبرماتية …` merges. **Move بينما out of N5's BACKWARD list; keep في حين in it.**

### L9B.4 — Two more openers I merged and shouldn't have.
MISSED @138 (ade63): `… اختيار هيئة رئاسية جديدة ‖ وهناك مسعى للتوصل إلى صيغة توافقية ‖` — **و + هناك
existential cuts**, and it cut even though I had it inside a قال…أن complement. My E6 shielding stops at the
point where the journalist resumes in his own voice.
MISSED @466 (085c): `… عمل الآلات ‖ وكذلك في اتساق تام مع دعاوي الشاعر …` — **وكذلك opens a segment even
when it heads a GAPPED coordinated PP.** I refused this cut explicitly, calling it "a gapped PP, not a
clause". Gapping does not shield وكذلك.
MISSED @402 (085c): `… اقتصاديات الإدراك ‖ وأطلقت على أنصار هذا التوجه صفة العقلانيين ‖` — و + a new PASSIVE
verb stating a new fact cuts, even at only 7 tokens. I merged it as "no new full-NP subject". Wrong test.

### L9B.5 — NEWS DISPATCH runs 16 tok/seg and و + a new finite verb CUTS. R 62.5 is the price.
ade63: key 16 cuts, mine 12. Missed @176 (`ويتمتع … بخطاب هادئ إجمالا ‖ وكان رئيس وفد المعارضة …`), @202
(`وقد ولد في دمشق عام 1959 ‖ وأمضى غالبية حياته المهنية …`), @224 (`أما خالد خوجة فهو طبيب في الأربعينيات ‖
غادر سورية بعد توقيفه …` — the asyndetic verb after an indefinite head is NOT a صفة here), @255 (`… ليعيش مع
أخواله فيها ‖ ويتولى منصب سفير الائتلاف …` — و cuts even inside a purpose-لـ chain). **In a wire profile
every و + verb is a separate DATUM and cuts.** Two false cuts show the limits: @71 (an asyndetic سعى
continuing the same subject merges) and @236 (`… نشاط العائلة المعارض وكان لا يزال فتى صغيرا ‖` — a
backgrounding كان + لا يزال attaches BACKWARD).

### L9B.6 — And the exact opposite in a NARRATED STORY. fb2e: P 75.6, 10 false cuts, key 14.1 tok/seg.
Every false cut was a CONNECTIVE JOIN that I mistook for a break. The key's units are PAIRS of short clauses:
  `كان من الخلدونيين العديد من الوزراء والأمراء أما والده فقد انصرف عن وظائف الدولة وتفرغ للعلم ‖`
  `ولما رزق بابنه راح يعلمه ويؤهله لحياة هادئة ولم ينتظر أن يكون رحالا ومغامرا تلاحقه … والنكبات ‖`
  `كان قوي الفهم وشديد الإقبال على العلم لكنه وهو في السابعة عشرة من عمره واجه أولى نكباته ‖`
  `انتشر وباء الطاعون في تونس كما انتشر بمناطق عديدة من العالم فتوفي والده وفقد عددا كبيرا من معلميه ‖`
  `ركب ابن خلدون البحر … عام 1278 م وأقام في مدينة القاهرة قاضيا ومعلما في الأزهر بقية حياته ‖`
  `طابت له الحياة بمصر لفترة حتى رأى أنها حضرة الدنيا وبستان العالم فلم يغادرها إلا للحج … بفلسطين ‖`
  `كتب في التاريخ كتابا ضخما من سبعة أجزاء شهد عدد من العلماء الأوربيين أنه أعظم عمل … الأزمان ‖`
**The ف of consequence NEVER cuts in a narrated story (4 false cuts: @124, @177, @224, @265). Nor does
mid-paragraph أما (@36), nor لكن (@103), nor ولم (@61), nor و + a new finite verb (@243), nor و + a fronted
subordinate (@322), nor an asyndetic verb that comments on the object just named (@409).** So my N1 "in the
short register every و + a complete clause is its own beat" is wrong at 8–11 and right only at ~14: the
printed sentence in a children's biography is TWO short clauses plus their connective.

### L9B.7 — The discriminator I actually need, stated once.
Both fb2e and ade63 have 4–8-token clauses. fb2e merges pairs of them; ade63 splits them. What differs is
not length but WHAT THE PAGE IS DOING: a narrated STORY joins a beat to its consequence with ف/و and prints
them as one sentence; a factual PROFILE or data listing prints each datum as its own sentence. **Ask: is the
next clause a CONSEQUENCE/ELABORATION of this one (merge) or an INDEPENDENT DATUM about the topic (cut)?**
That question, not the connective and not the token count, is the whole of family-A segmentation.

### L9B.8 — Where the merge correction worked, and the residue that cannot be predicted.
3ccbb 94.1, 8d06 96.0, 75aef 93.3, 085c 89.4 — all won by refusing E2's old connective cuts. The residual
errors are genuine coin-flips at the same site type in the same document: 085c @17 (`عمارة الحداثة ‖ ظهرت
في الاتحاد السوفييتي` — asyndetic صفة-verb CUTS) versus @65 (`عام 1920 ضمت خمس مبادئ` — asyndetic
صفة-verb MERGES); 75aef @55 (`القيمة الأخلاقية ‖ فهي توفر …` — فـ CUTS) versus batch A's three false
inferential-ف cuts; 8d06 @194 (`والاكتئاب لذلك فمن الضروري` — لذلك MERGES) versus 75aef where all three
لذلك cuts survived. **Accept ~1 error per document from source-punctuation noise; do not write a rule for it.**
### L9B.9 — Measured key densities, cumulative.
hadith 8.8–9.3 · school essay 11.1–18.0 · children's narrative biography 14.1 · news dispatch 16.4 ·
magazine fact page 17.2 · ornate heritage appreciation 16.5 · encyclopaedic Wikipedia 18.6–22.3 · fact-file
Wikipedia 20.7 · translated academic book 20.0 · classical argumentative 14.1 · scholarly monograph 25.0 ·
balloon page 3.8. **Nothing below 8.8 outside B2. When my draft comes out under 11 in family A, I am
over-cutting.**


================================================================================
## BATCH 9C — 8 docs, mean F1 87.5. I OVER-CORRECTED. The merge policy I wrote after 9B cost me recall.
Scores: 091d 87.8 (P 84.3/R 91.5) · **0a95 78.0 (77.5/78.6)** · 684c 90.7 (91.9/89.5) · 6abd 91.4 (92.5/90.2)
· 8921 86.4 (P 93.4/**R 80.3**) · 9af6 95.3 (95.3/95.3) · a045 88.9 (P 97.8/**R 81.5**) · ab45 81.8 (81.8/81.8).
94 errors, and **57 of them are MISSED cuts** — the exact mirror of 9A. Two batches ago E2 made me over-cut;
this batch my own "default MERGE" made me under-cut. D2 again, in the other direction.

### L9C.1 — KILL THE ولكن-MERGE. لكن / ولكن / لكننا OPENS a segment. Six graded misses.
MISSED @446 (`سآتي على ذكرها لاحقا ‖ لكن ما يجعل للإحراج تأثيرا قويا…`) · MISSED @840 (`نسخا مكبرة من هذه
الظاهرة ‖ لكننا في الحياة اليومية…`) · MISSED @122 in a045 (`أن يكونوا أولاد ملوك ‖ ولكني صياد فقير…`) ·
MISSED @645 + FALSE @649 in 0a95 (the key cuts BEFORE ولكن and runs it INTO what follows: `وسواء عندي أصغى
أو لم ‖ ولكن الأمر هنا مختلف فأنا شخصيا كإنسان لست راديو…`) · MISSED @281 + FALSE @275 (same shape) ·
MISSED @691 (`ولكن كل هذا لا يهم ‖`).
**So the rule is: لكن opens, and the clause it opens runs on into the following ف-clause.** The three false
cuts that made me invent the merge (9A @66، @416؛ 9B @103) all had a NEGATED or CONCEDED first half —
`ولسنا نقصد … ولكنا نقول` · `فنحن نسلم … ولكننا نظن` · `كان قوي الفهم … لكنه واجه`. **Narrow it to that:
merge at لكن ONLY inside an explicit deny/concede→correct pair (N4). Otherwise CUT.**

### L9C.2 — The ف of consequence CUTS in essay and translated-literary prose. Eight graded misses in one doc.
8921 (popular-nonfiction essay), all MISSED: @127 `فهي تلقي بظلالها` · @227 `فالتفاعل السلس` · @293 `فعبارة
أوه` · @527 `فالكاتب يدعونا` · @807 `فثمة عوامل` · @1136 `فهو ما زال باقيا` · @1165 `فالأعراس القليلة` ·
and @617 `بل يخفي بين طياته`. 684c (translated Dickens), MISSED @461 `فعلى كلا الجانبين سور رطب`. 6abd,
MISSED @290 `بل أكثر من ذلك`.
Against that, 0a95 (a novel) FALSE @30 `فأنا أحب عمتي سعدية` and FALSE @62 `فمعنى وجود القروش`, and inside
ONE stretch of 0a95 the key cuts at @402 (`فأنا أكلمهما`) and merges at @408/@419. **So: ف CUTS by default
in essay/expository/translated prose, MERGES only inside a fast narrated action run (فأخذته وحبسته · فطار
فوق الشجرة وقال · فضربها بالعصا). Treat every other ف as a med CUT, not a merge.** My 9B lesson was true
of a magazine biography and I wrongly generalised it to all narrative.

### L9C.3 — In a children's STORYBOOK, و + a new finite verb DOES cut. Nine graded misses (a045, R 81.5).
key = 54 cuts / 603 tokens = **11.2 tok/seg**, finer than my 13.4. MISSED @93 (`وأيقظت زوجها ‖ وحكت له ما
رأت`) · @177 (`لا بد أن تتحقق ‖ والأيام بيننا وسنرى`) · @216 (`وكبرت المولودة ‖ وأصبحت طفلة`) · @259
(`فكانت كسولا خاملة ‖ لا تعمل شيئا`) · @290 (`ويذهبان معا إلى البحر ‖ وتحمل معه أدوات الصيد`) · @305
(`أصبحت صيادة ماهرة ‖ فكانت تمسك بسنارة`) · @475 (`على الإطلاق ‖ ولن يرضى أن يتزوجكما أحد`) · @522
(`أندر وأثمن الحلي والمجوهرات ‖ ويحيط بي الخدم`) · @37/@40 (`الكبيرة تدعى سماء ‖ والوسطى اسمها دعاء أما
الصغرى…`). **A simple-sentence children's storybook runs ~11 and every new VERB is a new sentence — even
inside a quoted wish-list, even after a صفة chain.** Contrast 9B's magazine feature at 14.1 where the same
و merged. Discriminator: sentence LENGTH in the source, measured, not the audience.
Also 6abd MISSED @46, @55: **ثم opens a segment when it marks a new time-step** (`فارا من موت محتمل ‖ ثم
نجوت … ‖ ثم همت في البحر ووصلت`), even though ab45 FALSE @19 shows ثم merging inside one fast move
(`فأخذته وحبسته في غرفة ثم قالت للأب ابنك مات ‖`).

### L9C.4 — 0a95, my worst document (F1 78, 31 errors): placement noise, not policy.
The key runs 70 cuts / 774 = 11.1, essentially my count (71) — but the boundaries sit one clause off all over.
D3's signature, seven matched pairs: @275/@281, @402/@408, @412/@419, @499/@500, @503/@505, @565/@568,
@645/@649. In the dialogue the key reads `أنا ‖ أبدا أنا لا أبكي ‖ كذا ‖ ربما ولماذا لا تعلمني…` — a
one-word turn attaches FORWARD to the next turn's words. **When count is right and placement is wrong, no
new rule helps; what helps is trying the alternative placement at every short turn and every ف/لكن.**

### L9C.5 — SUBTITLE / LINE-LIST: a one-word item attaches FORWARD, not backward. Four graded false cuts.
091d FALSE @96 (`تبا المعذرة ‖`) · @201 (`نعم قال بأنه يفضل…‖`) · @212 (`لا لقد تفقدت الرشاشات ‖`) · @261
(`لكي يكون صادق أنا لا أستطيع التعايش…‖`) · and @22/@23/@24 show the key reading `سأحتاج إلى المزيد إذا ‖
لا أنا حقا يجب أن أرتفع ‖` and @128/@129/@130 `أجل أنا ‖ أعني لديهم نظام كاميرات…‖`. **KILLED for
line-lists: "a one-word cry is a whole utterance". In a subtitle line the interjection SHARES the line with
what follows it.** C1's rule survives only for a comic BALLOON, where the cry has its own bubble. Two MISSED
(@42 `كيف أطير ‖ و لن أنسى ‖`; @112 `على القانون ‖ ويجب ان أكون ‖`) confirm the line grain is ~5.
### L9C.6 — Comic page (9af6, F1 95.3 — my best of the batch). Three small corrections.
FALSE @4: `كسلان جدا يقدم بكل فخر ليلة بعد ليلة بعد ليلة ‖` is ONE segment — **a presenter banner and the
title it presents share a line** (C4's rank test, third confirmation). FALSE @131: `آسف يا مولاتي عندي
اجتماع في المساء ‖` is ONE balloon — an apology plus its reason is one utterance. MISSED @97: `يبدو أن
الأمير هامور عبقري ‖ اكتسب خبرة كبيرة من سكان الأرض ‖` — an asyndetic verb after a predicate ADJECTIVE
cuts. MISSED @199: `مبروك ‖ جاءك توأم ‖` — inside a balloon a congratulation and its news ARE two lines.
(So @131 and @199 pull opposite ways: the discriminator is that آسف+reason is one speech act, مبروك+news is
a greeting line plus a message line.)
### L9C.7 — The chant (ab45): FIVE lines, not three. P4's "conservative longest-line" reading was wrong here.
MISSED @56: the key reads `أنا الطير الأخضر في قبة العسكر ‖ زوجة أبي حبستني وأختي خلصتني ‖ وأبي ما يدري
عني ‖ أختي خبأتني خلف الزير اليماني ‖ وأنا صرت طيرا وبنادي ‖` — i.e. **one line per RHYME GROUP, and a
4-token line is normal.** Also MISSED @86 (`ولدا أسمر ‖ وعاشوا في هناء وسرور وصفاء ‖` — the tale-ending
formula IS its own segment, N6 after all) and FALSE @19/@44 (ف and ثم inside one fast move merge).
### L9C.8 — Cumulative measured key densities (family A).
children's storybook 11.2 · novel (first-person, talky) 11.1 · folk tale 8.4 · literary short story 12.4 ·
children's narrative biography 14.1 · translated literary (Dickens) 16.2 · news dispatch 16.4 · ornate
appreciation 16.5 · magazine fact page 17.2 · popular-nonfiction essay **17.0** · encyclopaedic 18.6–22.3 ·
scholarly monograph 25.0. B2: balloon page 5.0 · subtitle line-list 5.9 · hadith 8.8–9.3.
**Family A never comes in under 8.4, and narrative clusters at 11–12 far more often than at 14.**


================================================================================
## BATCH 9D (final) — 5 docs, mean F1 94.9. FOUR PERFECT SCORES.
1fa1 (Muʿallaqa of ʿAntara) **100.0** · 4161 (Sūrat al-Kahf, 110 āyāt) **100.0** · 91f6 (Baqara 172–185)
**100.0** · 7f0f (Āl ʿImrān 98–108) **100.0** · **02c1 74.4 (P 72.7/R 76.2)**.
Total for the 29 practice documents: A 86.3 → B 86.9 → C 87.5 → D 94.9; overall 88.3.

### L9D.1 — B1 WORKS WHEN I NAME THE UNIT AND COUNT. Four documents, 224 boundaries, zero errors.
The four perfect documents share one thing: I wrote the canonical unit down BEFORE reading a connective, then
verified the count in both directions (every fāṣila/rhyme has a cut; every cut is on a fāṣila/rhyme). M6's
"no middle" is confirmed — B1 is 100 or it is 60, and the difference is whether the law contains a judgement
word. What each perfect document required me to IGNORE is the useful record:
- **al-Kahf v.18**: I had drawn a cut at `بالوصيد`, where the printed full stop falls, and removed it — the
  count went 111 → 110. **D2's typographic-for-logical error, caught by counting.**
- **al-Kahf vv.84–86, 89–90, 92–93**: three two-and-three-token āyāt in a row (`فأتبع سببا ‖`, `ثم أتبع
  سببا ‖`). Density has NO vote where the unit is canonical.
- **Baqara v.177**: a ولكن mid-verse, in the same batch in which I rewrote E2c to make ولكن ALWAYS cut, plus
  fifteen و's and a case shift (والموفون / والصبرين), all inside one 51-token segment.
- **Āl ʿImrān v.103**: six candidate cuts inside one 34-token āyah — a ولا prohibition, three ف-consequences,
  a و + new predication, and an ASYNDETIC `كذلك يبين الله` — my most reliable prose signal, overruled.
- **ʿAntara**: the muṣarraʿ opening (متردم/توهم) is ONE bayt; three tadwīr enjambments (مؤوم | هر جنيب ·
  ضمضم | الشاتمي · واسلمي | دار) cut at the line against syntax.

### L9D.2 — CHILDREN'S CHANT: EVERY INTERNAL RHYME IS A LINE BREAK. Lines are 2–4 tokens.
02c1's key: `قال سلام ‖ يا تمام ‖ حجر إزميل أو قلم ‖ عرفوا من نحتوا أو رسموا ‖ أصغينا حدثنا الحجر ‖ عمن
نقروا ‖ عمن حفروا ‖ رسم نافر ‖ شكل غائر ‖ في أهرامات ومغاور ‖ نقش وسم ‖ رقش وشم ‖ قال سلام ‖ يا تمام ‖`.
Five missed cuts, all of one shape. **KILLED (second time): P4's "an internal rhyme PAIR sits inside one
line". In a children's chant the internal rhyme IS the break — split at every rhyming phrase, and expect
2–3-token lines.** The 9C folk-chant key (`أنا الطير الأخضر في قبة العسكر ‖`) is now the exception, not the
rule: there the two rhyme words were 4 tokens apart inside a 6-token line; here they are adjacent phrases.
Discriminator: if splitting at the internal rhyme leaves TWO grammatically parallel phrases (قال سلام / يا
تمام · عمن نقروا / عمن حفروا · رسم نافر / شكل غائر · نقش وسم / رقش وشم), SPLIT.

### L9D.3 — A GLOSSARY STRIP IS ONE SEGMENT, not one per entry. Five graded false cuts.
The key reads the whole vocabulary band as a single unit: `غائر عميق مجوف نافر بارز مغاور حمع مغارة الوسم
والوشم الرسم على الجلد النقش الرسم على الحجر الرقش التزيين ‖`. Nineteen tokens, six headword/gloss pairs,
ONE segment. **F1's "every self-contained datum splits" applies to a MASTHEAD or an IMPRINT — a stacked
column of fields — not to a footnote-style glossary printed as a running FOOTER STRIP.** The tell: the
entries run on with no label morphology and no line-per-field layout. And the exercise item that follows is
likewise ONE segment (`الرسام يرسم لوحة والشاعر يكتب قصيدة فماذا يفعل النحات ‖`) — X2's stem rule reaches
it: a question tag welded to its preamble is one slot, and my E3(i) question-cut does NOT apply inside a
worksheet item.

### L9D.4 — Where the 29 documents leave me.
Family B1 (quran, poetry-as-bayt, worksheet) is solved: name the unit, state the law as arithmetic, count
twice. Family A is not: three batches of connective policy produced 86 → 87 → 88 with the errors moving
from precision to recall and back. **The thing I still cannot do is predict a source's punctuation at a
50/50 site, and the thing that most improved my score was not a better connective rule but MEASURING the
register before writing the law (D7) and then not letting one batch's evidence become a global default (D9).**

