# Lessons — Juror 1, Arabic sentence segmentation (no punctuation)
Cumulative and append-only. Every entry is a correction I actually received.

---

## BATCH 1 (docs: doc_5eb0f458c625, doc_b15bce7039d2, doc_3762b5d5da2f — all `expository`)
Scores: doc_5eb0f458c625 F1 77.8 (P 100.0 / R 63.6); doc_b15bce7039d2 F1 84.8 (P 87.5 / R 82.4);
doc_3762b5d5da2f F1 82.4 (P 100.0 / R 70.0). 19 errors: **17 MISSED, 2 false cuts.**

### THE OVERRIDING LESSON OF BATCH 1 — I UNDER-CUT. BADLY.
Precision was 100/100/87.5 but recall 63.6/82.4/70.0. Almost every error was a boundary the key HAS and
I did not. My instinct "this is one long flowing Arabic sentence" is wrong for these annotators. Their
unit is the **clause-level orthographic sentence**, and they cut at nearly every coordinated independent
predication. Calibration numbers to carry forward:

| doc | words | key cuts | words per sentence |
|---|---|---|---|
| news report | 353 | 22 | **16** |
| student essay | 276 | 17 | **16** |
| trivia column | 252 | 20 | **13** |

**Target density ≈ 13–16 words per sentence.** I produced 25 / 17 / 18. If my average sentence is over
~18 words, I have missed cuts. When genuinely 50/50 at a clause-initial connective, **CUT.**

### expository — CONNECTIVES THAT ALWAYS OPEN A NEW SENTENCE

**RULE 1 (biggest single error, 4 hits). The annotators cut before لكن / ولكن, always — even when the
contrast is tiny and even when لكن carries a clitic pronoun.** I had written the opposite rule ("لكن is
comma-level coordination inside the statement it qualifies"); it is simply wrong.
> [AMENDED BATCH 2] "always" is now scoped to **expository/news register only** (4/4 there). In narrative
> and literary prose لكن is comma-level and does NOT cut (11 of 14 sites). See batch-2 narrative N2.
- `…تحاكي تماما نظم التحكم بالطائرات ‖ لكنه حرص على ألا تكون صالحة…` (missed @156)
- `…لن ينشر كود تطبيقه للعموم ‖ لكنه سوف يشاركه مع الإدارة الفيدرالية…` (missed @205)
- `…سد الثغرات في الأنظمة القديمة كان صعبا ‖ ولكن الأنظمة الحديثة ستحتاج…` (missed @314)
- `…خطورة هذه الوسائل علينا وعلى أطفالنا ومجتمعاتنا ‖ ولكن كيف يكون تأثيرها…` (missed @73)

**RULE 2. The annotators cut before إذ.** I filed إذ as a circumstantial subordinator that stays inside.
It does not.
> [AMENDED BATCH 3] Scoped to **expository register only**. Under the `narrative` label إذ NEVER cuts —
> 3/3 false cuts in batch 3, my most-repeated single error there. Changed because the evidence is
> unanimous the other way: the boundary I could feel was always at the neighbouring و/فـ. See N11.
- `…شكل مفاجأة سارة بالنسبة له ‖ إذ أثارت اهتمام المسؤولين ولم يحاولوا نفي…` (missed @294)

**RULE 3. فـ + a new finite clause is a CUT, not a "tight consecutive link".** I invented a rule that فـ
binds the clause to what precedes; the key cut at every فـ site I had suppressed.
> [AMENDED BATCH 2] Scoped to **expository register only**. In narrative/literary prose فـ defaults to
> NO CUT (12 of 18 sites) — it is the same-breath reason/consequence. See batch-2 narrative N3.
- `…وقبلها كان طيارا مدنيا مدة 12 سنة ‖ فدمج مجالي اهتماماته…` (missed @251)
- `…لا يعمل إلا أثناء تشغيل نظام الملاحة الآلي ‖ فإذا اكتشف الطيارون…` (missed @335)
- `…تختلف درجة حرارة القمر من مكان إلى آخر ‖ فقد تصل الحرارة إلى مائة درجة…` (missed @107)
- `…فحينها يكتمل معنى الاستخدام الإيجابي ‖ فبذلك تندرج عليه آثار إيجابية ‖ فعلى الفرد النمو الفكري…`
  (I cut the first, missed the second @134 — BOTH are cuts.)

**RULE 3a — the one فـ that does NOT cut: the apodosis of an explicit conditional.** Confirmed, not an
error: `إذا كان استخدامه إيجابيا … فحينها يكتمل معنى الاستخدام الإيجابي` stayed whole and the key agreed.
So: cut at فـ unless the clause before it is a protasis headed by إذا / لو / إن, or unless فـ explains an
immediately preceding NP fragment (`إضاعة الوقت بما هو ليس مفيدا فالوقت كالسيف…` — key did NOT cut).

**RULE 4. و + a finite verb opening a new predication is a CUT by default — even with the same subject
and even when a pronoun carries the topic over.** I required "a new topic re-stated as a full NP"; that
bar is far too high.
- `…تقع جزيرة تاهيتي في غرب المحيط الهادي ‖ مساحتها 1041 كيلو مترا مربعا ‖ وتبرز فيها أربع قمم…` (missed @15)
- `…قطر القمر يبلغ نحو ربع قطر الأرض ‖ وهو يبعد عن الأرض مسافة…` (missed @62 — bare pronoun subject!)
- `…نبات الترمس يزرع في مصر منذ أيام الفراعنة ‖ ويعتبر من المحاصيل…` (missed @202 — same subject!)
- `…منذ 11 سنة ‖ وقبلها كان طيارا مدنيا مدة 12 سنة ‖` (missed @244)
- `…إرسال البيانات فيها يجري بلا أدنى تشفير ‖ ولا ضرورة لإخفائها لأن اكتشافها شبه مستحيل` (missed @182 —
  a VERBLESS و-clause still cuts when it is a full predication with its own subordinate tail).

**RULE 4a — where و does NOT cut (all confirmed correct this batch).** و introducing a NON-FINITE conjunct:
a maṣdar (`وإعطائها أوامر`, `وإشعال وإطفاء الأنوار`, `والتعرف على موقعها`, `وتغيير مسارها`), a plain NP
conjunct (`والوكالة الأوروبية لسلامة الطيران`), or a deictic adverbial tag (`وذلك أثناء تشغيل الطائرة`).
The finite/non-finite test is the usable discriminator: **finite verb after و → cut; phrase after و → no cut.**
> [AMENDED BATCH 3] The finite/non-finite test is NOT sufficient, and this is where it breaks: inside an
> ENUMERATION, a non-finite conjunct that carries its own complement/PP/relative tail IS its own unit —
> maṣdars and even bare accusative NPs. 6 missed cuts. Changed because length+own-tail beat finiteness at
> every one of those sites. See N19. The test still holds outside enumerations.
Residual noise I could not predict and should not chase: the key did NOT cut at `…اسمها نجم سنتورى ويبعد عنا مسافة…`
nor at `…إذ أثارت اهتمام المسؤولين ولم يحاولوا نفي…`. و+finite is ~70%, not 100% — but 70% means CUT.

**RULE 5. A bare apposed nominal clause describing the thing just named is its OWN sentence.**
- `تقع جزيرة تاهيتي في غرب المحيط الهادي ‖ مساحتها 1041 كيلو مترا مربعا ‖` (missed @10). I read
  `مساحتها…` as a comma-set parenthetical. The annotators give it a full stop on both sides.

**RULE 6. In an enumeration whose members are full verbless predications, EACH MEMBER is a sentence.**
- `فعلى الفرد النمو الفكري وتطوير النفس وإدارة الوقت بشكل أفضل ‖ وعلى المجتمع التقدم في الفكر والعمل…`
  (missed @144). I explicitly wrote "enumerations stay in one sentence with their head noun" — wrong when
  the members are `على X + predicate` clauses. (The head `فبذلك تندرج عليه آثار إيجابية` is also its own
  sentence, RULE 3.) Note the contrast that still holds: a chain of coordinated maṣdars inside ONE member
  (`النمو الفكري وتطوير النفس وإدارة الوقت`) does not cut — that is RULE 4a.

**RULE 7 (false cut). Cut BEFORE the contrastive connective, not AFTER the rhetorical question it opens.**
A question and the clause that answers it can sit in one sentence.
- I cut `…إيجابيا أو سلبيا ‖ وذلك بحسب الشخص`. The key instead cuts at `ومجتمعاتنا ‖ ولكن كيف يكون تأثيرها
  إيجابيا أو سلبيا وذلك بحسب الشخص وكيفية استخدامه لها ‖`. Same total, boundary one clause earlier.
  Lesson: place the cut at the clause-initial connective. Do not invent a cut at a stripped "?".
  (`ولكن ما هو أحدها يا ترى ‖` DID cut — because the next unit `وسائل التواصل الاجتماعي هي…` starts
  asyndetically. So the question mark itself is not the trigger; the next clause's onset is.)

**RULE 8 (false cut). Do not cut after a sentence-medial adverb; cut only at a clause-initial connective
or a new predication.**
- I cut `…على الفرد وعلى المجتمع كذلك ‖ إضاعة الوقت…`. The key runs straight through: `فهنا يكون لها تأثير
  سلبي على الفرد وعلى المجتمع كذلك إضاعة الوقت بما هو ليس مفيدا فالوقت كالسيف إن لم تقطعه قطعك الهلاك
  والضياع والضياع الفكري ‖`. A weak trailing adverb is not a boundary licence.

### expository — WHAT I GOT RIGHT (keep these; they earned 100% precision)

- **Title / headline is always its own unit.** `طيار ألماني سابق يبتكر تطبيق أندرويد … بواسطة هاتف ذكي ‖`
  (news headline), `سلاح ذو حدين ‖` (essay title), `من كل بستان زهرة ‖` (column standing head). Test that
  worked: the head has no predicate, or the next word starts a finite clause that cannot attach to it.
- **Asyndeton + topic jump is the strongest boundary in the language.** Every one of the nine item
  junctions in the trivia column (`…على الوجه المظلم للقمر ‖ أعلى بحيرة في العالم هي بحيرة تيتيكاكا`) and
  every paragraph restart in the news report (`عرض هوغو تيسو…`, `يعتمد التطبيق…`, `لقي عرض هوغو…`,
  `يعمل هوغو تيسو…`) was correct. Zero errors here.
- **و + a verb of saying re-launches an attributed statement = cut.** All six correct: وقال، وأعلن، وأشار،
  وأضاف، واستطرد. This is a reliable news-register rule.
- **A long relative/complement chain stays inside one sentence.** The 43-word news lead
  (`استعرض … تطبيقا بسيطا للهواتف الذكية التي تعمل … يسمح باختراق … التي تتحكم بالطائرة …`) has NO internal
  cut in the key. Relative clauses with التي/الذي, purpose لـ/كي, cause لأن, and complement أن do NOT cut.
  So length alone is never the reason to cut — subordination genuinely holds a sentence together.
- **أما … فـ … is always a new sentence.** `أما بالنسبة للمجتمع فتدهوره وتدمره…` correct.
  [AMENDED BATCH 3] "always" is now expository-only. In narrative a SHORT أما-contrast whose predicate is
  an anaphoric echo of the clause before it rides backward inside that clause. Changed by one clean false
  cut: key `…رسالة ومعنى واضحين أما أسجارد والآلهة فلم تكن كذلك ‖ فهذا الكتاب…`. See N13.
- **فعلى سبيل المثال opens a sentence.** Correct.
- **Stripped symbols leave stray tokens at real boundaries.** `…إلا حوالي 7 ‖` (a `٪` was removed) and
  `عام 1224 م ‖`. A dangling numeral is a stripping artefact, not a reason to doubt the cut.

### Method note for next batch
Work the same way — identify the text type first, because it sets the connective inventory (news:
verba dicendi; essay: فـ-chains; trivia column: asyndetic item junctions). Then walk every clause-initial
و / فـ / لكن / ولكن / إذ / أما / ثم and ask only one question: **is what follows a finite predication?**
If yes, cut. Reserve "no cut" for non-finite conjuncts, subordinate clauses (التي، الذي، أن، لأن، كي، لـ),
conditional apodoses, and trailing adverbials.

---

## BATCH 2 (docs: doc_361233315d24 `legal`, doc_54f919517225 `narrative`, doc_eb278f2980be `narrative`/literary)
Scores: doc_361233315d24 F1 97.4 (P 96.3 / R 98.6), 55 errors (40 false / 15 missed);
doc_54f919517225 F1 84.2 (P 84.8 / R 83.7), 46 errors (22 false / 24 missed);
doc_eb278f2980be F1 85.3 (P 82.4 / R 88.4), 29 errors (18 false / 11 missed). **130 errors total.**

### THE OVERRIDING LESSON OF BATCH 2 — TWO THINGS, AND NEITHER IS "CUT MORE"

**(a) I am no longer under-cutting. I am MIS-PLACING.** Batch 1 was a recall problem (17 missed vs 2
false). Batch 2 is balanced (80 false / 50 missed) and — measured — **17 of my error sites were a FALSE
CUT sitting within a clause of a MISSED cut. That is 34 of 130 error-points, 26% of everything, spent on
knowing a boundary was near and putting it one junction off.** Each such site costs double. Cutting more
or less is not the lever any more; choosing the junction is.
The law that fixes it, and it is general: **the boundary goes BEFORE the element that opens the new unit
— the connective, the fronted adverbial, the first verb of an action chain — never after it.** Batch-1
RULE 7 said this for expository; batch 2 proves it is the law everywhere.

**(b) Connective behaviour is REGISTER-DEPENDENT and flips sign.** لكن and فـ, which I had as hard
expository laws, invert in narrative. Before applying any connective rule, name the register and load
that register's table. A rule without a register label is a trap.

---

### legal — doc_361233315d24 (Yemeni draft constitution), F1 97.4, my best document so far

**L1 (my single largest error class ever — 23 false cuts). The annotators keep a division label and its
topic title in ONE unit. Never cut between `الباب/الفصل + ordinal` and the title that follows it.**
Constitutions print these on one line (`الباب الأول: الأسس العامة`); the unit is that line.
- I cut `…الباب الأول ‖ الأسس العامة ‖ الفصل الأول ‖ الأسس السياسية…`
  the key: `…الباب الأول الأسس العامة ‖ الفصل الأول الأسس السياسية…`
- Same at الفصل الثاني الأسس الاقتصادية، الفصل الثالث الأسس الثقافية والاجتماعية، الباب الثاني الحقوق
  والحريات، الباب الثالث السلطات الاتحادية، الفصل الخامس الهيئات المستقلة والمجالس المتخصصة، الباب السابع
  المالية العامة، الباب العاشر الأحكام الانتقالية — 23 sites, all the same shape, all wrong the same way.
- **But an article-number label is NOT absorbed by its article: `مادة 282` is its own unit.** I missed
  that cut: key `…أحكام عامة ‖ مادة 282 ‖ تجسد الهيئات المستقلة… ‖`. Ordinal + NP title = one line;
  numbered article label = its own line.
- Residual noise not to chase: `أولا مجلس النواب` / `اولا مدينة صنعاء` are joined, but `‖ ثانيا ‖ مدينة عدن ‖`
  is split. Layout artefact, unpredictable.

**L2 (dominant recall failure, 8 missed). A stripped COLON introducing an enumeration is a full
boundary.**
> [AMENDED BATCH 4] Only when the lead-in is a dangling PREPOSITION or a full predication awaiting its
> list. A dangling identifying copular هي / وهي belongs WITH its items (2 false cuts). More generally the
> lead-in shares the items' fate: items ride together → the lead-in rides with them. See N32/N33. The signature is unmistakable once you look for it: the clause breaks off on a dangling
function word or lead-in — `من / في / ومنهم / ومنها / بما يضمن / على أساس / يحظر عليها / تكفل الدولة /
ينشأ بقانون` — and what follows is a run of listed items that the key also separates.
- missed: `يقوم النظام السياسي على أساس ‖ الفصل بين السلطات وعلى التعددية…`
- missed: `ويتضمن الحق في ‖ اللجوء إلى القضاء وإجراءات محاكمة عادلة…` (a dangling preposition is the
  loudest signal in the whole document — a sentence cannot end on في)
- missed: `يتكون مجلس صندوق الإيرادات الوطني من ‖ وزير المالية الاتحادي رئيسا للمجلس ‖ وزراء المالية…`
- missed: `كما يحظر عليها ‖ المساس بالنظام الجمهوري الديمقراطي ‖ الحصول على تمويل خارجي ‖`
- missed: `وتكفل له الدولة ‖ الحق في الاسم والنسب وشهادة الميلاد والجنسية ‖`
- **EXCEPTION: a lead-in to a QUOTATION does not cut.** false cut: `صيغة اليمين الدستورية كالتالي ‖ quot
  أقسم بالله العظيم…` — the key runs straight through. Colon-before-list cuts; colon-before-quote does not.

**L3. Inside one provision the annotators do NOT cut at every finite clause. و + finite, and even an
asyndetic new finite predication, stay in the article.** This is the reverse of expository RULE 4 — in
legal text the unit is the provision/line, not the clause.
> [CONFIRMED BATCH 4] Not a legal-register fact — a LIST/LAYOUT fact. The same law governed the list items
> of a magazine page labelled `narrative` (9 false cuts when I ignored it). Promoted to N32.
- false: `ألا يكون عضوا في مجلس النواب أو الاتحاد ‖ ولا يجوز الجمع بين منصب الوزير…` — key joins.
- false: `الشباب قوة فاعلة في بناء الوطن ‖ تكفل الدولة رعايتهم…` — key joins (nominal + verbal, asyndetic).
- false: `وأمانة عامة تعمل تحت إشرافها ‖ يتم اختيار موظفيها…` — key joins.
- false: `ويكون لكل منها نفس الحجية ‖ يكون يوم نفاذ الدستور يوما وطنيا` — key joins.
- false: `وفق برنامج زمني محدد ‖ والله الموفق` — the closing formula rides on the last provision.
- This **kills the qualification I had derived** ("a و-clause that follows a list and restates a rule over
  the whole list is the article's closing paragraph and does cut"). It does not cut. Removed.

**L4. كما + finite verb DOES open a new unit.** I had listed كما among the connectives whose presence
proves a clause is tied to the previous one. Wrong.
- missed: `والنظر في الطلبات والتظلمات المقدمة منهم ‖ كما ينظم القانون اختصاص مجلس القضاء في الاقاليم…`

**L5. A fronted adverbial phrase belongs to the FOLLOWING unit — cut before it, not after it.**
(Two displacement sites, four error-points.)
- key: `…وفقا لنظام القائمة النسبية المغلقة ‖ بعد الدورة التشريعية الأولى يمثل الجنوب…` — I cut after `الأولى`.
- key: `…وينظم القانون تشكيله واختصاصاته ‖ دون المساس باستقلال القضاء على كل أجهزة الدولة الرد…`

**L6 (6 false cuts). In a competence-list appendix, a run of very short bare-NP items (2–4 words) is
kept together — do not cut at every item.**
- I cut `العملة ‖ سك النقود ‖ السياسة النقدية ‖`; key: `العملة سك النقود السياسة النقدية ‖ القروض الخارجية ‖`.
- I cut `سياسة التعليم الوطنية ‖ معايير الجودة ‖ تنظيم المناهج ‖`; key runs all three together.
- Items that DO earn their own unit are longer and carry their own PP/relative tail
  (`المناطق الرطبة والطيور المهاجرة للحفاظ على التنوع الحيوي ‖`).

**L7. A marginal article title that restates the article's opening words: cut between the title and the
body, not inside the body.**
- key: `الحق في تكوين النقابات والاتحادات ‖ للعمال والموظفين وذوي المهن الحق في تكوين النقابات والاتحادات
  بمجرد الإخطار…` — I cut after `المهن`, splitting the body instead of detaching the title.

**legal — the law that worked (P 96.3 / R 98.6, F1 97.4).** The asyndetic junction between provision-units
is the boundary; never cut at و inside an article; heading and article alternate as separate units. That
core reading was right — every one of the 55 errors was a detail on top of it, not a failure of it.

---

### narrative — doc_54f919517225 (Tolstoy, folk narrative) and doc_eb278f2980be (literary essay)

**N1 — THE CHAIN-HEAD LAW. The biggest structural fix of this batch (≈12 errors, most of them doubled).**
> [CONFIRMED + TIGHTENED BATCH 4] The head half is confirmed a third time (3 more doubled sites, N24). The
> run half was too wide: a "run" ends at any change of location, state, subject or perception, so a journey
> is NOT one run (`فخرج ‖ ونزل ‖ وسار` = three units). 8 missed cuts. See N23.
A run of و/فـ-coordinated finite verbs that are sub-steps of one action stays whole inside one sentence —
that brake I invented was RIGHT — but the run **STARTS** a new sentence. The annotators cut at the chain's
FIRST member and never inside it. I was doing the exact inverse: gluing the chain's head verb onto the
previous sentence, then cutting somewhere in the middle of the chain. Each site cost one false cut plus
one miss.
- key: `فوضع باعوم كيس نقوده فوق القبعة ‖ وعلق قربة الماء في زناره ووضع كيس الخبز…`
  (I joined `وعلق` to the previous sentence and cut later inside the chain)
- key: `فسار بخطى معتدلة حوالي ألف خطوة ‖ ثم توقف وحفر حفرة وجمع فوقها كومة من الأعشاب ‖`
- key: `فتوقف وحفر حفرة وشرب ماء من قربته ‖ ثم انحرف يسارا ‖ وتابع سيره بهمة وقد أحاطت به الأعشاب ‖`
- key: `هز رجال البشكير رؤوسهم شفقة وأسى ‖ ثم تركوه على الأرض وانصرفوا ‖`
- key: `انطلقت صرخة ألم من فم باعوم وخانته قدماه ‖ فوقع على الأرض ومد يديه فأمسك بهما القبعة ‖`
- **Corollary: `ثم انحرف يسارا ‖` is a legitimate three-word sentence.** Shortness is never a reason to
  glue a unit onto its neighbour.

**N2 — In narrative and literary prose the annotators do NOT cut before لكن / ولكن. It is comma-level.**
11 of 14 sites; 8 false cuts on the literary doc alone. This SCOPES batch-1 RULE 1 rather than deleting it
(expository was 4/4 the other way) — see the amendment note added there.
> [AMENDED BATCH 4] There is no default. Batch 4 went 4 cut / 2 joined, and merged with N21 this is a
> coin-flip decided by what FOLLOWS: bare short reversal → join, new content → cut. Changed because I
> applied N2's no-cut default to four ولكن sites and lost four recall points. See N25.
- false: `رقد باعوم على فراشه ‖ لكنه لم يغمض له جفن` — key joins.
- false: `فهي ليست كالمتدينة التي خامرها الشك في دينها ‖ ولكنها كالمرأة التي لم تتدين قط` — key joins.
- false: `وقد يهيجون نفسها ‖ ولكنهم لا يقربونها إليهم ولا إلى نفسها` — key joins.
- false: `كما تحبه كل بنت من بنات حواء ‖ ولكنها تكره التدليل السخي الفياض` — key joins.
- false: `فهم نماذج عدة تبلغ المئات ‖ ولكنهم مشمولون جميعا في رجولة واحدة` — key joins.
- **Discriminator for the minority that DOES cut:** ولكن that opens a new question or a new speech turn
  (`لا أسألك في ذلك ‖ ولكن كم عبرة يا أبي`), or that follows an already-complete short narrative statement
  (`وسار نحو تلة البداية ‖ لكنه كان يسير بصعوبة`). A balanced contrast pair — `ليس X ولكن Y`, negation on
  one side, same clitic subject on both — is inside one sentence.

**N3 — In narrative, فـ defaults to NO CUT (12 of 18 sites).** فـ giving the reason, explanation, or
immediate consequence in the same breath is comma-level. Reverses expository RULE 3 for this register.
- false: `كانت الشمس قد اشتدت حرارتها ‖ فخلع باعوم سترته` — joins.
- false: `أخيرا تسلل ضوء الفجر إلى الخيمة ‖ فهب باعوم قائما` — joins.
- false: `تابع باعوم طريقه وقد ارتاح قليلا ‖ فقد أمده الطعام ببعض القوة ‖ لكنه كان يعاني…` — ALL one sentence.
- false: `وفي نفس اللحظة أظلمت الدنيا ‖ فصاح بجزع ضاعت جهودي كلها` — joins **even though فصاح is a speech
  frame**. This kills my clause "فقال/فصاح/فهتف always cuts". A فـ-speech-frame rides on its trigger.
- false (literary): `تعلمت وهامت بأوروبا ‖ فأوروبا عندها نبي معصوم`; `وهو في ملابسه الصباحية ‖ فكادت حين
  رأته إلى جانبها تجن من الغيظ` — both join.
- فـ still cuts when it opens the next time-step after a completed statement: `فجمعا نصف ثمن الأرض ‖`,
  `فرآها بعيدة جدا ‖`, `فجلس وأكل خبزا وشرب ماء ‖`, `فعندنا منها الكثير ‖`, `فتعلم لأول وهلة… ‖`.

**N4 — فإذا / وإذا correlative "and lo" clauses are ONE sentence, and a stated conditional pair
(فإذا … وإن …) is ONE sentence.** Refutes my rule "فـ + a conditional protasis (فإذا/فلو) cuts".
- false ×3: I split `فإذا به يعرفها مكشوفة ‖ … وإذا بها تحس ‖ … وإذا هي قريبة منه`; the key runs the whole
  triad together as a single period.
- false: `فإذا دفعتها فهي ناهيك من حركة وصعود وهبوط ‖ وإن وقفت لحظة فهي حجر ملقى على التراب` — one sentence.

**N5 — حتى introducing a RESULT is a CUT; حتى meaning "until" is not.** I had حتى as never-cut.
> [AMENDED BATCH 4] The cut signature is حتى أنّ specifically, not bare حتى + verb. Changed by one false
> cut on bare resultative حتى (`حتى أطلق عليها المدينة الخضراء` — joins) against 2/2 for حتى أنّ. See N27.
- missed: `فالشعير يرتفع في الأرض بارتفاع ظهر الحصان ‖ حتى أن فلاحا ذهب إلى هناك لا يملك إلا يديه ‖`
- missed: `فاندفع بكل قوته مادا جسمه إلى الأمام ‖ حتى أصبح من العسير على قدميه اللحاق به ‖`
- confirmed no-cut: `وانطلق يجري صاعدا حتى وصل إلى أعلى التل ‖`

**N6 — ثم + finite verb opening a distinct next action IS a cut (I missed 5).** Not a cut when ثم is a
member inside an ongoing chain (see N1).
- missed: `استمع الزعيم إلى باعوم ‖ ثم أشار بيده وقال اختر ما شئت من الأراضي ‖`
- missed: `والنوافذ مطلة عليه من جوانب شتى ‖ ثم لا تبالي أن تمازح صاحبها`
- no-cut: `ثم اقترضا الباقي من شقيق الزوجة`، `ثم تفرقوا إلى خيامهم`، `ثم ألقى حذاءه`

**N7 — و + finite verb still cuts in narrative. Expository RULE 4 CONFIRMED, not weakened** (this is the
one connective that held its sign across all three registers so far).
- missed: `فاقترض بذورا وزرعها ‖ وكان المحصول وفيرا ‖`
- missed: `لا يملك إلا يديه ‖ وهو الآن يملك ستة خيول وبقرتين ‖` (bare pronoun subject — same as batch 1)
- missed: `فاشترى أراضي زراعية ومراعي وماشية ‖ وأصبح يملك كل ما كان يتمناه ‖`
- missed: `وفقد السيطرة على قدميه ‖ وأصبحت دقات قلبه كأنها طرقات مطرقة الحداد ‖`
- missed (literary): `فذعر الكاهن ولم يصدق ما يسمع ‖ واستعادها مرة بعد مرة`
- missed (literary): `فإذا أحجم وتردد ضحكت منه ساخرة ‖ وأولعت بتعييره والتهكم عليه`
- Residual ~70%, as in batch 1: `اقتربت الشمس من الأفق وأصبحت كبيرة وحمراء بلون الدم ورأى باعوم رجال
  البشكير…` did NOT cut. 70% still means CUT.

**N8 — each quoted sentence, and each repetition, is its own unit. CONFIRMED and extended.**
- missed: `سأموت بلا ريب ‖ سأموت بلا ريب ‖` — a doubled exclamation is TWO sentences, not one.
- missed: `ويلهث قائلا آه يا إلهي ‖ ماذا أفعل إذا تأخرت وفقدت كل شيء ‖`
- missed: a one-word stripped exclamation stands alone: `…ورهبة الصوت ‖ ماذا ‖ فيما دون العاشرة…`

**N9 — subordinators I had filed as never-cut that DID cut once each. Record as caution, not as law**
(single sites; do not invert my defaults on this evidence, but stop treating them as impossible):
- لأن: `أنها أصلح ما تكون مديرة للإضاءة في مسرح تمثيل ‖ لأنها تعلم مواقع الرؤية علما لا خطأ فيه ‖`
- أو + finite verb: `ولا يسهل التقريب بينهما بعد ذلك ‖ أو ينظر إليها نظرة القانص الفاتك`
- ولو: `وكانت مرتاحة حقا لما سمعت ‖ ولو أنه أسمعها غير ذلك حسرات التفجع`
- a SECOND coordinated أنّ-complement: `أنها لا تفقه ما تقول ‖ وأنها بمحاكاة المعترفات…`
- asyndetic descriptive tail after a complete clause: `وكان صاحبها همام على نقيضها ‖ يهزأ بالعرف…`
- وقد ḥāl: stays inside 3 of 4 sites (`وتابع سيره بهمة وقد أحاطت به الأعشاب` — no cut, confirmed) but cut
  once when it opened a long new descriptive period: `ويلهث من شدة الخوف والإرهاق ‖ وقد بلل العرق قميصه…`

**N10 — narrative density and what it is NOT good for.** doc_54f919517225: 1453 words / 147 key cuts ≈ 10
words per sentence (denser than expository's 13–16 — dialogue does that). I produced 145 vs 147, and
102 vs 95 on the literary doc. **My counts were already right; my placement was wrong.** Density is now a
sanity check only. It cannot buy me another point — N1 and N2 can.
> [AMENDED BATCH 4] "Cannot buy me another point" is WRONG. In batch 4 the density gap predicted both
> failures before grading (9.5 vs key 9.4 → F1 91.5; 9.1 vs 10.7 → P 80.3; 12.2 vs 10.0 → R 73.3).
> Density is now an active pre-submission check, band 9.5–11 w/unit for narrative. See N39.

### Method note for batch 3
1. Name the register FIRST and load its connective table, because لكن and فـ flip sign between expository
   and narrative. Do not carry a rule across registers without a label.
2. In legal text: hunt for the two invisible marks — the label/title line (never split it) and the
   stripped colon before a list (always cut at it, unless a quotation follows).
3. In narrative: find the chain HEAD. Cut before the first verb of an action run; then run to the end of
   the run without cutting.
4. Whenever two adjacent junctions both look plausible, take the EARLIER one — the one at the element
   that opens the new unit, not the one after it. 26% of this batch's error-points were spent there.
   > [AMENDED BATCH 3] "Take the EARLIER one" is WRONG as stated — it was over-fit to legal + Tolstoy.
   > In batch 3, 6 of 7 displacement pairs went the other way: the key's boundary was LATER than mine.
   > The clause that survives is the second half: cut at the element that OPENS the new unit. Positional
   > tie-breaking is out; directional tie-breaking is in. See the batch-3 overriding lesson.

---

## BATCH 3 (docs: doc_405d5fba81e0, doc_5b0751f40176, doc_7bc0656a48ce — all labelled `narrative`)
Scores: doc_405d5fba81e0 F1 88.3 (P 94.4 / R 82.9), 18 errors (4 false / 14 missed);
doc_5b0751f40176 F1 87.4 (P 85.4 / R 89.4), 22 errors (13 false / 9 missed);
doc_7bc0656a48ce F1 88.7 (P 89.6 / R 87.8), 11 errors (5 false / 6 missed). **51 errors total.**
Running record after this batch: 76 docs graded, mean F1 89.30 (P 93.24 / R 87.89).

### THE OVERRIDING LESSON OF BATCH 3 — STILL DISPLACEMENT, BUT IT RUNS THE OTHER DIRECTION
My cut counts were nearly right (72 vs key 82; 89 vs 85; 48 vs 49) and the errors split 25 false / 26
missed. Fourteen of the 51 errors sit in seven ADJACENT false/missed pairs — I knew a boundary was there
and put it one junction off, exactly as in batch 2. But **in 6 of those 7 pairs the key's boundary was
LATER than mine, not earlier.** So the batch-2 tie-breaker ("take the earlier one") is dead; the law that
replaces it is directional, and it is the one thing to carry into every register:

> **Ask which way the connective FACES.** A backward-facing connective keeps its clause in the LEFT unit,
> so the boundary falls AFTER it. A forward-facing one opens the right-hand unit, so the boundary falls
> BEFORE it.
> Backward-facing (confirmed this batch): إذ، وهذا/وذلك summary، من بينها partitive، أما+echo، a و/ثم that
> is the next sub-step of one actor's action-run، a bare صفة verb on an indefinite NP.
> Forward-facing (confirmed this batch): فهو/فهي/فهذا، فنظرا/فقد، حيث + finite، a fronted PP، asyndeton،
> و + a new explicit subject، و + a second أنّ-complement.

### narrative

**N11 — إذ NEVER cuts under the `narrative` label. 3/3 false cuts, my most-repeated error of the batch.**
Scopes batch-1 RULE 2 (expository, where إذ does cut). When a boundary feels near an إذ, it is at the
neighbouring و/فـ, not at إذ.
- false: `كان والدها غائبا عن المنزل ‖ إذ كان طيارا يشارك في الحرب في أفريقيا` — key joins.
- false: `دائما ما تكون هزيلة وقبيحة المنظر ‖ إذ ليس لها أصحاب` — key joins.
- false+missed pair: I cut `فقد أثارت المزيد من الدهشة ‖ إذ اختارت اتجاها آخر`; key joins إذ and cuts one
  clause later — `…إذ اختارت اتجاها آخر ‖ واتجهت إلى مشتى جديد في جنوب فرنسا وأسبانيا ‖`.

**N12 — فـ + a NOMINAL subject (pronoun or demonstrative) launching an independent predication is a CUT.
4/4.** N3's "narrative فـ defaults to no cut" covers only فـ + finite verb in the same breath (فتنام، فخلع).
فهو / فهي / فهذا re-launches the topic and always cut.
- missed: `في عالم لا يوجد إلا في الكتب ‖ إنها تتذكره ‖ فهو ذو شعر ذهبي مائل إلى الحمرة`
- missed: `حتى لو لم يتحدث أحد عنه مع الطفلة النحيلة ‖ فهي تعلم بداخلها أن والدها البارع لن يعود` — it cuts
  even as the apodosis of حتى لو, so batch-1 RULE 3a (conditional apodosis never cuts) is expository-only.
- missed: `كان لاكي بالفعل كلبا قويا وجميلا ‖ فهو على عكس كل الكلاب الضالة`
- missed: `أما أسجارد والآلهة فلم تكن كذلك ‖ فهذا الكتاب هو قصة لغز عن نشأة العالم`
- Same family — فـ + a fronted adverbial, and فـ + قد + perfect, also cut:
  missed `وكان مصير والدتها أيضا ينطوي على مفارقات ‖ فنظرا إلى الحرب الدائرة أصبح من الجائز لها`;
  missed `ذات أصول اسكندنافية ‖ فقد هاجرت أسرتها من أرض غزاها الفايكنج`.
- فـ + a verb of saying: 50/50 and the LEFT side decides. Batch-2 N3 had `فصاح بجزع` riding on its trigger;
  here, after a completed statement, it cut — missed `وأحس من جديد بعطش أشد ‖ فقال في نفسه سأشرب…`.

**N13 — أما … فـ … is NOT automatically a new unit in narrative.** A short أما-contrast whose predicate is
an anaphoric echo of the clause before it (`فلم تكن كذلك`) is comma-level and rides backward.
- false+missed pair: I cut before أما and joined فهذا. Key: `…وقد حملت قصة بنيان رسالة ومعنى واضحين أما
  أسجارد والآلهة فلم تكن كذلك ‖ فهذا الكتاب هو قصة لغز…` — one junction later, both errors from one cause.

**N14 — ASYNDETIC juxtaposition of finite verbs or repeated words is ONE UNIT EACH, while the و-linked
clauses around them are not.** 6 missed. Loudest in dramatic children's narrative (stripped ellipses).
- key: `كان ذيله يكبر ‖ يزداد طولا ‖ يتضخم ‖ وكانت عيناه تتسعان وكان هو نفسه يكبر ‖ يكبر ويتضخم حتى صار
  وحشا هائلا` — I ran the first four together and then cut at `وكان هو نفسه`. Exactly inverted.
- key: `وكان ذيله ينكمش ويصغر وكان جسمه كله يصغر ‖ يصغر حتى عاد إلى حجمه الطبيعي ‖`
- key: `ثم وصوله إلى نهاية ‖ نهاية حقيقية نهاية العالم ‖` (bare repeated NOUN, same law)
- Slogan for the mixed run: **و joins, asyndeton cuts.** Extends batch-1's asyndeton law and N8.

**N15 — the و/ثم discriminator, finally in a form that fits all sites.** JOIN when the و/ثم-verb is the next
physical sub-step of ONE continuous action by the SAME actor (N1's chain law). CUT when it states a NEW
fact, a new state or a separate event — even about the same subject — and always when the subject changes.
This SCOPES N6: ثم cuts only when it opens a new event, never inside an actor's action-run.
- join (my false cuts): `هكذا قال الكلب لاكي ثم انطلق يعدو في اتجاه الغابة`; `وصل لاكي إلى مشارف الغابة ووقف
  هناك يزوم ويزمجر`; `مزقه تماما وابتلعه في لحظات قليلة ثم دس لسانه`; `وحبس العلماء الطيور عدة سنين في
  هولندا ثم أطلقوها`; `أصيب بغرور شديد وأخذ ينبح ويصرخ ويقول`; `وتابعت أسفاره عبر البرية و وادي الظل`;
  and inside one speech turn `فلماذا لا تأتي لتعمل في بيتي الجديد خادما وسوف أجعل زوجي يقدم لك`.
- cut (my misses): `لتنتشر المجاعات ‖ وتهرب الحيوانات المائية` (new subject);
  `ومع ذلك كان الكتاب باللغة الألمانية ‖ وقد اقتبس من أعمال الدكتور دبليو فاجنر` (new FACT, same subject —
  so وقد + perfect is a new predication, not a ḥāl, unless it gives the simultaneous circumstance of an
  actor already in motion, N9);
  `إذ اختارت اتجاها آخر ‖ واتجهت إلى مشتى جديد` (next step, not sub-step);
  `تدرك … أنه كلب ‖ وأنها كانت تسخر منه` — a SECOND coordinated أنّ-complement CUTS. This promotes N9's
  caution to a rule: 2/2 across batches.
  > [AMENDED BATCH 4] Scoped to أنَّ + a full independent proposition. Subjunctive أنْ-complements
  > coordinated under ONE order JOIN (`أن يعد فرقة … وأن يرسل … ويأمرهم`) — 2 false cuts. See N26.

**N16 — a run of و-linked NEGATIVE clauses is ONE unit.** Do not cut inside "not X, not Y, not Z".
- 2 false cuts in one place. key: `كان الماء في هذه المرة راكدا لا يتماوج ولم يكن هناك ضوء ولا خرير ولا
  أصوات ولم يكن في العين أي بريق ‖ وإنما حين نظر لاكي في الماء لم يجد…` — the boundary is at the وإنما that
  turns the description around, not at any of the negations.

**N17 — never cut inside a relative clause, however long it runs.** Two false cuts inside a single التي.
- key, one unit: `الكلاب الضالة التي دائما ما تكون هزيلة وقبيحة المنظر إذ ليس لها أصحاب وإنما تنطلق في
  الشوارع بحثا عن غذائها وقد لا تجد ما تأكله فتنام آخر الليل` — I cut it at إذ and again at وقد.
- The same law killed my cut at بينما: `وراحت تلعب كعادتها وتمرح وترقص بينما ظل لاكي وحده يخبط الأرض`.

**N18 — حيث + a new finite predication DOES open a new unit. 2/2.** I had حيث on the never-cut list.
> [AMENDED BATCH 4] Now 2/3, a tendency and not a law: حيث hanging off the place-noun just named is a
> locative relative and JOINS (`من سمات مدينة العين حيث تضم 24 حديقة غناء`). Changed by one false cut. N37.
- missed: `تشير إلى أغرب علاقة بين الاثنين ‖ حيث نرى تمساحا صغيرا يقف على ظهر فرس…`
- missed: `من بينها المنزل الذي نراه في الصورة ‖ حيث تنتشر على سطحه مئات الخلايا…`
- Contrast (and I got this one wrong the other way): a bare descriptive verb hanging on an indefinite NP —
  a صفة clause — stays inside. false cut: `مئات الخلايا أو مجمعات حرارة الشمس ‖ تحول طاقة الشمس إلى مصدر
  حراري دائم`.

**N19 — ENUMERATION: item LENGTH decides, not finiteness.** A conjunct carrying its OWN complement / PP /
relative tail is its own unit even as a maṣdar or a bare accusative NP; a short bare conjunct that shares
the head's tail is not. 6 missed. Amends batch-1 RULE 4a.
> [AMENDED BATCH 4] LENGTH is the wrong variable — an EMBEDDED CLAUSE is the right one. A flat NP/maṣdar +
> PP item rides however long it is (`القضاء على الاحتكار وسيطرة رأس المال`, 6 words, rides). Changed by 4
> false cuts in one list. All of N19's own sites still pass under the new test. Merged with L6 as N33.
- key: `صورت إحدى الرسومات الصخور في جبال ريزينجيبيرجا العملاقة ‖ ونهرا يجري عبر صدع تعلوه كتل صخرية شاهقة ‖
  وقمم غابات مستدقة الطرف رمادية اللون تغطي أحد المنحدرات ‖ وأناسا ضئيلي الحجم يشبهون النمل… ‖ وأطياف غيوم
  حاجبة تعلقت بين هذه الأشكال…` — five accusative objects of ONE verb, five units.
- key: `الإجابة على هذا السؤال استلزمت مراقبتها ‖ ثم اكتشاف قفزات بعضها من الأحواض ‖ وسيرها على أقدام غريبة
  لفترة تصل إلى أكثر من…` — three maṣdars, three units.
- This is legal L6 seen from the other side: short bare items ride together, long items with their own
  tail each get a line. One law, two registers.

**N20 — backward-facing tails that ride on the unit before them** (each cost a false cut plus the paired
missed cut one junction later):
- وهذا / وذلك + a summary of what was just said. key: `كي تضفي عليها الحياة وهذا ما فعلته الطفلة مرارا
  وتكرارا ‖ وفي كل مرة كانت تجربة جديدة` — the cut is at the fronted temporal PP, not at the summary.
- من بينها + NP partitive. key: `ظهرت النماذج المعبرة عن آفاق المستقبل من بينها المنزل الذي نراه في الصورة ‖
  حيث تنتشر…`
- A lead-in and the QUESTION it introduces are ONE unit. false: `وهنا برز السؤال الحائر ‖ كيف وصلت السمكتان
  إلى هذا المجرى المائي البعيد` — key joins. Same shape as legal L2's exception: a stripped colon before a
  LIST cuts; before a quotation or a question it does not. That exception is now cross-register.

**N21 — ولكن after an already-complete statement DOES cut; I under-applied N2's minority clause.**
- missed: `من أين أتت هي نفسها ‖ ولكنها فكرت كثيرا في ذلك السؤال القديم` — N2's no-cut default is only for
  the balanced same-clitic-subject contrast pair, not for every narrative ولكن.

**N22 — a two-member parallel boast inside ONE speech act can be a single unit. Noise; do not chase.**
- false: `وهو ينط ويقفز ويقول أنا جميل أنا قوي وعظيم ‖ ثم نبح` — key joins the pair. Yet later in the same
  story the key DOES cut `ويقول أنا أقوى الأقوياء ‖ أنا…`. Unpredictable; N8 stays the default.

### narrative — the laws that worked this batch (zero errors at these sites; keep)
- Headings, mastheads, story titles and item headlines are each their own unit — zero errors, three docs.
- Subordination holds a sentence together: أن / التي / الذي / لكي / لـ / لو / حتى ("until") / بينما. Length
  alone never licenses a cut — the only place I broke this, I was wrong (N17).
- A fronted adverbial opens the unit it precedes, never closes the one before it: وهنا، وفي كل مرة،
  ومع ذلك، وفي نهاية كل عام. Batch-2 L5 confirmed a third time.
- A bare apposed nominal naming what was just mentioned is its own unit — batch-1 RULE 5, now confirmed in
  narrative: key `وعيون زرقاء صافية وكأنه إله ‖ شجرة المران الرمادية إجدراسيل ‖`.
- Density is a sanity check only, again: key vs mine was 82/72, 85/89, 49/48. Counts are close enough;
  placement is the whole game and has been for two batches.

### Method note for batch 4
1. Read the register LABEL, not the content. doc_7bc0656a48ce is a popular-science column but is labelled
   `narrative`, and it behaved like narrative where it counted — إذ did not cut.
2. At every junction ask the direction question FIRST (backward-facing → boundary later; forward-facing →
   boundary before it). Only then apply the register's connective table.
3. In a list, measure the item: own tail → own unit, finite or not; bare and short → ride together.
4. Asyndeton is still the loudest boundary in the language, and that now includes a bare repeated verb
   (`يكبر ‖ يكبر`) and a bare repeated noun (`نهاية ‖ نهاية حقيقية`).
5. Two hard defaults to hold against my instincts: never cut inside a relative clause; never cut at إذ.

---

## BATCH 4 (orchestrator batch 3/35; docs: doc_666e6f739000, doc_78b2ed132e2f, doc_f41918b2700e — all labelled `narrative`)
Scores: doc_666e6f739000 F1 91.5 (P 92.2 / R 90.8), 11 errors (5 false / 6 missed);
doc_78b2ed132e2f F1 87.0 (P 80.3 / R 95.0), 17 errors (14 false / 3 missed);
doc_f41918b2700e F1 80.7 (P 89.8 / R 73.3), 21 errors (5 false / 16 missed). **49 errors total (24 false / 25 missed).**
Running record after this batch: 79 docs graded, mean F1 89.19 (P 93.02 / R 87.84) — **down from 89.30.**

### THE OVERRIDING LESSON OF BATCH 4 — TWO OPPOSITE FAILURES, DECIDED BY THE SHAPE OF THE STRETCH
This batch was not displacement-dominated. It was two clean, opposite failures in two different text shapes,
and I applied the wrong one's rules to the other:
- **Running narrative prose (doc_f41, doc_666): I UNDER-CUT.** 22 of my 27 errors there were missed cuts at
  و/فـ + finite verb that I had excused as "sub-steps of one action" or "clauses that merely complete the
  thought." My chain law (N1/N15) is far too wide.
- **The list/layout document (doc_78b2): I OVER-CUT.** 9 of 14 false cuts were inside list items or between
  short list members. There the LINE is the unit and nothing inside it cuts.

**The density number told me both, before grading, and I ignored it.** Key densities: 9.4 / 10.7 / 10.0
words per unit. My drafts: 9.5 (→ F1 91.5, my best), 9.1 (→ P 80.3), 12.2 (→ R 73.3). The one document
where my density matched the key's is the one I did well on. See N39.

### narrative — new rules

**N23 (the biggest recall lever, 8 missed cuts). A change of LOCATION, STATE, SUBJECT or PERCEPTION opens
a new unit — even inside one continuous journey by one actor. A "sub-step" is only a move within a single
bounded action at ONE place.** This TIGHTENS N1/N15, which I had stretched to cover whole journeys.
- key: `فخرج الضابط من الباب ‖ ونزل من أعلى الجبل ‖ وسار في طريقه إلى المدينة ‖` — I ran all three together.
  Three locations, three units. This is the site that cost the most.
- key: `وساروا حتى ابتعدوا عن بلادهم ‖ وغابت بيوتهم عن العيون ‖ وأصبحوا لا يرون أمامهم إلا الصحراء` —
  new subject, then new state.
- key: `ثم ساروا إلى الأمام أياما وأياما وأياما ‖ والصحراء لا تريد أن تنتهي والنهر الذي بعدها…`
- key: `ركب الملك والوزير الحكيم جواديهما ‖ وأخذا يتجولان في الحقول ويستمتعان بمشاهدة المزارع` — cut at the
  new event, THEN hold the two simultaneous aspects together.
- Same test for فـ: a new perception or a new actor cuts, and N3's "narrative فـ joins" survives only for the
  same actor's immediate next move. missed: `ولكنه دخل ‖ فوجد نفسه في حجرة واسعة` (new perception);
  missed: `وسكت الساحر ‖ ففتح الضابط فمه ليتكلم` (new actor).
- Genuine sub-steps, all confirmed no-cut this batch: `فوقف أمامه ورفع يده ليدق الباب`؛ `يتسلق الأحجار
  والصخور`؛ `يتجولان ويستمتعان`؛ `يقف بجانبهم ويرعى شئونهم`. Test that fits every one: same place, same
  state, same subject, one bounded act.
- Weak signal, do not promote: a chain member carrying its OWN heavy tail took a cut once —
  missed `كان دائما يقف بجانبهم ويرعى شئونهم ‖ ويفصل في قضاياهم بحكمته وسعة صدره وحسن حديثه` — while
  `وأحتاج إلى الذهاب في رحلة خلوية حتى أريح ذهني`, equally heavy, joined. One site each way.

**N24 — THE CHAIN-HEAD LAW (batch-2 N1), violated three more times, third batch running. Cut BEFORE the
first verb of the run; then never cut inside it.** Every time I glue the head onto the left unit and then
cut somewhere in the middle, I pay a false cut AND a miss.
- key: `إنني لم أنم طوال الليلة الماضية ‖ وأشعر بالإرهاق الشديد وأحتاج إلى الذهاب في رحلة خلوية حتى أريح…`
  (I joined وأشعر and cut before وأحتاج — exactly inverted.)
- key: `ثم نادى النعمان قائد جيشه ‖ وطلب منه أن يعد فرقة… وأن يرسل… ويأمرهم أن يعبروا…`
  (I joined وطلب and cut twice inside — one miss, two false cuts, my worst single site of the batch.)
- key: `ثم سار في طريق طويل ملتو ‖ حتى وصل إلى بيت الساحر فوقف أمامه ورفع يده ليدق الباب`
  (I joined حتى and cut before فوقف.)
All three pairs put the key's boundary EARLIER than mine — the opposite of batch 3's six-of-seven. So
positional tie-breaking is dead for good; only "cut at the element that OPENS the run" survives.

**N25 — ولكن in narrative is a coin-flip, not a default. Decide by the SIZE and NOVELTY of what follows.**
4 cut / 2 joined this batch. This MERGES N2 (no-cut, 11/14 in batch 2) and N21 (cuts after a complete
statement): neither is a default; the discriminator is what comes after.
- CUT — new content, own complement, or a new time-frame: `ولكنه لم يكن سعيدا ولا مرتاح البال ‖`؛
  `عندي كل شيء ‖ ولكني أريد أن أحصل على هذا الشيء الغريب`؛ `ليدق الباب ‖ ولكن قبل أن يفعل هذا فتح الباب`؛
  `ليبدأ يوما جديدا من العمل ‖ ولكنه شعر بالإرهاق والملل`.
- JOIN — a bare 2–4 word reversal of the very clause before it, inside one beat: `ولكنه دخل`؛
  `ولكنه أحس السجادة تتحرك`.

**N26 — coordinated أنْ-complements under ONE order or request JOIN.** `وطلب منه أن يعد فرقة مكونة من مائة
جندي وأن يرسل معهم أحد الضباط الشجعان ويأمرهم أن يعبروا…` — 2 false cuts. This SCOPES N15's promotion of
"a second coordinated أنّ-complement cuts" (which was 2/2 on `تدرك أنه كلب ‖ وأنها كانت تسخر منه`): the
cutting cases are أنَّ + a full independent proposition; subjunctive أنْ + verb behaves like a non-finite
conjunct and stays. Changed because two clean false cuts sit on the subjunctive side.

**N27 — the reliable resultative-حتى cut signature is حتى أنّ, not bare حتى + verb.** Sharpens N5.
- false cut: `اشتهرت بكثرة الأشجار ووفرة الزهر والثمار حتى أطلق عليها المدينة الخضراء` — key joins.
- correct, zero errors: `حتى أن الوزير كالدهار اكتسب…` cuts (now 2/2 with batch-2's `حتى أن فلاحا ذهب`).
- and bare حتى can take the boundary BEFORE it when its clause heads the next beat (N24's third example).

**N28 — و + a verbless predication in a description: ~50/50, no discriminator found. Do not spend effort
here.** Recording both sides honestly rather than inventing a rule:
- JOINED: `فاللحية بيضاء كثيفة والبشرة بيضاء تعكس الصفاء`؛ `فيها من الخيرات أشكال وألوان وعنده كل ما يخطر
  على البال` — both are the second member of a two-member parallel pair opening a description.
- CUT: `عليها نقوش غريبة ‖ وحولها كراسي أشكالها عجيبة` (a third object added to a spatial inventory);
  `فرأى الجبل عاليا عاليا ‖ وطريق الصعود إليه صعبا` (an accusative-of-state conjunct that is itself
  subject + predicate — N19 family).

**N29 — بالإضافة إلى + a phrase carrying its own relative clause opens a new unit.**
- missed: `وأكثر من 100 ألف شجرة وشجيرة في ربوعها وضواحيها ‖ بالإضافة إلى مدينة الألعاب العالمية التي تشغل
  مساحة…`

**N30 — a stripped one-word question stands alone, and a presentative fragment is its own unit.** N8
confirmed and extended; shortness is still never a reason to glue (N1's corollary).
- missed: `ولا مرتاح البال ‖ لماذا ‖ لأنه سمع بشيء غريب…`
- missed: `إني أعرف ما تريد أن تقول ‖ وإليك الجواب ‖ السر الغريب الذي…`

**N31 — a fronted temporal adverbial sets the SCOPE of its unit: two clauses under one وأخيرا are one
unit.** One site; consistent with L5, so keep as a tendency.
- false: `وأخيرا وقفت السجادة ورأى الضابط نفسه في قاعة فسيحة أمام الساحر` — key joins ورأى even though it
  has a new explicit subject.

**N32 — inside a LIST or layout line the unit is the LINE. No cut at و + finite verb, no cut at a
resumptive-PP clause, no cut between a lead-in and short items. 9 false cuts — my largest error class this
batch.** This CONFIRMS legal L3 outside the legal register: the provision/line, not the clause, is the unit.
- false ×4 (one list, four cuts, all wrong): key runs the lead-in AND all four objectives as ONE unit —
  `ومن أهداف ثورة 23 يوليو القضاء على الاستعمار وأعوانه القضاء على الإقطاع القضاء على الاحتكار وسيطرة رأس
  المال إقامة جيش وطني قوي ‖`
- false ×2: و + finite verb inside one item joins, resumptive pronoun or not, new subject or not —
  `عقد اتفاقية السودان في 12 فبراير 1953 وبمقتضاها أعلن استقلال السودان في يناير 1956 ‖`؛
  `وبمقتضاها تم جلاء آخر جندي بريطاني من مصر وحصلت مصر على الاستقلال التام في 18 يونيو…`
- false ×2: a closing و-clause saying what is DONE with the listed items rides on the list —
  `…خاتم واحد ساعة يد وتتزين بها الفتاة يوم الزفاف ‖`؛ `…قطعة ذهب تلبس في الأنف وتلبسها العروس في ليلة
  الزفاف ‖`. (Confirms L3's killed qualification a second time, now cross-register.)
- false ×2: a dangling identifying هي / وهي belongs WITH its items — `الحلي التي يتم شراؤها من المهر وهي
  شمبر قلادة أو مرية الكف غوص…`؛ `وتضم المدينة تسعا من الضواحي هي هيلي المسعودي قطارة الجيمي…`
  SCOPES legal L2: the stripped colon cuts after a dangling PREPOSITION or a full predication awaiting its
  list (من / في / يحظر عليها / تكفل الدولة), NOT after an identifying copular pronoun.

**N33 — the list-item threshold, in a form that finally fits every site across three registers: an item
earns its own unit when it contains an embedded CLAUSE (a finite verb, a relative, or subject + predicate).
A flat NP/maṣdar + PP item rides with its neighbours however long it is.** This MERGES N19 and legal L6,
which I had stated as raw length; length was the wrong variable and produced 4 false cuts here.
- rides: `القضاء على الاحتكار وسيطرة رأس المال` — 6 words, no clause, still rides.
- own unit: `عقد اتفاقية السودان في 12 فبراير 1953 وبمقتضاها أعلن…` — contains a finite verb.
- batch-3's N19 sites re-read under this test all pass: `ونهرا يجري عبر صدع…`, `وقمم غابات… تغطي أحد
  المنحدرات`, `وسيرها على أقدام غريبة لفترة تصل إلى…` — every one carries an embedded clause.
- **And the lead-in shares the fate of the items**: items ride → the lead-in rides with them (N32);
  items are separate units → the lead-in is its own unit (legal L2).

**N34 — a TWO-member coordination of predicate nominals under one verb stays whole.** N19/N33 per-item
cutting needs a genuine list, not a pair.
- false: `وتعتبر أول كشف تاريخي لفترة كانت مجهولة المعالم والآثار وأضخم كنز أثري تاريخي عثر عليه في مكتبة…`

**N35 — ثم narrating the next PHASE in one entity's history joins; the asyndetic clause after it cuts.**
Scopes N6.
- false: `ضرورية للحماية من الأعداء ثم استعملت سجنا في أيام الحكم البريطاني ‖ تستعمل…` — key joins ثم and
  cuts at the asyndetic present-tense clause. Asyndeton beats ثم, again.

**N36 — كما REPEATING the same verb to add a second piece of evidence joins.** Scopes legal L4 (كما + a
genuinely new predication cuts) — it is the repetition that joins.
- false: `أن أيبلا هي أول من طور نظام الكتابة المسمارية كما تدل على أقدم تعاون سياحي تم في…`

**N37 — حيث elaborating the place just named is a locative relative and JOINS.** Downgrades N18 from a 2/2
law to a tendency: حيث cuts when it opens a new observation, joins when it hangs off a place noun.
- false: `الخضرة سمة أساسية من سمات مدينة العين حيث تضم 24 حديقة غناء وتسع غابات كثيفة`

**N38 — an asyndetic finite verb after a complete clause in an encyclopedic definition CUTS, even when it
reads as a صفة on the last NP.**
- missed: `نوع من الأسماك يتميز باحتوائه على أعضاء كهربائية ‖ تتكون من خلايا خاصة مرتبة بشكل…`
- This is 1–1 against N18's contrast note (`مئات الخلايا ‖ تحول طاقة الشمس` was a false cut in batch 3).
  Tie-break by local density: in a dense definition entry, cut; in a running descriptive sentence, join.

**N39 — DENSITY IS PROMOTED FROM SANITY CHECK TO ACTIVE TOOL. This amends N10, which said density "cannot
buy me another point."** It bought both of this batch's failures, in advance:
| doc | key w/unit | my w/unit | result |
|---|---|---|---|
| doc_666e6f739000 | 9.4 | 9.5 | F1 91.5 — my best |
| doc_78b2ed132e2f | 10.7 | 9.1 | P 80.3 — over-cut |
| doc_f41918b2700e | 10.0 | 12.2 | R 73.3 — under-cut |
**Narrative target: 9.5–11 words per unit.** Above 12 → I am missing cuts; below 9.5 → I am inventing them.
Count before submitting and re-walk if outside the band.

**N40 — a run of parallel PP-predicate obligations inside ONE speech turn is not one unit per member.**
Key cut 1 of 3; the short and echoing members ride. 2 false cuts.
- false: `فنحن كما تعلم يا مولاي في موسم الحصاد وعلينا أن نحسم الأمور بين المزارعين والتجار في…` — joins.
- false: `…في نقل الأسماك من مدينتنا إلى المدن المجاورة وأمامنا كذلك ‖ قاطعه الملك…` — an interrupted
  trailing fragment rides backward (batch-1 RULE 8, confirmed).
- Default to riding; reserve the cut for the member that genuinely restarts the predication (ولدينا… did cut).

**N41 — do not invent ad-hoc "it merely completes the thought" exemptions for و + finite verb.** This is the
single habit that produced most of doc_666's misses. The exemption list for و + finite is CLOSED:
a non-finite conjunct; a verbless parallel attribute (N28); a و-linked negative run inside one description
(N16); a short bare fragment; a genuine sub-step (N23); anything inside a list item (N32).
- missed: `إنني مرهق جدا ‖ ولن يستفيد برأيي ومشورتي أي طرف من الأطراف` — I called it "a negative clause
  completing the thought." It has a NEW SUBJECT. Cut.
- missed: `فقد كرهت هذه المواكب التي تقيدني ‖ وأحب أن أشعر بالحرية مثل أي شخص عادي` — I called it "a
  balanced contrast." It is a new state. Cut.
- missed: `مرتبة بشكل يشبه قرص الشمع في خلية النحل ‖ وتحيط بها مادة لاصقة` — new subject. Cut.

### narrative — the laws that worked this batch (zero errors at these sites; keep)
- **Speech frames and quoted sentences: zero errors.** قال الوزير / قال الملك / قاطعه الملك قائلا each opens
  a unit; the first quoted sentence rides on its frame; every quoted sentence after it is its own unit (N8).
- **فـ + a nominal subject cuts: zero errors, second batch running.** فهو، فهي، فنحن، فاللحية، فأحاديث،
  فمدينتنا، and فقد + perfect. N12 confirmed.
- **Fronted adverbials open the unit they precede: zero errors, fourth batch running.** وفي إحدى ليالي
  الصيف الحارة، وبعد دقائق قليلة، بعد نصف ساعة، ومع الوقت، لذلك، كذلك. L5 confirmed.
- **Subordination holds a unit together however long it runs: zero errors.** التي / الذي / أن / لأن /
  حينما / إذا / لـ — a 28-word لذلك قرر الملك period and a 27-word closing sweep were each single units.
  N17 confirmed; length still never licenses a cut.
- **Asyndeton + a re-stated explicit subject remains the strongest boundary in the language: zero errors.**
  أخذ الملك، اعتاد الملك، أمر الملك، ركب الملك، سار الضابط، فتح الضابط، عاد الضابط، سار الجنود.
- **Every layout element is its own unit: zero errors.** Masthead, byline, item headline, standing rubric,
  photo caption, field label+value line — the one part of the magazine page I got completely right.
- **إذ never cuts under the `narrative` label** — no sites to test this batch, but the default held from N11.

### Method note for batch 5
1. **Count first, and count last.** Narrative target 9.5–11 w/unit (N39). Outside the band, re-walk the
   document before submitting — that check alone would have caught two of this batch's three documents.
2. **Decide the SHAPE of each stretch before applying any connective rule**: running prose (the clause is
   the unit) vs list / layout line (the LINE is the unit, and nothing inside it cuts — N32). Half of the
   magazine page was lists and I segmented it as prose.
3. In prose, at every و / فـ / ثم ask N23's four questions: same place? same state? same subject? one
   bounded act? Only all four yes → join. A change of location alone is enough to cut.
4. Find the run's HEAD and cut before it; never cut inside the run (N24). Third batch in a row that this
   single error has cost me double.
5. In a list, measure the item by N33: embedded clause → own unit; flat NP+PP → rides, however long. The
   lead-in shares the items' fate.
6. ولكن is a coin-flip (N25): bare short reversal → join; new content → cut.
7. Hard defaults that have still never failed: never cut inside a relative or an أن-complement; never cut
   at إذ in narrative; layout lines, quoted sentences and stripped one-word questions each get their own
   unit; a fronted adverbial opens its unit.

---

## BATCH 5 (21 docs: 5 `quran`, 5 `bible`, 4 `exercise`, 4 `narrative`, 1 `poetry`, 1 `conversational`, 1 `other`)
| doc | label | F1 | P / R | my cuts / key | errors |
|---|---|---|---|---|---|
| doc_127c1535d7d9 | quran | **100.0** | 100 / 100 | 18 / 18 | 0 |
| doc_9e0419ed749d | quran | **100.0** | 100 / 100 | 128 / 128 | 0 |
| doc_d5e46166411c | quran | **100.0** | 100 / 100 | 77 / 77 | 0 |
| doc_ea9c5c63ae76 | quran | **100.0** | 100 / 100 | 30 / 30 | 0 |
| doc_f876524dd98e | quran | **100.0** | 100 / 100 | 49 / 49 | 0 |
| doc_b9371c2fbb78 | poetry | **100.0** | 100 / 100 | 133 / 133 | 0 |
| doc_b58385fe50df | bible | 98.6 | 97.1 / 100 | 35 / 34 | 1 |
| doc_cb57e21e8421 | conversational | 98.6 | 97.3 / 100 | 37 / 36 | 1 |
| doc_20dcf69f9905 | exercise | 94.0 | 99.0 / 89.5 | 103 / 114 | 13 |
| doc_9ad9ba0d12d4 | narrative | 92.6 | 88.0 / 97.8 | 50 / 45 | 7 |
| doc_3484c02411e9 | narrative | 87.9 | 86.6 / 89.2 | 67 / 65 | 16 |
| doc_51f6f776f3c7 | narrative | 87.9 | 79.7 / 98.1 | 64 / 52 | 14 |
| doc_4f0612ce35d1 | bible | 87.4 | 77.6 / 100 | 49 / 38 | 11 |
| doc_d86f75defe49 | bible | 87.0 | 76.9 / 100 | 65 / 50 | 15 |
| doc_51fccce927eb | exercise | 85.1 | 93.6 / 78.0 | 171 / 205 | 56 |
| doc_df532033acd3 | bible | 84.7 | 81.8 / 87.8 | 44 / 41 | 13 |
| doc_0c92fc467c35 | narrative | 84.1 | 80.6 / 87.9 | 36 / 33 | 11 |
| doc_f2767b56c842 | bible | 83.3 | 72.7 / 97.6 | 55 / 41 | 16 |
| doc_f7c344e48e78 | other | 56.3 | 95.2 / 40.0 | 42 / 100 | 62 |
| doc_741bfb3bda19 | exercise | **46.0** | 100 / 29.9 | 20 / 67 | 47 |
| doc_87ac286b6785 | exercise | **46.0** | 100 / 29.9 | 20 / 67 | 47 |
**330 errors.** Six perfect documents and two documents at F1 46.

### THE OVERRIDING LESSON OF BATCH 5 — THE GRID IS THE ONLY BOUNDARY GENERATOR, AND I MUST RESOLVE IT TO THE FINEST THING THE PAGE PRINTS
248 of the 330 errors (75%) are in five documents that are printed GRIDS, not prose. The same single
mistake produced both my perfect scores and both my disasters, in three different postures:
- **Grid read at its own grain -> 100.0, six times.** 5 quran (the ayah) + 1 poetry (the بيت). Zero errors
  across 437 boundaries. When the layout unit is known exactly, syntax is inoperative and I am perfect.
- **Grid read, then syntax ADDED on top -> 42 false cuts.** All five bible docs. I took the verse AND the
  Van Dyck edition's internal full stops. The verse alone was right every time (B1).
- **Grid read too COARSELY -> 225 missed cuts.** 4 exercise + 1 exam. I took the *item* as the unit when the
  key takes every printed *cell*: each option, each صح, each word in a bank, each table header (E1).
The generalisation, and it now outranks every connective rule I own: **first decide whether the document is
prose or a grid. If it is a grid, find the smallest thing the page prints as its own line/cell, make THAT
the unit, and switch the entire connective table off in both directions — it neither creates nor cancels a
boundary.** My record already said this three times (legal L3, N32, N33). It is not a legal or list fact;
it is the master fact, and it governs 11 of this batch's 21 documents.

**And N39's density check called every single failure before grading:**
| doc | key w/unit | my w/unit | what it meant |
|---|---|---|---|
| doc_741bfb3bda19 / doc_87ac286b6785 | **2.6** | 8.8 | catastrophic under-cut (R 29.9) |
| doc_f7c344e48e78 | **4.2** | 10.0 | catastrophic under-cut (R 40.0) |
| doc_51fccce927eb | 5.0 | 6.0 | under-cut (R 78.0) |
| doc_f2767b56c842 | **14.5** | 10.8 | over-cut (P 72.7) |
| doc_d86f75defe49 | 12.9 | 9.9 | over-cut (P 76.9) |
| doc_4f0612ce35d1 | 13.8 | 10.7 | over-cut (P 77.6) |
| doc_51f6f776f3c7 | 12.3 | 10.0 | over-cut (P 79.7) |
Every band I had stored was for the wrong genre. New bands, all measured on this batch's keys:
**bible 11–14.5 · exercise/worksheet 2.5–6 · exam MCQ 4–4.5 · narrative 8.4–12.3 (wider than N39's 9.5–11)
· quran/poetry: do not use density, count verses/lines.**

---

### bible — a whole register I had never been graded on, and one law explains 42 of its 43 errors

**B1 — THE UNIT IS THE VERSE. EXACTLY THE VERSE. 5/5 documents, and in every one the key's cut count is
the passage's verse count to the digit.** Gen 4:25–5:32 = 34 = key 34. Matt 19:27–20:34 = 38 = key 38.
Mark 2:23–3:35 = 41 = key 41. Luke 12:54–13:35 = 41 = key 41. Luke 16:1–17:19 = 50 = key 50.
I built two of these documents on "the PRINTED SENTENCE of the Van Dyck edition, not the verse", reasoning
that a finely punctuated edition supplies extra stops. That model is simply wrong, and it cost 42 of my 43
bible errors. The verse is a line of the source file; the edition's commas and full stops were never in the
annotator's hands.
- **Nothing inside a verse ever cuts. Not one of these was a boundary:**
  a change of SPEAKER — `قالوا له لأنه لم يستأجرنا أحد قال لهم اذهبوا أنتم أيضا إلى الكرم`؛
  `فقال لها ماذا تريدين قالت له قل أن يجلس ابناي`؛ `قالا له نستطيع` (all one verse, all joined);
  a QUESTION — `ها نحن قد تركنا كل شيء وتبعناك فماذا يكون لنا`؛ `ما ظلمتك أما اتفقت معي على دينار`؛
  `أليس العشرة قد طهروا فأين التسعة`؛ `ماذا يشبه ملكوت الله وبماذا أشبهه`;
  a bare VOCATIVE — `فيكون يامراؤون تعرفون أن تميزوا`؛ `وقال يا مرائي ألا يحل`؛
  `يا أورشليم ياأورشليم يا قاتلة الأنبياء وراجمة المرسلين إليها كم مرة أردت`;
  a bare IMPERATIVE or DENIAL — `ولم أجد اقطعها لماذا تبطل الأرض`؛ `لأنهم كابدوا مثل هذا كلا أقول لكم`؛
  `لا تذهبوا ولا تتبعوا`؛ `لأنه فعل ما أمر به لا أظن`;
  بل — `فلا يكون هكذا فيكم بل من أراد أن يكون فيكم عظيما`;
  فـ / و + finite — `فأعطيكم ما يحق لكم فمضوا`؛ `ظنوا أنهم يأخذون أكثر فأخذوا`؛
  `وحملته الملائكة إلى حضن إبراهيم ومات الغني أيضا ودفن`؛ `شاكرا له وكان سامريا`؛ `إن معه بعلزبول وإنه برئيس الشياطين`;
  a fronted temporal — `ولشيث أيضا ولد ابن فدعا اسمه أنوش حينئذ ابتدئ أن يدعى باسم الرب` (my single error on
  my best bible doc).
- **And every verse edge cuts, even straight through the syntax** — the mirror image, and where my
  "printed sentence" model lost recall as well:
  missed `من الجليل ومن اليهودية ‖ ومن أورشليم ومن أدومية` (Mark 3:7/8 — mid-PP-list);
  missed `كي لا يزحموه ‖ لأنه كان قد شفى كثيرين` (3:9/10 — before لأن);
  missed `وليرسلهم ليكرزوا ‖ ويكون لهم سلطان` (3:14/15); missed `وسمعان القانوي ‖ ويهوذا الإسخريوطي` (3:18/19);
  missed `ها أمي وإخوتي ‖ لأن من يصنع مشيئة الله` (3:34/35);
  missed `أقليل هم الذين يخلصون فقال لهم ‖ اجتهدوا أن تدخلوا` (Luke 13:23/24) — **the verse edge severs a
  speech frame from its own quotation.** So legal L2's quote exception and N20 are suspended: in bible the
  frame carries its quote only when they share a verse.
- **How to find the verse edges with the marks stripped**: the passage identity (Van Dyck is one verse per
  line), then the verse's characteristic onset — و / فـ + a perfect verb, or a re-stated proper name — plus
  the density band 11–14.5 w/unit as the count check. If my count is materially above the verse count of
  the passage, I have invented verse-internal stops.

**B2 — the one bible finding that is NOT the verse law: my `doc_df532033acd3` and `doc_f2767b56c842`
pre-grading laws were reasoning backwards.** I wrote "it coincides with the verse end 36 times out of 41,
cuts inside a verse at 8 further points, and refuses the verse boundary at 5" — and the key was exactly
41 = the verse count. **When my model produces the right TOTAL by adding N internal cuts and subtracting N
structural ones, that is the signature of a model that has the right unit and is corrupting it.** Suspect
the arithmetic coincidence and fall back to the pure structural unit.

---

### quran — zero errors on five documents, 302 boundaries. The law that worked, stated once:
**THE AYAH IS THE SENTENCE, and the fasila (verse-final rhyme) is the in-document proof.** The verse marker
is the only punctuation scripture carries, so it is the only mark this corpus could have stripped. Below the
ayah the connective table is inoperative in both directions: it refuses cuts my rules demand (و + finite
fires ~40 times inside verses of al-Furqan; a 43-word 2:164 and a 32-word 16:35 stay whole across asyndetic
topic jumps; فـ, ثم, imperative restarts) and it takes cuts my rules forbid (before a relative on the
preceding noun, before a purpose-lam, before a bare ḥāl, inside an أو-series, mid-construct
`وكتب مسطور ‖ فى رق منشور`). Densities ranged 6.4 -> 17.0 w/unit across the five, which is exactly why
density must not be used here: **count verses, check every boundary word carries the rhyme, check the
verses partition all the words with nothing left over.** Three checks, no judgement calls.

---

### poetry — zero errors, 133 boundaries. The law that worked:
**THE VERSE LINE IS THE SENTENCE — one بيت (صدر + عجز, closing on the rhyme) is one unit, and each poem's
title is one unit.** Syntax neither creates nor cancels a boundary: enjambment runs across the caesura and
across the line end and the line still ends the unit; subordinators, coordinated NPs and unfinished
conditionals straddling a line end are cut anyway.
> Caution recorded from `exercise` doc_20dcf69f9905: this inviolability is a property of the POETRY label.
> When a poem is quoted inside a worksheet, its hemistichs split further at internal predications. See E7.

---

### exercise — 163 errors, my worst topic ever, and one law fixes almost all of it

**E1 (the biggest single error class in my entire record — ~200 error-points across 5 documents). EVERY
PRINTED CELL IS A UNIT. In a worksheet or a quiz, each answer option, each true/false token, each word of a
word bank, each table cell, each matching-list entry is its own sentence-unit — however short, however
repetitive.** I took the ITEM as the unit ("stem + its options ride together, they are short flat NPs with
no embedded clause, L6/N33"). The key resolves one level finer, everywhere.
- key: `يسمى صغير الحصان جدي ‖ صح ‖ خطأ ‖ عندما تنمو الحيوانات يزداد ‖ حجمها ‖ طولها ‖ كلاهما ‖` — 20 items,
  67 units. I cut 20. **This one misreading is 47 errors in doc_741bfb3bda19 and 47 more in doc_87ac286b6785.**
- key: `حافلة ‖ خلود ‖ سحور ‖ خليل ‖ أخي ‖ خميس ‖ حروف ‖ عجمان ‖ نخيل ‖ حضور ‖ خرز ‖ دجاج ‖ جموع ‖ مساجد ‖ حصير ‖ خروف ‖ حكيم ‖ خالق ‖ نجوم ‖ جميل ‖`
  — a 20-word sorting bank, 20 units. Also `ممرضة ‖ ممرضات ‖ معلمون ‖ معلم ‖`, `معلمتي ‖ الغصن ‖ ألعاب ‖ الباحة ‖`,
  `أبي ‖ الغالي ‖ مدرستي ‖ الباحة ‖`.
- key (exam, doc_f7c344e48e78): `الجبل ‖ الهضبة ‖ الوادي ‖ السهل ‖`؛ `1925 م ‖ 1940 م ‖ 1930 م ‖ 1935 م ‖`؛
  `320 جزء من المليون ‖ 340 جزء من المليون ‖`؛ `2 4 مليون كم 2 ‖ 2 5 مليون كم 2 ‖`؛ and options that carry
  their own PP tail — `الصحراوية لوجود الكثبان الرملية ‖ الجبلية لصلابة صخورها ‖ الساحلية لاعتدال مناخها ‖`.
- **This REVERSES N33 and legal L6 for the exercise/exam register.** N33 said a flat NP item with no embedded
  clause rides with its neighbours however long it is; that is true of a prose list printed as running text
  (legal competence lists, the magazine objectives list) and FALSE of an answer block printed as separate
  rows. Changed because 225 error-points sit on the wrong side of it. The discriminator is not the item's
  grammar, it is whether the page prints the items on one line or on N lines — and in a quiz it is always N.

**E2 — the stem cuts from its options, even when the stem breaks off on a dangling function word.** This is
legal L2 with the "identifying copula" exception deleted: in a quiz **every** dangling lead-in cuts.
- key: `تهاجر الطيور بحثا عن ‖ الطعام ‖ الدفء ‖ كلاهما ‖`؛ `يصنع الخبز و البسكويت من ‖ القمح ‖ السمسم ‖ الزيتون ‖`؛
  `عندما تنمو الحيوانات يزداد ‖ حجمها ‖ طولها ‖`؛ `تسعى دول الخليج العربية إلى توفير ‖ الرعاية البيطرية ‖ …`؛
  `لأنه يتميز ب ‖ ضخامة الحمولة ‖ …`؛ `بموجب معاهدة ‖ سيفر ‖ الصلح ‖ فرساي ‖ لوزان ‖`؛
  and against N32 explicitly: `نوع السياحة التي قام بها هي ‖ البيئية ‖ الثقافية ‖` — **a dangling identifying
  هي DOES cut here.** N32's "a dangling هي belongs with its items" is scoped to prose lists.
- Also a dangling exemplifier: key `مع عنصر آخر مثل ‖ احتراق الكربون الموجود في الفحم`.

**E3 — an exam item's SCENARIO or QUOTED DEFINITION and the question that refers back to it are ONE stem
unit; the only cut is before the options.** 2 false cuts — my only precision losses on the exam paper.
- key: `زراعة بعض المحاصيل في غير مواسمها يشير التعريف السابق إلى مفهوم الزراعة ‖ الرملية ‖ المروية ‖ …`
- key: `توجه أحد طلاب العلم من سلطنة عمان للدراسة في جامعة قطر نوع السياحة التي قام بها هي ‖ البيئية ‖ …`

**E4 — each QUESTION is its own unit even when و-coordinated to the one before it.** I had suppressed these
under "nothing cuts inside an item". 3 missed.
- key: `ما اللوحة التي تحوي أسماء التلاميذ ‖ و ما فائدتها ‖`؛ `مما ليس موجودا فيه ‖ ولماذا ‖`؛
  `بم تشبه المعلمة الأم ‖ وبم يشبه المعلم الأب ‖`.

**E5 — a numbered lesson/section label is its own unit, and so is each table-header cell.** The opposite of
legal L1 (`الباب الأول الأسس العامة` joined) and the same as legal's `مادة 282`.
- key: `الدرس الأول ‖ مدرستي ‖`؛ `الدرس الثاني ‖ صفي ‖`؛ `الدرس الثالث ‖ معلمي و معلمتي ‖`؛ `الدرس الرابع ‖ نشيد يا مدرستي ‖`
- key: `الكلمة ‖ المعنى السياقي ‖ توظيفها في سياق جديد ‖`؛ `العبارات ‖ رقم البيت ‖`؛ `الموقف ‖ التعليل ‖`؛
  `العمود الأول ‖ العمود الثاني المعنى ‖`؛ `رقم البيت المطلوب ‖ الإجابة ‖`.
- key: `أنشد ‖ بأداء معبر ‖`؛ `في المدرسة ‖ أحب ‖` — a rubric verb and its qualifier are two lines.

**E6 — a quotation lead-in DOES cut in a worksheet: `قال الشاعر` is its own line.** 2 missed. This SCOPES
legal L2's quote exception and N20 (which had made "lead-in + quote never cuts" cross-register): the
exception holds in running prose, and fails wherever the lead-in is printed as its own line.
- key: `قال الشاعر ‖ يهدد الأرض مذ أمسى هو البطلا ‖`؛ `قال الشاعر ‖ بالنبت تلقاه مفروشا ومنصوبا ‖`

**E7 — a poem quoted inside a worksheet splits BELOW the hemistich, at each internal complete predication.**
2 missed. The poetry register's line-inviolability does not travel.
- key: `حمض سموم غبار ‖ كونت مطرا ‖`؛ `الأرض تصرخ ‖ من يأتي يساندها ‖`

**E8 — a field LABEL heading a multi-line block is its own unit; a label whose value sits on the same line
rides with it. And inside the value block, asyndetic apposed predications ride.** One missed + one false, a
displacement pair, on the same bio card.
- key: `اسم الشاعر د معتز علي القطب ‖ حياته ‖ من مواليد مدينة القدس وسكانها حاصل على درجة الدكتوراة في العلوم ويعمل في…`
  I did the inverse — joined `حياته` to its block and then cut the block at `حاصل`.

**E9 — in a worksheet DIALOGUE the unit is the SPEAKER TURN, not the sentence.** 5 false cuts. This is the
opposite of the `conversational` register (C1 below: inside a comic balloon every sentence cuts), and the
reason is layout again: the reader prints one turn per line.
- false: `تعلمنا كيف نصلي ‖ وصلينا الظهر` — joins; `تستحق الآن أطيب طعام ‖ هيا بنا لتناول طعام الغداء` — joins;
  `وأنا أحترم معلمتي ‖ أنتبه للدرس وأتكلم بصوت واضح` — joins; `بارك الله فيكما ‖ فالمعلمة كالأم عطفا وحبا` — joins;
  `الأب أحسنتما ‖ والمعلم كالأب رعاية واهتماما` — joins.
- But where the reader is set as SHORT lines the turn splits at each phrase: missed `ماجد صفي جميل ‖ فسيح ومرتب ‖`،
  `كتب مفيدة وقصص ممتعة ‖ وحاسوب جديد وصور ملونة ‖`. Irreducible without seeing the line breaks; the usable
  signal is that a primary-school reader's lines are 3–6 words, so at ~5 w/unit err toward splitting.

**E10 — residual layout noise in worksheets. Do not chase.** `معلمي أبي جدي الباحة أمي الكتب ‖ صفي ‖ مدرستي ‖ جدتي ‖ عائلتي ‖`
(two picture-boards, the first printed as one row of six and the second as four rows); `أنا أقرأ ‖ القصة الرافدة أنا أقرأ قصصي الممتعة ‖`
against `القصة الرافدة المكتبة قصصي الممتعة ‖` and `القصة الرافدة أصنع كتابي من كتاب قصصي الممتعة ‖` joined. Same
rubric, three groupings. Take the finest grain as the default (E1) and accept these.

---

### narrative — 48 errors on four documents; no old law broke, three new ones and two inversions

**N42 — THE TWO-MEMBER PARALLEL PAIR JOINS, whatever the connective and whatever the category.** 8 false
cuts across three documents. This GENERALISES N34 (which I had stated only for coordinated predicate
nominals under one verb) and gives N22's "noise" a rule.
- `كان البحر يمده بالخيال وكانت مغامرات البحر تذكره بالمغامرات القديمة` — و + finite, joins (against RULE 4/N41).
- `هي التي قررت أن تقف في وجه السلطان شهريار وهي التي لم تكن تملك من سلاح غير…` — two clefts, joins.
- `لعله يقابل في البعيد شهرزاد أو السندباد ولعله يرى في السماء شديدة الزرقة بساط الريح` — two modals, joins.
- `وشركة أرمكو معروفة عالميا بمستوى الصيانة والحماية وحصلت على الكثير من الجوائز العالمية` — joins.
- `ممكن أن تحل من خلال العقل والحوار والمساومات ممكن تكون هي المخرج من أتون السعير` — an ASYNDETIC parallel
  pair joins, so N14 ("asyndetic repetition cuts") is scoped: repetition of a NARRATIVE verb cuts
  (`يكبر ‖ يكبر`), repetition of a MODAL/predicative frame across a balanced pair joins.
- `ولم يتوقف كورساكوف عند حدود الهواية أو الموهبة لكنه واظب على الدروس الموسيقية` — N25's join side confirmed
  (negation left, same subject, bare reversal); `كما كانوا يقولون عنها لكنها لم تعد شابة وليست كهلة` likewise.
- **Test: two members, same frame, same subject or a cleft/modal echo, second member adding no new event.**
  A third member -> it is a list, and N19/N33 take over.

**N43 — A VOCATIVE NEVER STANDS ALONE. It belongs to the clause that FOLLOWS it; cut before it, never after
it.** 2 false + 1 missed in one displacement pair, and independently confirmed at four bible sites (B1).
Now cross-register, and it is a special case of L5 (a fronted element opens its unit).
- key: `…ويتكلمون بما لا يرون ‖ يا رجل إنها أنفس ليست ألعاب الأطفال الصغار ‖` — I cut after `يا رجل`, the key
  cuts before it.
- key: `إنها أرواح أزهقت يا رجل أرواح ‖` — a POSTPOSED vocative rides backward, and so does the bare echo
  after it. So: vocative + following clause = one unit; trailing vocative = tail of the unit it closes.

**N44 — a comment's ADDRESSEE line rides with the first sentence of the comment.** 2 false cuts. It is not a
printed layout line, so the grid law does not reach it; it is a fronted adverbial phrase (L5) and takes its
clause with it. Corrects my own genre law for this document, which had made it free-standing.
- key: `ردا على الأخ فيصل اليامي هذا الحادث قضاء وقدر ‖`؛ `إلى الأخ رقم 1 من هم قبيلة ورسنكلي ‖`
- Still free-standing, zero errors: the formulaic exclamations and invocations — `لا حول ولا قوة إلا بالله`،
  `علم`، `وفق الله الجميع لما يحبه ويرضاه`، `حسبي الله ونعم الوكيل`، `أرواح`.

**N45 — a BIOGRAPHICAL life-story chain is one run: و / ثم + the next phase of one life joins.** 3 false
cuts. This is N24's chain law and N35's phase law meeting: the run starts at the birth verb and its
sub-steps are the life's stages, so N23's "a change of state cuts" does NOT reach a biography's phases.
- key: `ولد في روسيا في العام 1844 ونشأ في أسرة فنية تحب الموسيقى وتعشق الآلات ‖`
- key: `وألف العديد من القطع الموسيقية وهو صبي ثم التحق بالكلية البحرية ‖ لعله يقابل…` — the cut is at the new
  modal period, not at ثم.
- And N24 violated a fifth batch running, same shape as always: key
  `كان الطفل كورساكوف قد بلغ الثالثة من عمره ‖ زحف وضرب بيده على البيانو فانطلقت الموسيقى ولم تتوقف ‖` — I glued
  the run's head `زحف` backward and cut inside the run at `فانطلقت`. One false cut plus one miss, again.

**N46 — وهي / وهو + a bare predicate nominal commenting on the thing just named is its OWN unit; وهي + التي…
continuing the same predication JOINS. This is the exact inverse of what I wrote before grading.** I had
"وهي + a bare predicate nominal rides backward, وهي carrying an embedded clause is its own unit". 3 errors.
- missed: `السيمفونية التي كتبها اسمها شهرزاد ‖ وهي مقطوعته الأكثر شهرة ‖` — bare predicate nominal, CUTS.
- false: `أن تقف في وجه السلطان شهريار وهي التي لم تكن تملك من سلاح غير…` — relative continuation, JOINS.
- false: `صور لصديقة لي كنت قد التقطتها منذ بضعة شهور وهي التي اقترحت علي هذه الرحلة الصحراوية` — JOINS.
- Reconciles with N33's clause test by reading it the other way round: the clause inside `وهي التي…` is what
  ties it to its head, not what frees it. Batch-1 RULE 5 (a bare apposed nominal is its own unit) is the
  half that survives.

**N47 — in ASYNDETON-DOMINATED literary prose, match the LOCAL rhythm: an action passage cuts at every bare
verb; a descriptive passage runs the whole period.** 8 missed + 6 false in one document, evenly split — the
purest placement failure of the batch, and the discriminator is passage-level, not junction-level.
- CUTS, every bare verb, including the "instrumental second act" I had exempted (this kills that exemption
  outright): key `خلعت شالها الصوفي الأخضر من حول كتفيها ‖ فرشته فوق الحجر لتجلسها ‖ كانت تجاهد للوقوف ‖ تشد
  عضلاتها ‖ تقاوم الانحناء ‖ يعود قوامها إلى وضعه المستقيم ‖`؛ `أخرجت من حقيبتها زجاجة ماء معدنية صغيرة ‖ ناولتها
  إياها`؛ `حملوها إلى الخيمة ‖ غطوها بالبطانية الصوف`؛ and a possessive sub-part predication also cuts —
  `عظام ظهرها قوية متينة ‖ لها قوة أربعين رجلا`؛ `عيناي خضراوان لونهما لون الزرع ‖ تلمعان في مرآة حقيبتي`.
- JOINS, in the descriptive periods: `له لون الرماد يشقها مجرى رفيع رمادي يتلوى تحت كتل الأسمنت`؛
  `على جانبيه يعلوها دخان وبخار وقتام`؛ `جلست فوق حجر بجوار خيمتها كانت تلهث قليلا`؛
  `هؤلاء الملايين النساء الشباب… العجائز هذه الوجوه من كل الأعمار`؛ `التي تجتاز النيل كوبري الجيزة كوبري الجامعة…`؛
  `ألقت البلوفر والشال وحقيبة يدها إلى الأرض وانطلقت وسط الملايين تهتف معهم يسقط النظام`؛
  `وتسقط على الأرض فبدت لها دماء حمراء`.
- Usable form: a verb-initial clause introducing a NEW indefinite subject that fills in the scene
  (`يشقها مجرى`، `يعلوها دخان`) is presentative description and rides; a كان + state accompanying the action just
  reported rides; و + the next sub-step of one physical act rides; فـ + its immediate result rides. Everything
  that reports a NEXT ACT cuts. I could not do better than this and I record it as a rhythm rule, not a
  junction rule — the same honesty as N28.

**N48 — a literary DIARY / travelogue period is long: descriptive predications, فـ-results, ثم-steps,
appositions, fronted adverbials and لكن all ride inside it. 13 false cuts, my worst precision of the batch
(79.7), from one sentence in my own pre-grading law: "asyndeton with a new predication is the boundary; it
fires at almost every paragraph-internal junction here."** Key density 12.3 w/unit against my 10.0.
- joins: `القليل القليل من الإنجليزية ويصطحبني بسيارته بعد الظهر`؛ `يفك لافي وصبي آخر اسمه رحمان قيده فينتصب ثم يسرج`؛
  `يقفز الجمل على حين غرة وبصعوبة يستطيع رحمان امتطاءه` (**a fronted adverbial + a new subject, and it still
  joins — so L5 says where the boundary goes IF there is one, it does not create one**);
  `تنزع الخمار في البيت وجهها جميل فيه بعض البثور`؛ `أنوي الخروج لكن يفاد إلي بأن ذلك ليس ضروريا`؛
  `يدخل رجال إلى المنزل ثلاث مرات أحدهم مبارك الدليل الآخر فتحجب صالحة وجهها بسرعة البرق ‖`؛
  `فتأخذ الصور التي تبرزها عارية الوجه وبعد إلقاء نظرة عابرة عليها سرعان ما تضعها`؛
  `هل ذعرت من وجه نادرا ما تراه أنا الرجل لا أشاهد مرآة في المنزل أم أنها تريد من باب الحشمة حمايته ‖`
  (**a whole speculative question-block, two questions and a parenthesis, is ONE unit**);
  `لقد أسرجت الجمال الثلاثة غطاء على السنام عليه السرج الخشبي الثقيل`؛ `من الأمام والخلف وعلى السرج أغطية وحصائر`.
- The one cut I missed there is a layout element, not prose: `في خليج العقبة ‖ تهب ريح قاسية باردة` — the
  entry's PLACE-LINE under its dateline is its own unit.
- Rule for next time: **in descriptive first-person prose require a new EVENT or a new TOPIC, not merely a
  new predication.** N41's closed exemption list for و+finite was written for plot narrative and must not be
  applied to description.

### narrative — the laws that worked this batch (zero errors at these sites; keep)
- **Asyndeton + a re-stated explicit subject or a topic jump: still the loudest boundary in the language.**
  Every paragraph restart and every `من هو إذن / إنه الفنان / أبوه / الحركة الأولى / كل هذا` junction correct.
- **Subordination holds however long it runs: zero errors, fifth batch running.** التي، الذي، أن، لأن،
  عندما، بينما، وكأن، كي، لو، temporal حتى، the وإن كان…لكن concessive correlative, comparative كما.
- **ثم + a genuinely new event cuts** (`وهي لا تكف عن الكلام المباح ‖ ثم انتصرت شهرزاد لجنسها وحياتها`) — N6
  correct where the event is new, N35/N45 correct where it is the next phase.
- **Titles, standing heads, datelines, bylines, translator/reviser lines: each its own unit, zero errors.**
- **Quoted sentences and formulaic free-standing exclamations: zero errors** (N8; and the slogan
  `يسقط النظام` correctly ridden on its frame every time it appeared — a two-word slogan is a quotation).

---

### conversational — 1 error on 36 boundaries (F1 98.6)
**C1 — a comic masthead's SERIES name and EPISODE title share one line: `أبو الظرفاء مطلوب شاهد ‖`.** My
only error. This is legal L1's label+title line in another costume: a standing head and the specific title
under it are one unit, while the credits below (`سيناريو محمد قنديل ‖ رسوم هانئ دراج ‖`) are one each.
- The rest of the law, zero errors, keep: the unit is the UTTERANCE — every change of speaker is a boundary,
  and inside one balloon every complete sentence (statement, question, imperative, exclamation, bare echo,
  one-word reaction) is its own unit, while PP conjuncts sharing an elided head and all subordinate material
  stay inside. Natural density ~4 w/unit, a property of the text type. **Contrast E9: in a worksheet
  dialogue the whole TURN is one unit. Balloon is not the same object as a reader-line.**

---

### expository — no documents this batch. The laws stand untested; nothing changed.
### legal — no documents this batch. But L3 (the provision/line is the unit) was confirmed a fourth time
from the outside, as the master grid law of the overriding lesson; and L1/L2/L6 were each scoped by the
exercise register (E5 splits a numbered label from its title, E2 deletes L2's copula exception, E1 reverses
L6/N33 for printed answer rows).
### hadith — still no documents in five batches. No law, no evidence. If one appears my prior is the grid
law: the matn/isnad line is likely the unit, and I should look for the transmission formula
(حدثنا / عن / قال رسول الله) as the line onset before touching any connective.

### Method note for batch 6
1. **PROSE OR GRID? Decide before reading a single connective.** Grid signals: repeated short rows, option
   runs, صح/خطأ, rubric verbs, table headers, verse rhyme, hemistichs, label+value pairs. If grid: find the
   finest printed cell, make it the unit, and switch the connective table OFF in both directions.
2. **Resolve the grid to its finest grain.** Ask "would this appear on its own row on the page?" — for an
   answer option, a bank word, a header cell, a lesson label, the answer is yes. 225 recall points said so.
3. **Never add syntax on top of a structural unit.** If the unit is the verse or the line, the edition's
   internal full stops, speech turns, questions, vocatives and imperatives are all invisible. 42 precision
   points said so.
4. **Count against the band before submitting** (N39, now with this batch's numbers): bible 11–14.5,
   quran/poetry count verses instead, exercise 2.5–6, exam 4–4.5, narrative 8.4–12.3, expository 13–16,
   conversational ~4. Outside the band, re-walk. It has now predicted every failure in two consecutive batches.
5. In bible, verify the count equals the passage's verse count. If it exceeds it, delete verse-internal cuts.
6. In prose, the new brakes: a two-member parallel pair joins (N42); a vocative attaches forward (N43); a
   life-story chain is one run (N45); description runs long, action cuts short (N47/N48).

---

## BATCH 6 (15 docs, ALL labelled `exercise` — every one an MCQ question bank of 20 items)
| doc | F1 | P / R | my cuts / key | errors |
|---|---|---|---|---|
| doc_25ed373f8aeb | **100.0** | 100 / 100 | 100 / 100 | 0 |
| doc_60d9a7d0d1ca | **100.0** | 100 / 100 | 96 / 96 | 0 |
| doc_72b8decfdb8c | **100.0** | 100 / 100 | 67 / 67 | 0 |
| doc_74177f9e1015 | **100.0** | 100 / 100 | 100 / 100 | 0 |
| doc_7a7737eabf04 | **100.0** | 100 / 100 | 99 / 99 | 0 |
| doc_e438f8ad8abe | **100.0** | 100 / 100 | 62 / 62 | 0 |
| doc_eb9893e8f98b | **100.0** | 100 / 100 | 95 / 95 | 0 |
| doc_f60bd3a48b58 | **100.0** | 100 / 100 | 100 / 100 | 0 |
| doc_fe3b2556a241 | **100.0** | 100 / 100 | 96 / 96 | 0 |
| doc_1c49614cd6bc | 99.5 | 99.0 / 100 | 101 / 100 | 1 |
| doc_cddb10bd6b23 | 99.5 | 99.0 / 100 | 101 / 100 | 1 |
| doc_d30b2fb502db | 99.5 | 100 / 99.0 | 99 / 100 | 1 |
| doc_ede30da2ee29 | 98.9 | 98.9 / 98.9 | 93 / 93 | 2 |
| doc_617f4fad2251 | 98.5 | 98.5 / 98.5 | 68 / 68 | 2 |
| doc_b3d76332711b | 98.5 | 99.0 / 98.0 | 99 / 100 | 3 |
**10 errors on 15 documents; nine perfect documents.** Running record: 115 docs graded, mean F1 **90.08**
(P 93.64 / R 89.21) — up from 89.19 after batch 4. The batch-5 grid law (G1/G2/E1/E2) is now confirmed
fifteen more times and is the single most valuable thing in my record: it took `exercise` from my worst
topic (F1 46 twice) to nine documents at 100.0. **Nothing structural is left to learn here. All ten
remaining errors are ±1 word at the stem/option seam, or one cut too many inside an option cell.**

### THE OVERRIDING LESSON OF BATCH 6 — THE GRID IS SETTLED; WHAT IS LEFT IS *WHERE THE BLANK IS*
Every error is in one place: the seam between an item's STEM and its first OPTION, or the internal edge of
one option cell. Six of the ten error-points are three adjacent false/missed PAIRS — one boundary put one
word off. That is the whole residue, and it has three named cures below (E14, E15, E16/E17).

**E14 — THE OPTION EDGE IS ASYNDETIC. A cell NEVER begins with و. Every و in an option run is
cell-internal coordination.** This is the strongest checkable rule I got this batch, and it was already
written in my own pre-grading law for `doc_eb9893e8f98b` ("every cell edge is asyndetic; every و in the
document is cell-internal coordination") — I derived it, scored 100.0 with it, and then failed to apply it
one document over. Verified against all four key-side cuts elsewhere in the batch: the key's option edges
open on عند، في، a bare verb, a bare noun — never on و.
- false cut (`doc_1c49614cd6bc` @393): I split one option in two at a و + maṣdar conjunct —
  `بفرض القانون على الجميع ‖ وتحقيق الأمن على النفس والعرض والممتلكات`; the key's option is the whole thing,
  and the NEXT option opens asyndetically (`تعزيز الشعور…`). One option cell can hold two coordinated
  maṣdars with their own PP tails and be 12 words long. Do not resolve below the cell (G3).
- Test to run before every option-run cut: **does the candidate cell start with و? Then it is not a cell.**

**E15 — STEM MATERIAL MAY PRECEDE THE INTERROGATIVE BUT NEVER FOLLOWS A COMPLETE ONE.** These two errors
look opposite and are one law; together they sharpen E3 (scenario + question = one stem).
- Before: a fronted circumstantial/conditional clause rides INTO the stem it precedes (G14/L5).
  false cut (`doc_cddb10bd6b23` @444): I cut `عندما تكون حالة الطرق والحالة الجوية جيدة ‖ كم البعد الذي يجب
  عليك الحفاظ عليه…`; the key runs the scenario straight into its question. Beware the trap that made me
  cut: the clause LOOKS like the previous item's last option (`عند المطر ‖`). Check parallelism with the
  siblings above — `عند المطر` is 2 words, this is 7 and it is a full clause, so it belongs below, not above.
- After: once the interrogative frame is complete and answerable, everything after it is OPTIONS.
  missed (`doc_b3d76332711b` @163): `ما الذي يسبب الموت المبرمج للخلايا ‖ عند عدم ارتباط الكروماتيدات
  الشقيقة بالخيوط المغزلية…` — I absorbed the long PP into the stem under "the stem is indivisible". The
  stem's indivisibility (E3, G3) protects material INSIDE the printed stem; it never licenses swallowing an
  option. Ask: is the stem already a complete question? Then close it.

**E16 — THE STEM/OPTION SEAM CARRIES ±1 WORD OF IRREDUCIBLE NOISE when a construct or a noun+modifier
straddles it. Three displacement pairs, six error-points, two later and one earlier than mine.** Recording
this honestly rather than inventing a law, with the three tie-breakers that each site supplies:
- (a) **OPTION-SET PARALLELISM decides — and it outranks my reading of the stem's syntax.**
  `doc_617f4fad2251` @63/64: I cut `…تأكل الأشجار ىسمى ‖ الرعي الجائر ‖ الفائز ‖ الناجح`; the key cuts
  `…ىسمى الرعي ‖ الجائر ‖ الفائز ‖ الناجح`. Three sibling options are bare single adjectives, so the fourth
  is too, and the noun الرعي belongs to the stem. **When N−1 options are bare words of one category, the
  Nth is one bare word of that category; push the surplus into the stem.**
- (b) **A generic construct head before a run of proper nouns stays with the STEM.**
  `doc_ede30da2ee29` @51/52: I cut `تم إنشاء أول أسطول إسلامي في ‖ بلاد الشام ‖ العراق ‖ شمال افريقيا`; the
  key cuts `…في بلاد ‖ الشام ‖ العراق ‖ شمال افريقيا`. Semantic substitution favoured MY reading and the key
  went the other way, so this is not a syntax judgement: with a place-name option set, a stem-final
  بلاد / مدينة / عهد / سنة rides with the stem.
- (c) **Never extend the stem past a SUBORDINATOR to give the option a subject.**
  `doc_b3d76332711b` @395/396: I cut `يفرز ADH عندما يحدث ‖ انقباض للاوعيه الدمويه`; the key cuts
  `يفرز ADH عندما ‖ يحدث انقباض للاوعيه الدمويه`. E2's dangling-lead-in list includes bare subordinators
  (عندما، إذا، لأن، حيث), and the stem stops dead at them. I pulled يحدث back to tidy the syntax; the
  annotator was reproducing a stripped blank, not a clause (E2/L2).

**E17 — READ THE WHOLE OPTION SET BEFORE PLACING THE STEM'S END.** The unifying method behind E16: an MCQ
item is a paradigm, so the options are the evidence for the stem, not the other way round. Procedure — list
the item's N options, find their common syntactic type and typical length, then place the stem's end so all
N options have that type. Every one of this batch's displacement pairs was a site where I placed the seam
from the stem's syntax alone and never looked down the column.

**E18 — an OVER-LONG option can be split at a trailing PP. Layout noise (line-wrap), but the signal is
length relative to its siblings.** One missed cut; E13 family.
- missed (`doc_d30b2fb502db` @262): key `استخدام السخان الكهربائي بدلا من السخان الشمسي ‖ في تسخين الماء ‖`
  against sibling options of 3–4 words (`تمزيق القصص بعد قراءتها`). An option that markedly overshoots its
  column's length may have wrapped and been segmented at the wrap. Do not chase; the density/count check is
  what catches it (I cut 99 against the key's 100).

### exercise — the laws that worked, now on very large evidence (keep verbatim)
- **E1/E2 are the whole register.** One unit per item STEM, one unit per ANSWER OPTION, however short
  (`صح`, `خطأ`, `الشورى`, `الحرية`, `أريحا`, `معان`, `أصفر`, `tRNA`, `الأدمة`, bare numerals `16`, `18`,
  `ساعة`, `ثانيتين`) and however repetitive (eight consecutive `عليه السلام` cells; four cells reading
  `السير بسرعة أقل من X كم في الساعة`; the option column `الفن التشكيلي / الفن الصوتي / الفن الحركي /
  جميع ما ذكر` printed twice). Zero errors at any of these in fifteen documents.
- **The stem cuts from its options even when it breaks off mid-syntax**, on a proclitic (`ب`, `ل`), a
  preposition (`عبر`, `إلى`, `في`, `عن طريق`), a construct head (`كل`, `مساحة`, `الغدة`), a maṣdar awaiting
  its object (`تفادي`), a verb awaiting its object (`يحدث`, `نصنع من القطن`), an exceptive (`ما عدا`), an
  apodosis marker (`فإنك`) or an identifying copula (`هي`, `بأنها`). Zero errors: this is E2 and it never
  failed once this batch.
- **The stem cell is INDIVISIBLE (G3).** A quoted ayah or hadith with its citation tag, an embedded
  imperative or vocative (`يا أيها الناس` — G3 outranks G15), inline honorifics (`صلى الله عليه وسلم`,
  `رضي الله عنه`), a two-sentence definition, an inline example list, a riddle scenario, a ولكن-contrast, a
  51-word scenario paragraph, four stacked relative clauses, و + finite verb — all ride inside one stem.
- **Nothing above the cell glues either.** `نعم ‖ لا` and `صح ‖ خطأ` are two units each; an option run never
  rides as one list; `يعجبني ‖ لا يعجبني` splits.
- **The arithmetic check is exact and I should run it every time.** These banks are 20 items; total units =
  20 stems + Σ options, and the units partition ALL the words with the last option ending on the last word
  (`doc_25ed373f8aeb`: 20 × (1+4) = 100 units over 602 words, last unit ends on word 601). Shapes seen:
  20×(1+4)=100 (five docs), 20 stems + 79/80/81/73 mixed options, 20×(1+2)+… for صح/خطأ banks (62, 67, 68).
- **Density (G9), observed this batch: 2.5–6.1 w/unit, centre ≈ 3.7.** doc_ede30da2ee29 2.51 ·
  doc_60d9a7d0d1ca 2.86 · doc_7a7737eabf04 3.66 · doc_d30b2fb502db 3.74 · doc_74177f9e1015 4.28 ·
  doc_1c49614cd6bc 5.14 · doc_25ed373f8aeb 6.02. Option cells alone average ~3.25 words; a mean above ~5 is
  only legitimate when the bank has unusually long definition/scenario stems. The one-unit-per-item reading
  (21.4 w/unit) is excluded outright by the band — that reading is what cost me 94 errors in batch 5.

### Method note for batch 7
1. On an `exercise` label: E1/E2 immediately, no syntax. That part is done and it is worth 100.0.
2. Then spend ALL remaining effort on the stem/option seam, and spend it by reading the OPTION COLUMN
   (E17), not the stem. Every error I have left in this register lives at that one seam.
3. Three hard checks before submitting an exercise doc: no cell begins with و (E14); no stem continues past
   a complete interrogative (E15) or past a bare subordinator (E16c); units × band ≈ word count, and the
   last unit ends on the last word.

# BATCH 8 (final practice, batch A) — eight `expository` documents. 142 errors: 128 FALSE CUTS, 14 misses.
Mean F1 81.8. Per-doc: a74a9e93d97a 93.2 · 5a3a244c59f1 88.6 · 8b2d52902b9b 87.6 · 9a890accffc8 81.2 ·
528da1fb596e 78.6 · 5e12ebe2976f 77.3 · de12d5da4854 74.3 · 3272f207e8c9 73.7.
Recall was 89-100 everywhere. **Every point I lost was precision. I cut ~35% too often.**

## L8.1 — THE EXPOSITORY BAND IN MY DOCTRINE WAS FAR TOO LOW, AND IT DROVE MOST OF THE DAMAGE
Observed w/unit in the answer key, this batch: **14.4 · 15.7 · 18.0 · 18.8 · 19.1 · 21.4 · 22.4 · 23.8**
(a74a9e93d97a translated academic book 14.4 · 8b2d52902b9b magazine page 15.7 · 528da1fb596e Wikipedia bio
18.0 · 5a3a244c59f1 essay 18.8 · 9a890accffc8 Wikipedia club article 19.1 · 5e12ebe2976f essay 21.4 ·
3272f207e8c9 author preface 22.4 · de12d5da4854 classical essay 23.8). My doctrine said 13-16 and I used it
as a gate to ADD cuts — on doc_de12d5da4854 a conservative first pass gave 49 units (19.4 w/unit; the true
answer was 40 units / 23.8) and I talked myself up to 65 because 19.4 was "above band". **The band itself
was the error.** M8 is only a gate when the band is right; a wrong band manufactures false cuts.
- `expository` is not one register. **NEWSPAPER/MAGAZINE pages with layout furniture run 14-16.
  BOOKS, ESSAYS, PREFACES, WIKIPEDIA ARTICLES run 18-24.** The tell is layout lines
  (masthead/byline/headline/stat box/ordinal subheads) versus continuous authored prose.

## L8.2 — X1 IS INVERTED FOR LONG-PERIOD EXPOSITORY: و + FINITE **JOINS** (~75%), IT DOES NOT CUT
This alone was ~45 false cuts. In doc_de12d5da4854 the key rides و+finite at ويدعون, ويصبح, ويوصلون,
وتعتبر, ويتهم, وقلما, واعتبرت, وقد فقدت, وأخذت, وتصوروا and cuts at only six of them. All false cuts of mine:
- ووفرت للباحثين · ووصلته بالثقافة العالمية · وأنجزت الكتاب في نحو سنة ونصف · وتقودني نهاية كل مغامرة ·
  ودفعته إلى المطبعة · وصدرت الطبعة الثانية · وعهدت إلي بتدريس · وتزايدت الدعوات · وتحقق ذلك جزئيا ·
  وأقام عند عمه · وتعددت موضوعاته · وأصبح له في الغرب · وقدرت الجارية بأربعة ثيران · وتخطوها ·
  وأصبح المبنى · وتم افتتاح · ويتم إزالتها · ويفترض أن · ويقع مقره · ويخوض كل مبارياته ·
  ويعتبر من أغنى الأندية · ومضى النهر · وتم أخذ اسم النادي · وكانت مهمة شاقة · وكان عمل الباحث.
**The و-chain IS the sentence.** Where the key does break a و-chain it is because the period has already run
~20-30 words and a new TOPIC starts, not because of the و.
- ONE genre resisted: doc_a74a9e93d97a (translated modern academic prose, 14.4 w/unit) cut correctly at
  وبدأ / وما لبث / وقد اعتلى / وتتضمن / وتظهر / وعرف / وكان — that document scored 93.2 on the OLD law.
  So the و rule is genre-conditional and the density band is the discriminator to read FIRST.

## L8.3 — فـ + FINITE JOINS. فـ + NOMINAL STILL CUTS.
My worst document (73.7) was a فـ-chain I shredded:
فرحت أبحث في منافذ بيع الكتب … عن مراجع باللغة الإنجليزية ‖ فلم أجد ضالتي ‖ فتأكدت لي استحالة إتمام المشروع
‖ وتوقفت عن الكتابة — the key has NO cut at any of those three; the whole consequence chain is one period.
Same: فمضى · فوجدت · فاتخذ · فيجتاز · فتتحرك · فيستنكرون · فيكتسب · فتفرغت · فلم أتعجل · فصدر. All false.
- فـ + a NOMINAL subject keeps its old status and CUTS: فإننا · فإنهم · ففريق · فإن الخلايا · فهو · فهي ·
  فتقنيات · فالبعض · ففي سنة 1921 (fronted-PP variant) — all correct.
- فقد + perfect is a genuine **coin flip** (4 cut / 4 join this batch): فقد ولد · فقد أمضى · فقد كان مبرزا ·
  فقد ثبت cut; فقد استرعت · فقد بدأ الفتى · فقد أثبت · فقد نفدت join. Tie-break by length: join while the
  current period is short, cut once it has run its ~20 words.

## L8.4 — X3 IS REVERSED. CONTRAST MARKERS DO **NOT** CUT IN EXPOSITORY.
"cut before لكن always, even a tiny contrast" was wrong on this evidence, and the extension I invented in
batch A to بل and في حين أن made it worse. All false cuts:
- **لكن / ولكن**: …إحسان عنتابي ‖ ولكن ألوانه بهتت · …الأمور الشكلية ‖ ولكنهم من أكثر الأمم ·
  …الحياة الغربية ‖ ولكنها تبقى · …من حيث الأساس ‖ ولكنه يتضمن · …هذه الهزيمة ‖ ولكنه تراجع ·
  …باحتلال سيناء ‖ لكنهم انسحبوا · …الدور قبل النهائي ‖ لكنه احتل · …اللاعب السويدي ‖ لكنه سأل ·
  …ومهرجان أهداف ‖ لكن في النهاية · …بعد الاعتداء علي ‖ لكنني سرعان ما.
- **بل** (6/6 false): …رؤية أو سمعا ‖ بل يبحث دوما · …على ما كان ‖ بل يقولون · …الحركات التجديدية ‖ بل إنهم
  يقاومونها · …من اعتبار ‖ بل يصبح مكروها · …وعلى حد سواء ‖ بل كثيرا ما يحدث · …معها يوميا ‖ بل وصارت.
  **بل NEVER cuts, in any register. Delete the exception I invented.**
- **في حين أن / بينما / مع أن / إلا أن**: …إلى التجديد ‖ في حين أن بعضهم · …في بعض الميادين ‖ في حين أن روح
  المحافظة · …الحياة الاقتصادية ‖ في حين أن أكثر الأمم · …سير بيرو دافنشي ‖ في حين كانت ألله ·
  …١٩٤٦ م ‖ مع أنه من المجحف · …في لبنان ‖ إلا أنه عاد · …استثنائية هذه المرة ‖ فقد استرعت.
  M7 was right all along: these are subordinators and they hold.
- **ولهذا / ولذلك / وبالتالي / كذلك** also JOIN: …العقاب الصارم ‖ ولهذا يطلبون · …كما للذهب الآن ‖ ولذلك
  رسمه · …الأسود والأصفر ‖ ولهذا أطلقوا · …بايرن ميونخ ‖ ولهذا تعرف · …بمستوى غير متوقع ‖ كذلك منتخب
  البحرين. I had been treating a consequence connective as a unit-opener. It is not.

## L8.5 — ثم + NEW EVENT JOINS IN EXPOSITORY (V6 is narrative-only)
…رئاسة الوزراء ‖ ثم اختير رئيسا للجمهورية · …إلى أسيوط ‖ ثم انتقلوا سنة 1923 · …بمحرم بك بالإسكندرية ‖ ثم
التحق بالمدرسة الابتدائية · …ثمانية أعوام ‖ ثم كتبته في عامين · …نهاية العام ‖ ثم تتالت الطبعات. All false.
A chronological ثم step rides inside the period.

## L8.6 — كما SPLITS TWO WAYS, AND I HAD THE EXAMPLE SIDE BACKWARDS
- **ADDITIVE كما ("likewise/also"), a new independent assertion, CUTS**: كما يوجد دور أول · كما يغالي بعض
  المحافظين · كما سيشارك منتخب أستراليا · كما وصل منتخب الأردن · كما اقترب من تصوير · كما تعلم ليوناردو ·
  كما تشمل بعضا من المعالم — all correct.
- **COMPARATIVE كما, pointing at a named parallel case, JOINS**: …بتسعة ثيران ‖ كما قدر سلاح جلوكوس ·
  …التطور التكنولوجي المنتظر ‖ كما فعل جورج أرويل · …في عالم جديد رائع ‖ وكما في تلك الروايات. False cuts.

## L8.7 — وذلك CUTS. THIS REVERSES M4/V12 FOR THE EXPOSITORY CASE.
MISSED: …أي بعد 3 سنوات فقط من البطولة الثالثة عشرة ‖ وذلك بسبب وجود العديد من الأحداث الرياضية المهمة…
The key opens a new unit at وذلك. I rode it backward on M4 ("backward-facing → boundary after it") and it
cost a miss AND a 57-word unit. Confirmed twice more: MISSED at …من عناصر الحياة ‖ وهما متلازمان وضروريان…
and at …والشمعدانات والأضرحة ‖ وكلها موشاة بزخارف فائقة ‖. **وذلك / وهذا / وهو / وهي / وهما / وكلها +
predicate = its OWN unit.** And V11's "a closing و-clause saying what is done with the list rides" is FALSE
for وكلها + predicate.

## L8.8 — LAYOUT LINES: TITLE ≠ SUBTITLE, BUT CHAPTER TITLE + SECTION SUBTITLE CAN BE ONE LINE
- MISSED: فرانسوا كيفيجيه ‖ ليوناردو دافينشي ‖ الذات والفن والطبيعة ‖ — a book MAIN title and its SUBTITLE
  are two separate units. I ran them together.
- FALSE CUT: الفصل الأول ‖ السنوات الأولى في فلورنسا التعليم والتكوين ‖ — the chapter title and the section
  subtitle under it are ONE unit. M9 does not split every consecutive heading; the numbered chapter LABEL
  splits (E8 holds), a title + its immediate subtitle does not.
- من عام 1929 حتى 1949 ‖ is its own unit (a bare date range acting as a heading), and the following sentence
  keeps its own في عام 1929. I displaced that boundary by one junction (F5).
- 3 3 in the stat box: the key reads ‖ 3 3 ‖, not ‖ 3 ‖ 3 ‖. Two adjacent bare numerals of one stat are ONE
  cell, not two.
- A magazine headline can be shorter than it looks: the key reads ضرب الحكام ظاهرة خطيرة ‖ as the headline
  and starts the body at تزايدت في ملاعب كرة القدم العالمية. **When a headline is a verbless nominal
  predication, it ENDS there** — do not swallow the following verb into it.

## L8.9 — WHAT DOES STILL CUT (the 14 misses name the real boundary generator)
1. An **asyndetic bare-verb clause** after a complete nominal predication: …هو ثاني رؤساء مصر ‖ تولى السلطة
   من سنة 1956 حتى وفاته ‖ (I had ridden it as a صفة under M4 — wrong), and …كما يوجد دور أول في نهائيات
   البطولة ‖ يقسم المنتخبات المتأهلة….
2. **وقد + perfect** at a topic step: …بريد باكوس هناك ‖ وقد تزوج من السيدة فهيمة….
3. **و + كان + a new subject** at a topic step: …أول أبناء والديه ‖ وكان والداه قد تزوجا….
4. **و + finite once the period has run its ~20 words**: …في حرب 1967 ‖ وبدأ عملية عدم تسييس الجيش وأصدر
   مجموعة… (وشن joined, وبدأ cut, وأصدر joined — pure rhythm, not connective identity).
5. **A coordinated أن-complement CAN cut**: …قبل أن تحتاج للفكر الرياضي ‖ وألا يسهو أثناء المباراة….
   M7's "coordinated أنْ-complements under one order JOIN" is not safe when the second complement is long.
6. **Displacement is still alive (F5)**: in the Verrocchio list the key rides both items together and cuts at
   …الموجود في البندقية ‖ وكان قد شرع في تصميمه… — I cut one junction early, at بدأ العمل به 1467.

## L8.10 — METHOD FIX
The lesson is a POLICY, not a connective. On an expository document:
1. Decide FIRST whether it is a LAYOUT page (14-16 w/unit) or CONTINUOUS AUTHORED PROSE (18-24).
2. Build PERIODS of ~20 words, not clauses. Start from topic structure, only then look at connectives.
3. Ride و+finite, فـ+finite, بل, لكن, في حين أن, بينما, ثم, ولهذا, ولذلك, كذلك, comparative كما.
4. Cut at: layout lines · asyndetic topic jumps · فـ+nominal · additive كما · وذلك/وهذا/وهو/وهي/وهما/وكلها
   + predicate · fronted أما…فـ · and a و-clause only once the period has already run long.
5. When torn, DO NOT CUT. Recall was 89-100 with a policy that over-cut by 35%; the marginal cut is worth
   far less than the marginal precision point.

# BATCH 8B — 90 errors on 8 docs (46 false cuts, 44 misses). Mean F1 84.6, up from 81.8.
Per-doc: 449f221bdbd2 99.0 (MCQ) · 2fabc1ccf342 93.3 · ae1331c52539 93.3 · 616eaaa0cc9d 84.8 ·
40e700c4f806 82.4 · 83e3dc997e52 80.0 · 9d15d9d5d637 77.1 (narrative) · 1d08b507b151 66.7 (hadith).
**The batch-A correction worked** — precision 92, recall 89, errors now balanced instead of 128/14. What is
left is (a) one big structural miss and (b) F5 displacement, which is now my dominant error class.

## L8.11 — A SPEAKER LABEL IN A SCRIPT IS ITS OWN UNIT. 20 misses in one document.
doc_9d15d9d5d637 embeds a play in which every character is called سارة. The key reads:
`…على المثال الآتي ‖ سارة ‖ إني لا أرضى أن أصاحبك… ‖ سارة ‖ وهل تحسبين… ‖ سارة ‖ على رسلكما…`
I rode each label into its turn on V13's "the FIRST quoted sentence rides on its speech frame". **A SPEAKER
LABEL IS NOT A SPEECH FRAME.** قال همام is a frame (a verb); سارة on its own is a printed layout line, and
M9 governs it. Twenty-one labels, twenty-one units, twenty of them misses.
- It goes further: inside a turn the key also isolates a listed NAME as a cell —
  `سارة ‖ دعوت سارة و ‖ سارة ‖ سارة ‖ أخشى أن تكون…`. When a dialogue turn ENUMERATES names, the names are
  cells (E1 logic leaking into a novel), not one NP list.

## L8.12 — IN NARRATION A SPEECH FRAME CARRIES ITS **WHOLE** QUOTED TURN, NOT JUST THE FIRST SENTENCE
V13's "every quoted sentence is its own unit" is far too strong for a novel. False cuts, all of them:
- `قال همام كفاية ‖ لقد ظفرنا بتصفيق…` → key: one unit.
- `قال هدئي من روعك ‖ إنما ثناء أردت لا ملامة` → one unit.
- `قال همام أسعد الله الصباح ‖ أين زاهر يا مدام` → one unit (frame + TWO sentences).
- `فسألها قائلا وأنت يا سيدة ‖ نعم أنت يا سيدة في هذه المرة ‖ لأية قرابة ترشحين نفسك…` → ONE unit, three
  sentences of speech under one frame.
- `وقالت ضيف ‖ ولكن لا أظنه طويل المقام` → one unit.
- `…مرحة ضاحكة ‖ احمد ربك` → the quoted nukta rides on the narration that introduces it.
**Model: frame + the whole turn = one unit, up to ~18 words; break only when the speech runs longer, and then
at a genuinely new question** (`…ولكن لا أظنه طويل المقام ‖ ألا تراه يتعثر بقدميه ‖`).
- The counter-case that keeps the rule honest: `…بكلمات لا مقدمة لها ولا سابقة لتفسيرها ‖ كم لك من وجوه يا
  سارة ‖` was a MISS — when the frame is itself long and elaborated, the cry does stand alone.

## L8.13 — A STRIPPED-COLON ENUMERATION SPLITS INTO CELLS, AND ITS LEAD-IN IS ITS OWN UNIT (hadith)
My worst score of the batch (66.7). The key on the Muwatta hadith:
`…يكفر الله عنه كل سيئة كان زلفها ‖ وكان بعد ذلك القصاص ‖ الحسنة بعشر أمثالها إلى سبعمائة ضعف ‖ والسيئة
بمثلها إلا أن يتجاوز الله عنها ‖` — four units, not two. I applied G3's "a lead-in shares the fate of its
items; flat NP items ride" and got the fate backwards. **When the enumeration is a two-or-more-member
PARADIGM (X gets a, Y gets b), the members split and the lead-in stands alone** — V11's "flat NP item rides"
covers a list inside running prose, not a colon paradigm. My reading of the hadith family was otherwise
right: it is NOT family A (a printed hadith edition punctuates inside the hadith), the connective table is
live, and the isnad rides with the first matn sentence.

## L8.14 — إذ DOES CUT IN EXPOSITORY. I over-corrected in batch A.
MISSED twice in one 62-word brief: `وتصدر هذه الترشيحات فيلم جاذبية ‖ إذ حصل على 11 ترشيحا ‖ وجاء بعده فيلم
12 سنة عبدا…`. Batch A killed the whole of X3, but the إذ clause of the old X3 was right for expository news
(V7's "إذ NEVER cuts" is narrative-only). Same site shows و+finite (وجاء) cutting in a news brief.

## L8.15 — وذلك: ONLY THE CAUSAL ONE CUTS
- CUTS: `…من البطولة الثالثة عشرة ‖ وذلك بسبب وجود العديد من الأحداث…` (batch A miss).
- JOINS: `…عن مستوى ال 70 دولارا وذلك في آخر تعاملات الأسبوع…` (TIME) and `…بنفس قدرات اليد المفقودة وذلك
  لإنسان عاش 14 عاما…` (BENEFICIARY), and `…مبتور اليد وتلك هي ثالث عملية ناجحة…` — three false cuts.
**Rule: وذلك / وتلك + بسبب or a causal clause = own unit. وذلك / وتلك + a time, place, beneficiary or
identifying PP rides.** Same narrowing for وهذا: `فإنها تستقبل ملايين السياح كل عام وهذا دليل كبير على
تطورها` joined (false cut) — so X6's وهذا clause only holds when the comment is a fresh evaluative
predication in scholarly prose, not a tag on the sentence it evaluates.

## L8.16 — NARRATIVE: و+finite ≈ 50/50 BY RHYTHM; فـ+finite JOINS
CUTS (misses): `…ومشفق تارة أخرى ‖ ويعزو تقلبها…` · `…في كل ساعة ‖ وخطر له أن ينشئ…` · `…في ثياب الشرطة ‖
ويصيح أين المشاجرة…` · `…للخامسة والعشرين ‖ وتسمى آنسة…` · `…في وقت واحد ‖ ورحب مع ذلك…` · `…لم توافق
هواها ‖ وسمعها تجيب…` · `…على ما يظهر ‖ وآسف لأني قطعت…`.
JOINS (false cuts): `…وصلة بينهما ويضحكان ضحكا كثيرا…` · `…تلتقي بهمام وإنما جاء اللقاء…` · `…شخوص
الروايات وهي تصغي إليه…` · `…بداهة وطواعية ثم نكتة…` · `…حريم كامل فلا تشكر نفسك…` · `…خاتم الزواج فأين
هذه العلامة…` · `…يعبر الفناء فسأل الخائطة…` · `…ثم ينساه فأسفرت عن الغضب…` · `…يغيظها قليلا وعاد يقول…` ·
`…رأسها تفكر ثم قالت…` · `…ابتسامة عريضة وإنما أجابت الفتاة…`.
So in narrative: **فـ+finite JOINS (11/11 this batch), ثم JOINS, وإنما JOINS, ولكن JOINS
(`…وتذبذبها في الوطنية ولكني لا أذكر…`), و+ḥāl (وهي تصغي / وهي مشغولة) JOINS — reversing V12 for a bare ḥāl.
و+finite is decided by the ~10-word rhythm, nothing else.**

## L8.17 — F5 DISPLACEMENT IS NOW MY DOMINANT ERROR CLASS, AND IT HAS ONE SHAPE
Six paired miss/false-cut sites this batch, and in every one **the key put the boundary BEFORE a fronted
adverbial that I attached backwards**:
- `…العين لتدمع على القتلى ‖ في كل يوم كل شهيد يشيعه شهيد ‖` — I cut after يوم.
- `…والله شيء محير ‖ في إن كبيرة في الموضوع يرجى التفكر ‖` — I cut after الموضوع.
- `…بهذا الشأن والسيب ماش ‖ وأهم شيء عند الشركات كم يدخل في حسابها شكرا ‖` — I cut after الشأن and after حسابها.
- `…إنها تستركما على كل حال وأنتما ضيفتاي غدا ‖ فهل تحضران…` — I cut after حال.
- `…كما تصلح للخامسة والعشرين ‖ وتسمى آنسة كما تسمى سيدة وهي مشغولة…` — I cut after سيدة.
**Check: once I know a boundary is in the neighbourhood, put it immediately before the element that OPENS the
new unit (M4) — and a fronted PP/adverbial belongs to the FOLLOWING unit, so the boundary goes before it,
not after it.** Also note closing formulas ride: `…في حسابها شكرا ‖` — شكرا did NOT stand alone.

## L8.18 — MCQ: E6 EARNED ITS KEEP AND I STILL MISREAD ONE STEM SEAM (99.0, 2 errors)
`…بطريقة غير علمية يؤدي إلى ‖ انتشار الأوبئة والأمراض المعدية ‖ زيادة نسبة الاحتباس الحراري ‖ …`
The stem runs THROUGH يؤدي إلى (E2: a verb+preposition awaiting its object is a dangling lead-in). I stopped
the stem at علمية because I read option 1 as a clause. The option column said otherwise: two of four options
are bare maṣdar NPs (زيادة نسبة…, زيادة الإنتاج…), so all four are, and يؤدي إلى belongs to the stem. **E6
again: read the OPTION COLUMN first, make the four options parallel, then place the seam.**

# BATCH 8C — 134 errors on 8 docs (75 false cuts, 59 misses). Mean F1 79.5.
Per-doc: 56781db1019f 87.1 · 2baf8d2ac98d 86.5 · ca06bbd92e01 85.7 · 099def456da2 82.0 · 9f9992d71084 80.9 ·
6806936b7535 77.5 · 59a45e1e029a 71.4 · 35734be96b2b 65.2. All narrative except one `other`.

## L8.19 — VERSE QUOTED INSIDE A NON-`poetry` DOCUMENT SPLITS AT THE HEMISTICH AND BELOW. 14 misses.
My worst score of the batch (65.2, recall 50). I applied P1 (the بيت is the unit, rhyme marks the line end) to
verses quoted on a narrative anthology page. **E10 already told me this and I did not carry it across:** "a
poem quoted inside a worksheet splits BELOW the hemistich, at each internal complete predication — poetry's
inviolability does not travel." It travels to ANY non-`poetry` label, not just worksheets. The key:
`أبلغ سليمان أني لست في سعة ‖ وفي غنى غير أني لست ذا مال ‖ يسخو بنفسي أني لا أرى أحدا ‖ يموت هزلا ولا يبقى
على حال ‖ والفقر في النفس لا في المال نعرفه ‖ ومثل ذاك الغنى في النفس لا المال ‖` — every صدر and every عجز.
And in the second poem it goes FINER STILL, one unit per predication inside the hemistich:
`ليس البلاغة معنى ‖ فيه الكلام يطول ‖ بل صوغ معنى كثير ‖ يحويه لفظ قليل ‖ فالفضل في حسن لفظ ‖ يقل فيه الفضول
‖ يظنه الناس سهلا ‖ وما إليه سبيل ‖ والعي معنى قصير ‖ يحويه لفظ طويل ‖` — note بل CUTS here, the only place
I have ever seen it cut, because the hemistich boundary falls there.
**Rule: `poetry` LABEL → the بيت is inviolable (P1). Verse inside any other label → cut at every hemistich,
and at every complete predication inside a hemistich.**
- Also on that page: `وقال له ‖ قل لسليمان مادمت أجد هذا…` — the speech frame does NOT carry its quote when
  the quote is a whole quoted MESSAGE being relayed (قل ل…), and `وبعث مع الرسول بمال كثير فأبى الخليل` joins.

## L8.20 — A CHANT / REPETITION RUN SPLITS INTO ITS PRINTED LINES, AND THE LINES ARE SHORT
doc_59a45e1e029a (`other`, 39 words): the key cuts 9, I cut 5. It reads
`ضربه فان داي القاضيه ‖ لا×8 ‖ لا×8 ‖ لا×8 ‖ داي داي داي ‖ داي الشجاع ‖ داي داي داي ‖ داي الشجاع ‖ داي ‖`.
So the 24 لا are THREE lines of eight, and each داي-line splits into `داي داي داي ‖ داي الشجاع`. I treated the
لا-run as one continuous exclamation. **When a document is nothing but a repeated chant, look for the repeat
PERIOD (here 8, and 3+2) and cut on it** — M1's "own row on the page" test applies to chant lines too.

## L8.21 — INFORMAL FIRST-PERSON DIARY PROSE SEGMENTS FINER THAN LITERARY NARRATIVE, AND لكن CUTS THERE
doc_6806936b7535: the key cuts 67, I cut 62, at 8.8 w/unit — and 20 of my 29 errors are misses. Sites:
`…وكان الانتظار متعبا لي ‖ لكن الحمد لله وجودها معي…` and `…وكان الأمر متعبا جدا ‖ لكن هذه الحياة ‖ لابد أن
تتعب لكي تلقى ‖` — **لكن CUTS in this register** (contrast batch A, where it rode 10/10 in expository, and
batch B, where it rode in literary narrative). Also `فوافقوا وتقدمت إليها ‖ فقبلوا في بداية الأمر ‖` — a
3-word فـ-clause is its own unit here, and `أريد إجابة ولا إجابة ‖`, `وفرحت ولم أفرح…‖`, `فكانت كل الوفاء`
all stand alone. I merged seven three-word fragments back into neighbours to lift density and five of those
merges were wrong. **Register ladder for narrative: comic-strip balloons ≈4 · informal diary/testimony ≈8.8 ·
literary narrative and Nights prose ≈11-12 · children's abridgement ≈12.9.**

## L8.22 — I AM STILL OVER-CUTTING CHILDREN'S-STORY NARRATIVE BY ~20%
099def456da2: 58 vs 42 key (real density 15.4, not 11.1). 9f9992d71084: 50 vs 39 (real 15.7, not 12.3).
56781db1019f: 98 vs 88 (real 12.9). So **fairy-tale / children's-abridgement narrative runs 13-16 w/unit,
NOT 8.4-12.3.** The 8.4-12.3 band came from action-heavy literary prose. Same shape as the batch-A expository
error: one band covering several sub-registers, and I trusted it to justify extra cuts.

# BATCH 8D — 43 errors on 5 docs (30 false cuts, 13 misses). Mean F1 82.7.
Per-doc: 9f8cf954304a 100.0 (quran) · d1b08b16526d 100.0 (quran) · a9c7d1c861a3 86.0 · daa6620988df 81.1 ·
0696314023ab 46.5. **Two perfect quran documents — Q1 is unbroken (7/7 documents at 100.0).**

## L8.23 — P3 IS WRONG AS I WROTE IT: A REPETITION REFRAIN IS **ONE** UNIT, NOT ONE PER REPEAT
My worst score of all four batches (46.5, precision 32). The key on the Batman song:
`بات مان بات مان بات مان بات مان بات مان بات مان ‖ الحارس الذي لا يهادن الشر ‖ …`
The six-fold opening refrain is ONE unit and the twelve-fold closing refrain is ONE unit. I atomised both
into one unit per بات مان on the strength of batch C's chant (لا ×24 = three lines of eight) and V9. **The
batch-C chant split because it had a real printed line period of eight; a refrain that fills ONE line is ONE
unit.** So P3 must read: *find the printed line and do not go below it* — never "one unit per repeat". This is
M1's own test ("would this get its own row?") and I inverted it two batches running: too coarse in C (4 recall
points), far too fine in D (21 precision points). **When a repetition run's length is not an obvious multiple
of some line, treat the whole run as one line.**
- What I got right there: 10 of the 13 verse lines, and the two-line chorus repeated verbatim.

## L8.24 — P1's "THE بيت NOT THE HEMISTICH" ONLY HOLDS FOR LONG-METRE CLASSICAL VERSE
doc_daa6620988df, a children's school poem (`poetry` label): the key cuts 22 where I cut 15, and every miss is
a HEMISTICH edge inside what I read as one بيت:
`ما أجمل الغيوم ‖ تسير أو تحوم ‖` · `بعيدها السحاب ‖ قريبها الرباب ‖` · `وتركض الغيوم ‖ والرياح تصفر ‖` ·
`ويبدأ الرذاذ ‖ ثم يأتي المطر ‖` · `لو زاد غيث هاطل ‖ نقول هذا وابل ‖` · `سموا معي ‖ المطر الأول بالوسمي ‖` ·
`من أجلنا ‖ من أجل حقلنا ‖`.
**Rule: in مجزوء / short-line verse (children's poems, songs, hymns) each شطر is printed on its own line and is
its own unit; the بيت-as-unit reading is only for long-metre diwan poetry.** Practical discriminator: **if a
candidate بيت is under about eight words, the printed line is the HEMISTICH, so cut at the caesura.** This is
the same law as P2 (verse outside its own label splits at the hemistich) arriving from the other direction —
both say the line, not the couplet, and I now have three documents' worth of evidence for it.
- Note ثم يأتي المطر standing as its own hemistich unit: even ثم, which rides everywhere else, is cut through
  by a line edge (M2 — the unit edge cuts the syntax).

## L8.25 — THE MISLABELLED BOOK (86.0): READING THE LABEL AS A FAMILY WOULD HAVE BEEN A DISASTER
doc_a9c7d1c861a3 carries the `quran` label but only 29 of its 740 words are Quran (al-Fatiha at the head of an
academic book on Abu Hanifa). Treating it as six declared stretches — Fatiha under Q1, khutba / مقدمة /
chapter under expository law, footnotes as label+value lines, six numbered research items as list cells,
عصر أبي حنيفة تمهيد as ONE heading — scored 86.0 with only 13 errors on 44 key cuts. **F6 (declare each
stretch) plus M1 (what does the PAGE print?) outrank the topic label when the label describes a quotation
rather than the document.** My order of operations still says "read the LABEL first", and that is right as a
prior — but the label names the source of the OPENING QUOTATION here, not the family.

## FINAL STANDING AFTER 29 DOCUMENTS (144 graded, mean F1 88.48 / P 91.22 / R 88.78)
Batch A 81.8 → B 84.6 → C 79.5 → D 82.7. The A→B jump (+2.8, and false cuts 128→46) is the real result: it
came from one correction, that expository prose segments at the PERIOD and not the clause. C and D fell back
because each introduced a register I had no band for (fairy-tale narrative, songs, short-line verse) and in
each I repeated the same shape of error — trusting a band or a granularity law derived from a neighbouring
sub-register. **The single most valuable thing I now carry: before segmenting, name the SUB-register and its
band, and never let a band or a granularity precedent travel across a sub-register boundary.**
